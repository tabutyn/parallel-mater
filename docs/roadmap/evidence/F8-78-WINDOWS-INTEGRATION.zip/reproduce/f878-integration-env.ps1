$ErrorActionPreference = 'Stop'
$F878Source = 'C:/Users/tabut/Repos/ballroller-2026/.codex-worktrees/parallel-mater-f8-performance-deferral-20261103'
$F878Build = 'D:/Repos/parallel-mater-f878-integration-build-20261103'
$F878Evidence = 'D:/Repos/parallel-mater-f878-integration-evidence-20261103'
$F878Python = 'C:/Users/tabut/AppData/Local/Programs/Python/Python313/python.exe'
$F878Slang = 'D:/Repos/parallel-mater/build-d3d12-full/_deps/parallel_mater_slang-src/bin/slangc.exe'
& 'C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation | Out-Null
$env:PATH = 'C:/Users/tabut/AppData/Local/Programs/Python/Python313;C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja;C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v12.9/bin;' + $env:PATH
$env:GIT_CONFIG_COUNT = '2'
$env:GIT_CONFIG_KEY_0 = 'safe.directory'
$env:GIT_CONFIG_VALUE_0 = $F878Source
$env:GIT_CONFIG_KEY_1 = 'core.autocrlf'
$env:GIT_CONFIG_VALUE_1 = 'false'
$env:PYTHONUTF8 = '1'
foreach ($name in @('CUDA_LAUNCH_BLOCKING','PM_DRIVER_FILES','PM_LAYER_FILES','PM_ENABLE_LAYERS','PM_TEST_VALIDATION','F876_DIAGNOSTIC_YIELD_WAIT')) {
    Remove-Item "Env:$name" -ErrorAction SilentlyContinue
}
Set-Location -LiteralPath $F878Source
