"""Classify retained F8-78 evidence without changing its frozen oracle."""
import copy
import ctypes
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f878-integration-evidence-20261103')
build = Path('D:/Repos/parallel-mater-f878-integration-build-20261103')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()


def timing_failure(failure):
    allowed = {
        '.timings.physics_ms.p95': 'physics p95 exceeds the target tier',
        '.timings.frame_ms.p95': 'frame p95 exceeds the 60 Hz budget',
        '.simulated_to_wall_time_ratio': 'sustained workload missed the realtime rate',
    }
    actual = failure.get('actual')
    return (
        failure['path'].startswith('$.workloads[')
        and any(failure['path'].endswith(suffix) and failure['message'] == message
                for suffix, message in allowed.items())
        and isinstance(actual, (int, float)) and not isinstance(actual, bool)
        and math.isfinite(actual) and actual >= 0
    )


capture_module = load_module('f878_capture', root / 'conformance/v1/realtime_device_capture.py')
checker = load_module('f878_closures', root / 'tools/check_realtime_candidate.py')
candidate_path = capture_module._candidate_path()
contracts = (
    read(capture_module.PROFILE_PATH), read(capture_module.INVENTORY_PATH),
    read(capture_module.CAPABILITY_PATH), read(capture_module.SUITE_PATH),
    read(candidate_path), capture_module.file_sha256(candidate_path, portable_text=True),
)
assert digest(candidate_path) == '4ed4ed7a097928944ac5667e8120e2447affda962a258e56c01dfd0d90d9dd4b'
source = read(raw / 'source.json')
assert source['revision'] == git('rev-parse', 'HEAD')
assert source['tree'] == git('rev-parse', 'HEAD^{tree}')
assert not source['status'] and not git('status', '--porcelain')
assert source['lease']['token'] == '426c0a4a-1f2a-4a23-9faf-a5bcdf25f531'

registered = read(raw / 'registered-tests.json')['tests']
previous = read(Path('D:/Repos/parallel-mater-f8-77-final-evidence-20261102/registered-tests.json'))['tests']
names = {test['name'] for test in registered}
previous_names = {test['name'] for test in previous}
assert previous_names <= names
test_cases = ET.parse(raw / 'ctest.xml').getroot().findall('testcase')
assert {test.attrib['name'] for test in test_cases} == names
assert all(test.attrib.get('status') == 'run' and test.find('failure') is None
           and test.find('error') is None and test.find('skipped') is None
           for test in test_cases)
sdk = read(raw / 'sdk/report.json')
assert sdk['status'] == 'passed'

aggregate = read(raw / 'capture/capture.json')
original_report = read(raw / 'capture/report.json')
assert len(aggregate['public_cases']) == 30 and len(aggregate['scenarios']) == 12
controls = capture_module.SUITE.REQUIRED_NEGATIVE_CONTROLS
mutations = {
    'candidate_missing_pair': lambda value: value['capabilities'].pop(),
    'atomic_failure_violation': lambda value: next(item for item in value['scenarios']
        if item['id'] == 'capacity-overflow-atomic-recovery')['tick_work'][1].update({'state_unchanged': False}),
    'hidden_retry_violation': lambda value: next(item for item in value['scenarios']
        if item['id'] == 'capacity-overflow-atomic-recovery')['tick_work'][1].update({'hidden_retries': 1}),
    'timing_stall_retained': lambda value: value['workloads'][0]['timings']['physics_ms'].pop('maximum'),
    'timing_failed_tick': lambda value: value['workloads'][0].update({'failed_ticks': 1}),
}
expected_paths = {
    'candidate_missing_pair': '$.capabilities',
    'atomic_failure_violation': '$.scenarios[capacity-overflow-atomic-recovery].tick_work[1].state_unchanged',
    'hidden_retry_violation': '$.scenarios[capacity-overflow-atomic-recovery].tick_work[1].hidden_retries',
    'timing_stall_retained': '$.workloads[rigid-wall].timings.physics_ms.maximum',
    'timing_failed_tick': '$.workloads[rigid-wall].failed_ticks',
}
modes = {}
for mode in ('plain', 'validation'):
    selected = copy.deepcopy(aggregate)
    workloads = {}
    provenance = read(raw / 'capture/logs' / mode / 'provenance.log')
    assert provenance['source_commit'] == source['revision']
    public = list((raw / 'capture/raw' / mode / 'public-cases').glob('*.json'))
    assert len(public) == 30
    assert all(read(path)['execution_status'] == 'completed' for path in public)
    for index, template in enumerate(aggregate['workloads']):
        path = raw / 'capture/raw' / mode / 'workloads' / (template['id'] + '.json')
        workload = read(path)
        assert workload['warmup_ticks'] == 600 and workload['measured_ticks'] == 7200
        assert workload['failed_ticks'] == 0
        assert set(workload['raw_samples']) == {'cpu_ms', 'gpu_ms', 'physics_ms', 'frame_ms'}
        for clock_name, samples in workload['raw_samples'].items():
            assert len(samples) == 7200 and all(math.isfinite(x) and x >= 0 for x in samples)
            ordered = sorted(samples)
            expected = {name: ordered[math.ceil(fraction * len(samples)) - 1]
                        for name, fraction in [('p50', .5), ('p95', .95), ('p99', .99)]}
            expected['maximum'] = ordered[-1]
            assert workload['timings'][clock_name] == expected
        workload.pop('raw_samples')
        workloads[template['id']] = {'sha256': digest(path), **copy.deepcopy(workload)}
        workload['executions'] = copy.deepcopy(template['executions'])
        selected['workloads'][index] = workload
    selected['negative_controls'] = capture_module._negative_controls(selected, contracts)
    canonical = capture_module.SUITE.evaluate(selected, *contracts)
    # The existing control evaluator uses placeholders to avoid recursive control checks.
    # This diagnostic baseline is separate from the retained canonical verdict above.
    baseline = copy.deepcopy(selected)
    baseline['negative_controls'] = [{'id': identity, 'passed': True} for identity in controls]
    baseline_report = capture_module.SUITE.evaluate(baseline, *contracts)
    assert all(timing_failure(failure) for failure in baseline_report['failures']), baseline_report
    baseline_failures = {json.dumps(failure, sort_keys=True) for failure in baseline_report['failures']}
    injected_results = {}
    for identity in controls:
        injected = copy.deepcopy(baseline)
        mutations[identity](injected)
        injected_report = capture_module.SUITE.evaluate(injected, *contracts)
        new_failures = [failure for failure in injected_report['failures']
                        if json.dumps(failure, sort_keys=True) not in baseline_failures]
        assert any(failure['path'] == expected_paths[identity] for failure in new_failures), (identity, new_failures)
        injected_results[identity] = {
            'injected_defect_rejected_independently': True,
            'new_failures': new_failures,
            'full_injected_report': injected_report,
        }
    expected_control_failures = {
        '$.negative_controls[' + identity + ']' for identity in controls
    }
    assert all(timing_failure(failure) or failure['path'] in expected_control_failures
               for failure in canonical['failures'])
    modes[mode] = {
        'provenance': provenance, 'public_cases_passed': 30, 'physical_scenarios_passed': 12,
        'correctness_work_recovery_passed': True,
        'workloads': workloads, 'original_canonical_report': canonical,
        'canonical_negative_controls': selected['negative_controls'],
        'diagnostic_baseline_report': baseline_report,
        'negative_control_differential_diagnostics': injected_results,
    }

closures = []
tracked = set(git('ls-files').splitlines())
with tempfile.TemporaryDirectory(prefix='f878-closure-') as temporary:
    clean = Path(temporary)
    for item in contracts[4]['source']['protected_closures']:
        for pattern in item['patterns']:
            for path in root.glob(pattern):
                relative = path.relative_to(root)
                if path.is_file() and relative.as_posix() in tracked:
                    destination = clean / relative
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(path, destination)
    for item in contracts[4]['source']['protected_closures']:
        count, sha = checker.closure_identity(clean, item['patterns'])
        closures.append({'category': item['category'], 'patterns': item['patterns'],
                         'current': {'file_count': count, 'sha256': sha},
                         'candidate_v9': {'file_count': item['file_count'], 'sha256': item['sha256']},
                         'changed_from_candidate_v9': sha != item['sha256']})

runtime = ctypes.WinDLL('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v12.9/bin/cudart64_12.dll')
memory = {}
for name, enum in [('managed_memory', 83), ('concurrent_managed_access', 89)]:
    value = ctypes.c_int()
    result = runtime.cudaDeviceGetAttribute(ctypes.byref(value), enum, 0)
    memory[name] = {'result': result, 'value': value.value}
assert memory['concurrent_managed_access'] == {'result': 0, 'value': 0}
artifacts = {path.name: {'bytes': path.stat().st_size, 'sha256': digest(path)}
             for path in sorted(build.iterdir())
             if path.is_file() and (path.suffix.lower() in ('.dll', '.exe', '.pdb') or path.name == 'CMakeCache.txt')}
before_path = root / 'docs/roadmap/evidence/F8-76-WINDOWS-CUDA-METADATA-PROGRESS.json'
before = read(before_path)
report = {
    'schema': 'parallel-mater-f8-78-windows-integration/v1', 'task': 'F8-78',
    'status': 'passed_revised_integration_contract', 'final_performance_qualified': False,
    'planning_pr': 'https://github.com/tabutyn/parallel-mater/pull/657',
    'claim_pr': 'https://github.com/tabutyn/parallel-mater/pull/658',
    'source': source, 'cuda_memory_attributes': memory,
    'nvidia_device': subprocess.check_output([
        'nvidia-smi', '--query-gpu=name,uuid,driver_version,memory.total,pci.bus_id',
        '--format=csv,noheader'], text=True).strip(),
    'clean_release': {'registered': len(names), 'passed': len(test_cases), 'skipped': 0,
                      'previous_registered': len(previous_names), 'all_previous_tests_retained': True},
    'relocated_sdk': sdk,
    'capture': {'finished_at': read(raw / 'capture-result.json')['finished_at'],
                'original_report': original_report, 'modes': modes,
                'measured_ticks_total': 72000, 'raw_timing_values_total': 288000,
                'all_samples_and_stalls_retained': True},
    'protected_closures': closures,
    'build_artifacts': artifacts,
    'before_comparison': {
        'report': before_path.relative_to(root).as_posix(), 'sha256': digest(before_path),
        'source_revision': before['after']['source_revision'],
        'performance_observations': before['performance_observations'],
        'changed_files': git('diff', '--name-only', before['after']['source_revision'], source['revision']).splitlines(),
        'interpretation': 'The before capture predates F8-77 and F8-73. Their accepted production changes are included in this integrated after capture. This task adds evidence only.',
    },
    'limitations': [
        'F8-74 still needs an immutable replacement candidate and fresh physical qualification rows.',
        'Original timing targets and timing-contaminated canonical control baselines remain F9-07/F9-08 obligations.',
        'The capture labels the historical v9 oracle contract. Actual executed source is recorded separately and does not qualify candidate v9.',
        'Passing frozen physical assertions does not establish convincing scene behavior. F9-01 through F9-06 own that work.',
    ],
}
output = raw / 'integration-evaluation.json'
assert not output.exists(), output
output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'tests': report['clean_release'], 'workloads': {
    mode: {name: value['timings']['physics_ms']['p95'] for name, value in row['workloads'].items()}
    for mode, row in modes.items()}, 'closures_changed': [row['category'] for row in closures if row['changed_from_candidate_v9']]}, indent=2))
