. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f878-integration-env.ps1
if ((Test-Path -LiteralPath $F878Build) -or (Test-Path -LiteralPath $F878Evidence)) { throw 'Retain previous evidence and build directories' }
if (git status --porcelain) { throw 'Build requires a clean source tree' }
$task = Get-Content docs/roadmap/tasks/F8-78.json | ConvertFrom-Json
if ($task.lease.token -ne '426c0a4a-1f2a-4a23-9faf-a5bcdf25f531') { throw 'Unexpected lease' }
if ([DateTimeOffset]::Parse($task.lease.expires_at) -le [DateTimeOffset]::UtcNow) { throw 'Lease expired' }
New-Item -ItemType Directory -Path $F878Evidence | Out-Null
@{revision=(git rev-parse HEAD); tree=(git rev-parse 'HEAD^{tree}'); source=$F878Source; status=(git status --porcelain); captured_at=[DateTimeOffset]::UtcNow.ToString('o'); lease=$task.lease} | ConvertTo-Json -Depth 6 | Set-Content -Encoding utf8 "$F878Evidence/source.json"
$env:PATH = "$F878Build;" + $env:PATH
$configure = @('-S',$F878Source,'-B',$F878Build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DBUILD_TESTING=ON',
    '-DCMAKE_CUDA_ARCHITECTURES=61','-DPARALLEL_MATER_BUILD_CUDA=ON','-DPARALLEL_MATER_BUILD_D3D12=OFF',
    '-DPARALLEL_MATER_BUILD_VULKAN=OFF','-DPARALLEL_MATER_BUILD_GALLERY=ON','-DPARALLEL_MATER_BUILD_CONFORMANCE=ON',
    '-DPARALLEL_MATER_BUILD_SLANG_MIRRORS=ON','-DPARALLEL_MATER_BUILD_SLANG_GEOMETRY_CONSTRAINTS=ON',
    '-DPARALLEL_MATER_WINDOWS_GALLERY_AUTO_DEPLOY=OFF',
    '-DFETCHCONTENT_SOURCE_DIR_PARALLEL_MATER_GLFW=D:/Repos/parallel-mater/build-d3d12-full/_deps/parallel_mater_glfw-src',
    "-DPython3_EXECUTABLE=$F878Python","-DPARALLEL_MATER_SLANGC_EXECUTABLE=$F878Slang")
@{executable='cmake'; arguments=$configure; build_directory_existed=$false} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F878Evidence/configure-command.json"
Write-Output 'F8-78 configure'
cmake @configure *> "$F878Evidence/configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F878Evidence/configure.log" -Tail 25; exit $LASTEXITCODE }
Write-Output 'F8-78 clean Release build'
cmake --build $F878Build -j 4 *> "$F878Evidence/build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F878Evidence/build.log" -Tail 30; exit $LASTEXITCODE }
Write-Output 'F8-78 registered tests'
ctest --test-dir $F878Build --show-only=json-v1 *> "$F878Evidence/registered-tests.json"
ctest --test-dir $F878Build --output-on-failure --no-tests=error -j 1 --output-junit "$F878Evidence/ctest.xml" *> "$F878Evidence/ctest.log"
$testCode = $LASTEXITCODE
Copy-Item -LiteralPath "$F878Build/Testing/Temporary/LastTest.log" -Destination "$F878Evidence/last-test.log"
Get-Content "$F878Evidence/ctest.log" -Tail 15
if ($testCode -ne 0) { exit $testCode }
Write-Output 'F8-78 relocated SDK'
& $F878Python tools/check_sdk_install.py --build-dir $F878Build --output "$F878Evidence/sdk" --config Release *> "$F878Evidence/sdk.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F878Evidence/sdk.log" -Tail 25; exit $LASTEXITCODE }
$sdk = "$F878Evidence/sdk/relocated-sdk"
$env:PATH = "$sdk/bin;" + $env:PATH
$capture = @('conformance/v1/realtime_device_capture.py','--runner',"$sdk/bin/parallel-mater-conformance.exe",
    '--driver-manifest',"$sdk/share/parallel-mater/drivers.d/parallel_mater_slang_cuda.json",
    '--validation-layer-manifest',"$sdk/share/parallel-mater/layers.d/parallel_mater_validation.json",
    '--runtime-variant','cuda-runtime','--target-id','windows-gtx1080-slang-cuda','--output',"$F878Evidence/capture")
@{executable=$F878Python; arguments=$capture; cuda_launch_blocking=$null} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F878Evidence/capture-command.json"
Write-Output 'F8-78 complete installed-public capture'
& $F878Python @capture *> "$F878Evidence/capture.log"
$captureCode = $LASTEXITCODE
@{exit_code=$captureCode; finished_at=[DateTimeOffset]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -Encoding utf8 "$F878Evidence/capture-result.json"
Get-Content "$F878Evidence/capture.log" -Tail 15
if ($captureCode -gt 1 -or -not (Test-Path -LiteralPath "$F878Evidence/capture/report.json")) { exit 2 }
Write-Output 'F8-78 capture complete; review original failures before acceptance'
