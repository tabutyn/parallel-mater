"""Package the evaluated F8-78 capture and verify each archive member."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f878-integration-evidence-20261103')
temporary = Path('C:/Users/tabut/Repos/ballroller-2026/.codex-tmp')
destination = root / 'docs/roadmap/evidence'
archive = destination / 'F8-78-WINDOWS-INTEGRATION.zip'
report_path = destination / 'F8-78-WINDOWS-INTEGRATION.json'
assert not archive.exists() and not report_path.exists()
report = json.loads((raw / 'integration-evaluation.json').read_text())
assert report['status'] == 'passed_revised_integration_contract'
assert report['clean_release']['passed'] == 146 and report['clean_release']['skipped'] == 0
assert len(report['relocated_sdk']['checks']) == 12
assert all(item['status'] == 'passed' for item in report['relocated_sdk']['checks'])

files = {}
for path in sorted(raw.rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(raw)
    if relative.parts[0] == 'sdk' and len(relative.parts) != 2:
        continue
    files[relative.as_posix()] = path
for name in ('f878-integration-env.ps1', 'f878-integration-run.ps1',
             'f878-integration-evaluate.py', 'f878-integration-package.py'):
    files['reproduce/' + name] = temporary / name

manifest = {}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for name, path in files.items():
        data = path.read_bytes()
        manifest[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        stream.writestr(name, data)
    stream.writestr('archive-members.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as stream:
    assert stream.testzip() is None
    assert set(stream.namelist()) == set(manifest) | {'archive-members.json'}
    for name, identity in manifest.items():
        data = stream.read(name)
        assert len(data) == identity['bytes']
        assert hashlib.sha256(data).hexdigest() == identity['sha256']
assert archive.stat().st_size < 99 * 1024 * 1024

classifications = {
    'api_abi': 'Byte-identical to the historical candidate closure.',
    'contract': 'Byte-identical frozen capability, numerical, performance and workload contracts.',
    'kernel': 'Includes accepted shared Slang ordering and transfer/batching repairs from F8-73.',
    'adapter_binding': 'Includes accepted managed metadata ownership, completion notifications and Metal adapter repairs.',
    'runtime': 'Includes accepted Windows ownership and shared-runtime/Metal staging repairs.',
    'schedule_telemetry': 'Includes accepted shared production-backend transfer and batching changes. Fresh scenario checks verify fixed advance, publication, recovery and work ledgers.',
    'public_oracle': 'Includes candidate bookkeeping and managed-auxiliary/validation-mode regression checks in the native runtime test. Frozen physical and timing limits retain their original values.',
    'work_budget': 'Managed-auxiliary coverage and validation-mode enabling in the native runtime test change this closure. Independent work-budget values and assertions remain preserved.',
    'gallery': 'Includes accepted shared reset/lifetime behavior and associated command/session tests.',
}
for closure in report['protected_closures']:
    closure['classification'] = classifications[closure['category']]
report['artifacts'] = {
    'archive': archive.relative_to(root).as_posix(), 'bytes': archive.stat().st_size,
    'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'files': len(manifest), 'all_member_hashes_verified': True,
    'contents': 'Complete raw capture, original and per-mode oracle results, all differential control failures, build/test/SDK logs, installed SDK file hashes, tested build hashes and exact reproduction scripts. SDK binaries can be rebuilt from the recorded source and commands.',
}
report_path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(report['artifacts'], indent=2))
