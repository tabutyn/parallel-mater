. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f877-final-env.ps1
if (Test-Path -LiteralPath $F877Build) { throw 'Retain previous build; use a fresh path' }
$env:PATH = "$F877Build;" + $env:PATH
$configure = @('-S',$F877Source,'-B',$F877Build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DBUILD_TESTING=ON',
    '-DCMAKE_CUDA_ARCHITECTURES=61','-DPARALLEL_MATER_BUILD_CUDA=ON','-DPARALLEL_MATER_BUILD_D3D12=OFF',
    '-DPARALLEL_MATER_BUILD_VULKAN=OFF','-DPARALLEL_MATER_BUILD_GALLERY=ON','-DPARALLEL_MATER_BUILD_CONFORMANCE=ON',
    '-DPARALLEL_MATER_BUILD_SLANG_MIRRORS=ON','-DPARALLEL_MATER_BUILD_SLANG_GEOMETRY_CONSTRAINTS=ON',
    '-DPARALLEL_MATER_WINDOWS_GALLERY_AUTO_DEPLOY=OFF',
    '-DFETCHCONTENT_SOURCE_DIR_PARALLEL_MATER_GLFW=D:/Repos/parallel-mater/build-d3d12-full/_deps/parallel_mater_glfw-src',
    "-DPython3_EXECUTABLE=$F877Python","-DPARALLEL_MATER_SLANGC_EXECUTABLE=$F826Slang")
@{executable='cmake'; arguments=$configure; build_directory_existed=$false} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F877Evidence/release-configure-command.json"
cmake @configure *> "$F877Evidence/release-configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F877Evidence/release-configure.log" -Tail 20; exit $LASTEXITCODE }
cmake --build $F877Build -j 4 *> "$F877Evidence/release-build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F877Evidence/release-build.log" -Tail 30; exit $LASTEXITCODE }
& $F877Python C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f877-final-identity.py release $F877Build
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
ctest --test-dir $F877Build --show-only=json-v1 *> "$F877Evidence/registered-tests.json"
ctest --test-dir $F877Build --output-on-failure --no-tests=error -j 1 --output-junit "$F877Evidence/release-ctest.xml" *> "$F877Evidence/release-ctest.log"
$code = $LASTEXITCODE
Copy-Item -LiteralPath "$F877Build/Testing/Temporary/LastTest.log" -Destination "$F877Evidence/release-last-test.log"
Get-Content "$F877Evidence/release-ctest.log" -Tail 12
if ($code -ne 0) { exit $code }
$sdkOutput = "$F877Evidence/sdk"
$sdkArguments = @('tools/check_sdk_install.py','--build-dir',$F877Build,'--output',$sdkOutput,'--config','Release')
@{executable=$F877Python; arguments=$sdkArguments} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F877Evidence/sdk-command.json"
& $F877Python @sdkArguments *> "$F877Evidence/sdk.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F877Evidence/sdk.log" -Tail 20; exit $LASTEXITCODE }
$sdk = "$sdkOutput/relocated-sdk"
$runner = "$sdk/bin/parallel-mater-conformance.exe"
$env:PATH = "$sdk/bin;" + $env:PATH
$env:PM_DRIVER_FILES = "$sdk/share/parallel-mater/drivers.d/parallel_mater_slang_cuda.json"
$env:PM_LAYER_FILES = "$sdk/share/parallel-mater/layers.d/parallel_mater_validation.json"
$results = @()
foreach ($mode in @('plain','validation')) {
    if ($mode -eq 'validation') { $env:PM_TEST_VALIDATION = '1' } else { Remove-Item Env:PM_TEST_VALIDATION -ErrorAction SilentlyContinue }
    $output = "$F877Evidence/installed-rigid-$mode"
    $arguments = @('--workload','rigid-wall','--warmup-ticks','600','--measured-ticks','7200','--root',$F877Source,'--output',$output)
    $command = [ordered]@{executable=$runner; arguments=$arguments; mode=$mode; cuda_launch_blocking=$null; source_revision=(git rev-parse HEAD); driver_manifest=$env:PM_DRIVER_FILES; validation_layer_manifest=$env:PM_LAYER_FILES}
    $command | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F877Evidence/installed-rigid-$mode-command.json"
    $watch = [Diagnostics.Stopwatch]::StartNew()
    & $runner @arguments *> "$F877Evidence/installed-rigid-$mode.log"
    $code = $LASTEXITCODE
    $watch.Stop()
    $results += @{command=$command; exit_code=$code; seconds=$watch.Elapsed.TotalSeconds}
    Get-Content "$F877Evidence/installed-rigid-$mode.log" -Tail 5
    if ($code -ne 0) { exit $code }
}
$results | ConvertTo-Json -Depth 6 | Set-Content -Encoding utf8 "$F877Evidence/installed-rigid-results.json"
Remove-Item Env:PM_TEST_VALIDATION -ErrorAction SilentlyContinue
