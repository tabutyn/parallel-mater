import hashlib
import json
import math
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f8-77-final-evidence-20261102')
helpers = Path('C:/Users/tabut/Repos/ballroller-2026/.codex-tmp')
destination = root / 'docs/roadmap/evidence'
stem = 'F8-77-WINDOWS-PUBLIC-COMPLETION-WAITS-V2'
revision = '701a3f12ef434381a5baa0b62a8f4a1473505a6a'
def read(name):
    return json.loads((raw / name).read_text(encoding='utf-8-sig'))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path, value):
    assert not path.exists(), f'Retain existing artifact: {path}'
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == revision
assert not subprocess.check_output(['git', 'status', '--porcelain']).strip()
assert not any((destination / (stem + suffix)).exists() for suffix in ['.json', '.zip', '.md'])
identity = read('release-identity.json')
assert identity['source_revision'] == revision and not identity['source_status']
cases = ET.parse(raw / 'release-ctest.xml').getroot().findall('testcase')
assert len(cases) == 146
assert all(c.get('status') == 'run' and c.find('failure') is None and c.find('skipped') is None for c in cases)
registered = read('registered-tests.json')
names = {c['name'] for c in registered['tests']}
before_provenance = read('before-provenance.json')
with zipfile.ZipFile(root / before_provenance['archive']['archive']) as archive:
    previous_names = {c['name'] for c in json.loads(archive.read('registered-current-tests.json'))['tests']}
assert len(previous_names) == 144 and previous_names <= names
assert names - previous_names == {'parallel-mater-cuda-completion-wait-plain', 'parallel-mater-cuda-completion-wait-validation'}
for mode in ['plain', 'validation']:
    test = next(t for t in registered['tests'] if t['name'] == f'parallel-mater-cuda-completion-wait-{mode}')
    properties = {p['name']: p['value'] for p in test['properties']}
    modifications = properties['ENVIRONMENT_MODIFICATION']
    expected = 'PM_TEST_VALIDATION=set:1' if mode == 'validation' else 'PM_TEST_VALIDATION=unset:'
    assert expected in modifications
    assert any(m.startswith('PATH=path_list_prepend:') for m in modifications)
    assert 'SKIP_RETURN_CODE' not in properties
    assert '--allow-no-device' not in test['command']
availability = read('availability-probe-results.json')
assert len(availability) == 6
assert all(r['exit_code'] == r['expected_exit_code'] for r in availability)
assert all(r['exit_code'] == (77 if r['availability'] == 'optional-no-device' else 0) for r in availability)
sdk = read('sdk/report.json')
assert sdk['source_revision'] == revision and not sdk['source_dirty'] and sdk['status'] == 'passed'
assert len(sdk['checks']) == 12 and all(c['status'] == 'passed' for c in sdk['checks'])
executions = read('installed-rigid-results.json')
assert len(executions) == 2 and all(e['exit_code'] == 0 and e['command']['cuda_launch_blocking'] is None for e in executions)
observations = {}
for mode in ['plain', 'validation']:
    before = read(f'before-rigid-{mode}.json')
    after = read(f'installed-rigid-{mode}/rigid-wall.json')
    assert before['counts'] == after['counts']
    for result in [before, after]:
        assert result['id'] == 'rigid-wall' and result['failed_ticks'] == 0
        assert result['warmup_ticks'] == 600 and result['measured_ticks'] == 7200
        assert not result['driver_private_state_used']
        assert all(len(values) == 7200 and all(math.isfinite(v) for v in values) for values in result['raw_samples'].values())
    observations[mode] = {label: {k: v for k, v in result.items() if k != 'raw_samples'}
                          for label, result in [('before', before), ('after', after)]}
audit = read('source-closure-audit.json')
assert audit['after_revision'] == revision
assert [c['category'] for c in audit['protected_closures'] if c['changed_by_F8_77']] == ['adapter_binding']
slang = read('slang-version-observation.json')
assert slang['exit_code'] == 0 and '2026.18' in slang['stdout'] + slang['stderr']
finite_probe = read('public-finite-probe-results.json')
assert len(finite_probe) == 2 and all(p['exit_code'] == 0 for p in finite_probe)
machine = read('machine.json')
machine['slang'] = (slang['stdout'] + slang['stderr']).strip()
machine['slang_supported_version_observation'] = slang

tools = raw / 'reproduction-tools'
assert not tools.exists()
tools.mkdir()
for name in ['f826-env.ps1', 'f877-env.ps1', 'f877-final-env.ps1', 'f877-final-release.ps1', 'f877-final-identity.py', 'f877-final-audit.py', 'f877-final-finite-probe.ps1', 'f877-availability-probe.ps1', 'f877-final-package.py']:
    shutil.copy2(helpers / name, tools / name)
members = {p.relative_to(raw).as_posix(): p for p in raw.iterdir()
           if p.is_file() and (p.suffix.lower() in ['.json', '.log', '.xml', '.patch'] or p.name in ['public-finite-probe.cpp', 'zero-device-driver.cpp'])
           and not p.name.startswith('package')}
for directory in ['installed-rigid-plain', 'installed-rigid-validation', 'reproduction-tools']:
    for p in (raw / directory).rglob('*'):
        if p.is_file():
            members[p.relative_to(raw).as_posix()] = p
for p in (raw / 'sdk').iterdir():
    if p.is_file():
        members[p.relative_to(raw).as_posix()] = p
assert not any(p.suffix.lower() in ['.exe', '.dll', '.pdb', '.obj', '.lib'] for p in members.values())
member_manifest = {name: {'sha256': sha(p), 'bytes': p.stat().st_size} for name, p in sorted(members.items())}
manifest_path = raw / 'SHA256SUMS.json'
dump(manifest_path, member_manifest)
archive_path = destination / (stem + '.zip')
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, path in sorted(members.items()):
        archive.write(path, name)
    archive.write(manifest_path, 'SHA256SUMS.json')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == item['sha256'] for name, item in member_manifest.items())
report = {
    'schema': 'parallel-mater-public-completion-repair/v1', 'task': 'F8-77', 'status': 'passed',
    'captured_at': datetime.now(timezone.utc).isoformat(),
    'claim_pr': 'https://github.com/tabutyn/parallel-mater/pull/647', 'lease_token': '42db680c-e3ca-42a5-b971-1bfeac890373',
    'scope': 'Public fence/timeline completion notification and timeout semantics; no fixed-tick or physics change.',
    'before': before_provenance, 'after': identity, 'machine': machine,
    'release_binary_inventory': {'artifact': 'release-binary-hashes.json', 'sha256': sha(raw / 'release-binary-hashes.json'),
                                  'count': len(read('release-binary-hashes.json'))},
    'test_harness_corrections': {
        'initial_report': 'docs/roadmap/evidence/F8-77-WINDOWS-PUBLIC-COMPLETION-WAITS.json',
        'initial_ci': 'https://github.com/tabutyn/parallel-mater/actions/runs/41514424323/attempts/3',
        'optional_hardware': 'Hosted Metal enumeration returned zero devices. Optional Metal/Vulkan/D3D12 tests now explicitly allow exit 77 only after successful zero-device enumeration; failures on an available device still fail. Required CUDA, CPU and host tests have no skip code and no allow-no-device argument.',
        'windows_modes': 'Appending the Windows DLL PATH modification preserves each API test mode. Earlier API validation-case metadata had been overwritten by PATH setup; this fresh suite verifies the actual set/unset mode and keeps CUDA strict.',
        'historical_scope': 'Initial raw reports and timings remain preserved. Earlier standalone validation probes and conformance captures explicitly set their mode and were unaffected by the CTest metadata issue. This fresh capture supersedes registered-test mode acceptance.',
        'availability_regressions': availability,
    },
    'implementation': {
        'ownership': 'The existing per-device submission queue owns a completion epoch and condition variable. Native work drains, captures retire and completion status publishes before queue bookkeeping advances the epoch and notifies all public waiters.',
        'no_lost_wake': 'Observe epoch before checking fence/timeline predicates, then wait under the same queue mutex only while the epoch is unchanged. Completion before blocking is retained; unrelated wakes recheck the original deadline and predicates.',
        'timeout': 'Zero-time polls retain status/error ordering. Finite calls use one steady-clock deadline; unsigned durations outside the representable clock range saturate without signed overflow. Infinite calls block on notification without timed polling.',
        'preserved': 'Queue admission, command execution, error handling, native drains, handle checks, timeline ordering, reset/resource lifetime and worker readiness scheduling remain unchanged. No busy-spin loop, global timer/power policy or per-kernel synchronization is added.',
    },
    'clean_release_tests': {'total': 146, 'passed': 146, 'failed': 0, 'skipped': 0, 'previous_144_retained': True,
                             'added': sorted(names - previous_names),
                             'focused': 'Extended submission-queue tests cover completion before blocking, expired deadline, simultaneous waiters and capture retirement. Public suites cover pending/ready, zero/finite/large/infinite timeout, any/all, foreign/null handles, simultaneous waiters, timeline ordering and reset. Existing async suite adds failed-timeline and ready-plus-failed-fence errors without removing prior checks.'},
    'relocated_sdk': {k: v for k, v in sdk.items() if k != 'sdk_sha256'},
    'public_sdk_finite_probe': {'source': read('public-finite-probe-source.json'), 'executions': finite_probe,
                                'purpose': 'Independent consumer compiled only against relocated SDK headers/import library; exercises ordinary finite wake and finite expiry in both modes, alongside the registered unsigned-range-edge and infinite wait cases.'},
    'installed_public_workload': {'id': 'rigid-wall', 'modes': ['plain', 'validation'], 'warmup_ticks': 600,
                                  'measured_ticks': 7200, 'failed_ticks': 0, 'all_raw_samples_retained': True,
                                  'executions': executions, 'observations': observations},
    'source_audit': audit,
    'limitations': [
        'These are normal observations on one physical Windows GTX 1080; they do not establish the complete five-workload or five-negative-control performance acceptance.',
        'Host critical-path and native GPU statistics are separate observations; their percentile difference is not a measured pure-wait interval. No stalls were filtered and no global power/timer policy was changed.',
        'F8-78 still requires the complete frozen Windows performance capture and five negative controls in both modes. F8-74 waits for that task and all other accepted repairs before refreeze.',
        'Candidate v9 remains immutable failed history. Adapter-binding closure changes require refreeze; this task does not qualify F8-26 or any other physical device.',
        'The retained F8-76 shorter status/yield diagnostic remains explicitly non-qualification history and is not used instead of either full 7200-sample baseline.'
    ],
    'artifacts': {'archive': archive_path.relative_to(root).as_posix(), 'sha256': sha(archive_path),
                  'bytes': archive_path.stat().st_size, 'files': len(members) + 1,
                  'member_manifest': 'SHA256SUMS.json', 'member_manifest_sha256': sha(manifest_path),
                  'verification': 'ZIP CRC and every archived member SHA-256 verified; binaries are identified by hashes without binary payloads.'},
}
report_path = destination / (stem + '.json')
dump(report_path, report)
rows = '\n'.join(f"| {mode} | {observations[mode]['before']['timings']['physics_ms']['p95']:.4f} | {observations[mode]['after']['timings']['physics_ms']['p95']:.4f} | {observations[mode]['before']['timings']['gpu_ms']['p95']:.4f} | {observations[mode]['after']['timings']['gpu_ms']['p95']:.4f} |" for mode in ['plain', 'validation'])
notes = f'''# F8-77: Windows public completion notifications

Public fence and timeline waits now block on submission completion notifications
instead of 50-microsecond polling sleeps. The existing queue publishes its epoch
after native work drains, captures retire, completion status publishes and queue
bookkeeping completes. Observing the epoch before checking public predicates
prevents a completion between checking and blocking from being lost. A single
steady-clock deadline preserves finite timeout budgets across unrelated wakes.

Exact clean Release source: `{revision}`, tree `{identity['source_tree']}`.
All **146 registered tests pass with zero skips**, retaining every prior 144 test.
Focused queue/public/async regressions cover ownership retirement, notification
races, simultaneous waiters, ready/pending states, zero/finite/large/infinite
timeout, wait-any/all, timelines, validation/foreign handles and failed work.
The relocated SDK passes all 12 checks.

The corrected harness explicitly permits no-device status only for optional
Metal/Vulkan/D3D12 cases. A valid device still executes every assertion; CUDA,
CPU and host cases stay strict. A local zero-device mock verifies optional
unavailability in both modes, while optional-flag executions on the real CUDA
device still run and pass the complete fixture. Windows DLL PATH setup now
appends rather than overwrites per-test mode settings; this fresh registration
records the actual validation set/unset operations alongside DLL lookup.
The original raw evidence remains preserved. This V2 report supersedes its
registered-test mode acceptance; standalone timing/validation captures were
unaffected by the earlier CTest metadata issue.
An independent consumer compiled only against relocated SDK headers/import library
also passes ordinary finite wake and finite-expiry checks in both modes.

Normal installed-public rigid-wall samples use unchanged counts, 600 warmup and
7,200 measured ticks, with no failed ticks and no discarded stalls:

| Mode | Before physics p95 ms | After physics p95 ms | Before GPU p95 ms | After GPU p95 ms |
| --- | ---: | ---: | ---: | ---: |
{rows}

The baseline is the complete retained F8-76 capture, compiled at
`{before_provenance['compiled_source_revision']}`. Its compiled-source identity
is distinct from the later claim checkout, which adds only documentation/task
metadata. The shorter consumer status/yield diagnostic is retained as historical
diagnosis and does not replace these normal full samples. Physics critical-path
time and native GPU time remain separate measurements; percentile differences
are not a measured pure-wait interval.

Only the adapter-binding protected closure changes. API/ABI, shared kernels,
runtime, fixed-tick schedule/telemetry, contracts, public oracle, work budgets and
Gallery closures are byte-identical to the accepted ownership repair. There is
no global timer/power change, busy-spin workaround, new GPU drain, physics fork,
workload reduction or raised budget. Existing worker dependency scheduling is
unchanged; this task replaces public completion polling.

Reviewable report: [{stem}.json]({stem}.json). Raw samples, exact commands,
source diff, test logs/JUnit, SDK report/hashes, device/compiler/memory identities
and reproduction helpers: [{stem}.zip]({stem}.zip), SHA-256
`{report['artifacts']['sha256']}`. Every archive member was hash-verified.

F8-78 still owns complete five-workload/five-negative-control acceptance at the
unchanged 10 ms physics p95, 16.667 ms frame p95 and 0.99 realtime-rate gates.
F8-74 waits for successful follow-up evidence before freezing a replacement.
Candidate v9 is unchanged; this is not final F8-26 qualification.
'''
(destination / (stem + '.md')).write_text(notes, encoding='utf-8', newline='\n')
print(json.dumps({'report': report_path.relative_to(root).as_posix(), 'report_sha256': sha(report_path),
                  'archive': report['artifacts'], 'tests': 146,
                  'timings': {mode: {label: result['timings'] for label, result in values.items()} for mode, values in observations.items()}}, indent=2))
