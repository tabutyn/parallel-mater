. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f877-final-env.ps1
if (-not (Test-Path -LiteralPath "$F877Evidence/installed-rigid-results.json")) { throw 'Finish timing capture before compiling/running extra probes' }
$sdk = "$F877Evidence/sdk/relocated-sdk"
$env:PATH = "$sdk/bin;" + $env:PATH
$env:PM_DRIVER_FILES = "$sdk/share/parallel-mater/drivers.d/parallel_mater_slang_cuda.json"
$env:PM_LAYER_FILES = "$sdk/share/parallel-mater/layers.d/parallel_mater_validation.json"
& $F877Python -c 'import pathlib,json,hashlib; p=pathlib.Path("D:/Repos/parallel-mater-f8-77-final-evidence-20261102"); original=pathlib.Path("tests/api/completion_wait_tests.cpp").read_text(); assert original.count("UINT64_MAX - 1U")==1 and original.count("1000U")==3; source=original.replace("UINT64_MAX - 1U","10000000000ULL").replace("1000U","1000000U"); out=p/"public-finite-probe.cpp"; assert not out.exists(); out.write_text(source,encoding="utf-8",newline="\n"); metadata={"canonical_source":"tests/api/completion_wait_tests.cpp","canonical_sha256":hashlib.sha256(original.encode()).hexdigest(),"probe_sha256":hashlib.sha256(out.read_bytes()).hexdigest(),"only_changes":"10-second regular finite wake instead of the unsigned-range edge, and 1-millisecond finite expiration instead of 1 microsecond; no latency threshold or production/measurement change.","public_sdk_only":True}; (p/"public-finite-probe-source.json").write_text(json.dumps(metadata,indent=2)+"\n",encoding="utf-8",newline="\n")'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$exe = "$F877Evidence/public-finite-probe.exe"
$arguments = @('/nologo','/std:c++20','/EHsc','/O2','/MD',"/I$sdk/include","$F877Evidence/public-finite-probe.cpp", "/Fe$exe", "/Fo$F877Evidence/public-finite-probe.obj",'/link',"/LIBPATH:$sdk/lib",'parallel-mater.lib')
@{executable=(Get-Command cl).Source; arguments=$arguments; private_runtime_includes=$false} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F877Evidence/public-finite-probe-build-command.json"
cl @arguments *> "$F877Evidence/public-finite-probe-build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F877Evidence/public-finite-probe-build.log" -Tail 10; exit $LASTEXITCODE }
$results = @()
foreach ($mode in @('plain','validation')) {
    if ($mode -eq 'validation') { $env:PM_TEST_VALIDATION='1' } else { Remove-Item Env:PM_TEST_VALIDATION -ErrorAction SilentlyContinue }
    & $exe *> "$F877Evidence/public-finite-probe-$mode.log"
    $code = $LASTEXITCODE
    $results += @{mode=$mode; exit_code=$code; executable=$exe; executable_sha256=(Get-FileHash -Algorithm SHA256 $exe).Hash.ToLowerInvariant(); driver_manifest=$env:PM_DRIVER_FILES; validation_layer_manifest=$env:PM_LAYER_FILES; cuda_launch_blocking=$null}
    Get-Content "$F877Evidence/public-finite-probe-$mode.log"
    if ($code -ne 0) { exit $code }
}
$results | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F877Evidence/public-finite-probe-results.json"
Remove-Item Env:PM_TEST_VALIDATION -ErrorAction SilentlyContinue
