. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f877-env.ps1
$F877Build = 'D:/Repos/parallel-mater-f8-77-final-build-20261102'
$F877Evidence = 'D:/Repos/parallel-mater-f8-77-final-evidence-20261102'
New-Item -ItemType Directory -Path $F877Evidence -Force | Out-Null
