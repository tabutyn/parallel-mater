. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f877-final-env.ps1
if (-not (Test-Path -LiteralPath "$F877Evidence/installed-rigid-results.json")) { throw 'Finish timing captures before extra probes' }
$sdk = "$F877Evidence/sdk/relocated-sdk"
$env:PATH = "$sdk/bin;" + $env:PATH
$env:PM_LAYER_FILES = "$sdk/share/parallel-mater/layers.d/parallel_mater_validation.json"
& $F877Python -c 'import pathlib,json,hashlib; raw=pathlib.Path("D:/Repos/parallel-mater-f8-77-final-evidence-20261102"); source=pathlib.Path("tests/api/mock_driver.cpp").read_text(); start=source.index("PmResult mock_enumerate_physical_devices("); end=source.index("void mock_get_properties(",start); replacement="PmResult mock_enumerate_physical_devices(PmInstance instance, std::uint32_t *count, PmPhysicalDevice *) {\n    if (instance == nullptr || count == nullptr) return PM_ERROR_INVALID_ARGUMENT;\n    *count = 0U;\n    return PM_SUCCESS;\n}\n\n"; out=raw/"zero-device-driver.cpp"; expected=source[:start]+replacement+source[end:]; assert out.read_text()==expected; assert json.loads((raw/"zero-device-source.json").read_text())["fixture_sha256"]==hashlib.sha256(out.read_bytes()).hexdigest()'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$dll = "$F877Evidence/zero-device-driver.dll"
$compile = @('/nologo','/LD','/std:c++20','/EHsc','/O2','/MD','/DPARALLEL_MATER_DRIVER_IMPLEMENTATION=1',"/I$sdk/include","$F877Evidence/zero-device-driver.cpp", "/Fe$dll", "/Fo$F877Evidence/zero-device-driver.obj",'/link',"/IMPLIB:$F877Evidence/zero-device-driver.lib")
@{executable=(Get-Command cl).Source; arguments=$compile; prior_attempt='zero-device-build.log'; correction='Match the canonical mock target PARALLEL_MATER_DRIVER_IMPLEMENTATION=1 export definition.'} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F877Evidence/zero-device-build-fixed-command.json"
cl @compile *> "$F877Evidence/zero-device-build-fixed.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F877Evidence/zero-device-build-fixed.log" -Tail 15; exit $LASTEXITCODE }
& $F877Python -c 'import pathlib,json; raw=pathlib.Path("D:/Repos/parallel-mater-f8-77-final-evidence-20261102"); p=raw/"zero-device.json"; assert not p.exists(); j=json.loads((raw/"sdk/relocated-sdk/share/parallel-mater/drivers.d/parallel_mater_slang_cuda.json").read_text()); j["PMD"]["library_path"]=str(raw/"zero-device-driver.dll"); p.write_text(json.dumps(j,indent=2)+"\n",encoding="utf-8",newline="\n")'
$exe = "$F877Build/tests/api/parallel-mater-completion-wait-tests.exe"
$results = @()
foreach ($mode in @('plain','validation')) {
    if ($mode -eq 'validation') { $env:PM_TEST_VALIDATION='1' } else { Remove-Item Env:PM_TEST_VALIDATION -ErrorAction SilentlyContinue }
    foreach ($availability in @('strict-cuda','optional-cuda','optional-no-device')) {
        $arguments = @()
        $expected = 0
        if ($availability -eq 'optional-no-device') {
            $env:PM_DRIVER_FILES = "$F877Evidence/zero-device.json"
            $arguments = @('--allow-no-device')
            $expected = 77
        } else {
            $env:PM_DRIVER_FILES = "$sdk/share/parallel-mater/drivers.d/parallel_mater_slang_cuda.json"
            if ($availability -eq 'optional-cuda') { $arguments = @('--allow-no-device') }
        }
        & $exe @arguments *> "$F877Evidence/availability-$availability-$mode.log"
        $code = $LASTEXITCODE
        $results += @{mode=$mode; availability=$availability; arguments=$arguments; exit_code=$code; expected_exit_code=$expected; executable_sha256=(Get-FileHash -Algorithm SHA256 $exe).Hash.ToLowerInvariant(); manifest=$env:PM_DRIVER_FILES}
        Get-Content "$F877Evidence/availability-$availability-$mode.log"
        if ($code -ne $expected) { exit 1 }
    }
}
$results | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F877Evidence/availability-probe-results.json"
Remove-Item Env:PM_TEST_VALIDATION -ErrorAction SilentlyContinue
