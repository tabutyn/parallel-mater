$ErrorActionPreference = 'Stop'
$F827V10Source = 'C:/Users/tabut/Repos/ballroller-2026/.codex-worktrees/parallel-mater-f827-v10-20261104'
$F827V10Frozen = 'C:/Users/tabut/Repos/ballroller-2026/.codex-worktrees/parallel-mater-f826-v10-source-20261104'
$F827V10Build = 'D:/Repos/parallel-mater-f827-v10-build-20261104'
$F827V10Evidence = 'D:/Repos/parallel-mater-f827-v10-evidence-20261104'
$F827V10Python = 'C:/Users/tabut/AppData/Local/Programs/Python/Python313/python.exe'
& 'C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation | Out-Null
$env:PATH = "$F827V10Build/Release;C:/Users/tabut/AppData/Local/Programs/Python/Python313;" + $env:PATH
$env:GIT_CONFIG_COUNT = '3'
$env:GIT_CONFIG_KEY_0 = 'safe.directory'
$env:GIT_CONFIG_VALUE_0 = $F827V10Source
$env:GIT_CONFIG_KEY_1 = 'safe.directory'
$env:GIT_CONFIG_VALUE_1 = $F827V10Frozen
$env:GIT_CONFIG_KEY_2 = 'core.autocrlf'
$env:GIT_CONFIG_VALUE_2 = 'false'
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
foreach ($name in @('CUDA_LAUNCH_BLOCKING','PM_DRIVER_FILES','PM_LAYER_FILES','PM_ENABLE_LAYERS','PM_TEST_VALIDATION')) {
    Remove-Item "Env:$name" -ErrorAction SilentlyContinue
}
Set-Location -LiteralPath $F827V10Source
