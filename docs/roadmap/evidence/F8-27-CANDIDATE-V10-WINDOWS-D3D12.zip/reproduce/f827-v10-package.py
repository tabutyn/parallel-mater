"""Package the failed candidate-v10 Windows D3D12 qualification evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone
import zipfile

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f827-v10-evidence-20261104')
temporary = Path('C:/Users/tabut/Repos/ballroller-2026/.codex-tmp')
destination = root / 'docs/roadmap/evidence'
archive = destination / 'F8-27-CANDIDATE-V10-WINDOWS-D3D12.zip'
output = destination / 'F8-27-CANDIDATE-V10-WINDOWS-D3D12.json'
summary = destination / 'F8-27-CANDIDATE-V10-WINDOWS-D3D12.md'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()


assert not archive.exists() and not output.exists() and not summary.exists()
assert not git('status', '--porcelain')
task_path = root / 'docs/roadmap/tasks/F8-27.json'
task = read(task_path)
canonical = json.loads(git('show', 'origin/main:docs/roadmap/tasks/F8-27.json'))
assert task == canonical
assert task['status'] == 'leased'
assert task['lease']['token'] == '1c6c2ca1-335f-469b-928e-11da3c9bb1a7'
assert git('rev-parse', '--abbrev-ref', 'HEAD') == task['lease']['branch']

report = read(raw / 'qualification-evaluation.json')
assert report['status'] == 'failed_candidate_capability_reduction'
assert report['candidate']['manifest_sha256'] == digest(root / report['candidate']['manifest'])
assert report['candidate']['source_revision'] == '5bacbe2b1e0fbfad565fb9477bb6873396e31d5d'
assert report['registered_tests']['passed'] == 135
assert len(report['registered_tests']['skipped']) == 2
assert report['failure']['expected_capability_rows'] == 49
assert report['failure']['advertised_capability_rows'] == 46
assert len(report['failure']['missing_capabilities']) == 3
assert len(report['partial_capture']['completed_workloads']) == 4
assert report['partial_capture']['measured_ticks_completed'] == 28800
assert report['partial_capture']['failed_workload']['id'] == 'six-family-mixed'
assert report['installed_gallery']['d3d12_failed_scenes'] == ['peg-paint']
assert report['installed_gallery']['cuda_preservation_passed']

files = {}
for path in sorted(raw.rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(raw)
    if relative.parts[0] == 'gallery-install-stage':
        continue
    if relative.parts[0] == 'sdk' and len(relative.parts) != 2:
        continue
    files[relative.as_posix()] = path
reproduction = (
    'f827-v10-env.ps1', 'f827-v10-prepare.py', 'f827-v10-sdk-metadata.py',
    'f827-v10-run.ps1', 'f827-v10-gallery-stage.py', 'f827-v10-install-gallery.ps1',
    'f827-v10-gallery-audit.py', 'f827-v10-preview.py', 'f827-v10-failure.py',
    'f827-v10-package.py',
)
for name in reproduction:
    files['reproduce/' + name] = temporary / name
members = {}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for name, path in files.items():
        data = path.read_bytes()
        members[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        stream.writestr(name, data)
    stream.writestr('archive-members.json', json.dumps(members, indent=2) + '\n')
with zipfile.ZipFile(archive) as stream:
    assert stream.testzip() is None
    assert set(stream.namelist()) == set(members) | {'archive-members.json'}
    for name, identity in members.items():
        data = stream.read(name)
        assert len(data) == identity['bytes']
        assert hashlib.sha256(data).hexdigest() == identity['sha256']
assert archive.stat().st_size < 99 * 1024 * 1024

report['recorded_at'] = datetime.now(timezone.utc).isoformat()
report['acceptance_contract'] = {
    'card_sha256': digest(task_path), 'acceptance': task['acceptance'],
    'metadata_revision': git('rev-parse', 'HEAD'),
    'retained_evaluation_sha256': digest(raw / 'qualification-evaluation.json'),
}
report['candidate']['active_pointer_sha256'] = digest(
    root / 'conformance/v1/qualification/active-realtime-candidate.json')
report['artifacts'] = {
    'archive': archive.relative_to(root).as_posix(),
    'bytes': archive.stat().st_size,
    'sha256': digest(archive),
    'files': len(members),
    'all_member_hashes_verified': True,
    'contents': 'Exact-source build and test identity, partial original capture, targeted plain and validation reproductions, installed Gallery audit, raw samples, images, deployment hashes, logs and reproduction scripts.',
}
output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')

workloads = report['partial_capture']['completed_workloads']
rows = '\n'.join(
    f"| {name} | {value['timings']['physics_ms']['p50']:.4f} | "
    f"{value['timings']['physics_ms']['p95']:.4f} | {value['timings']['physics_ms']['p99']:.4f} |"
    for name, value in workloads.items())
text = f"""# F8-27 candidate v10 Windows D3D12 qualification

Candidate `realtime-single-step-v1-5bacbe2` fails the Windows D3D12 integration gate. The result uses exact source `5bacbe2b1e0fbfad565fb9477bb6873396e31d5d`, tree `67f5088c2e9f50938c55856e3683326e42675310`, and manifest SHA-256 `29e051d94a89a39d51c2128b212165d60da6da7de4b2c107a72ae7cc5b77f20a` on the registered GTX 1080 with NVIDIA driver 582.66.

## Decisive failure

The frozen contract requires 49 interaction capability rows and forbids capability reduction. D3D12 advertises 46. It omits separate-system equal-material fluid-fluid contact, pressure, and viscosity. The same missing `liquidLiquidCoupling` feature causes two registered tests to skip and rejects the required `six-family-mixed` workload before its first tick.

The original plain capture exits 2 after four workloads complete. Targeted plain and validation executions both reproduce exit 2 with `no physical device supports workload six-family-mixed`. This is a capability and workload-coverage failure. It is not a numeric timing miss covered by F9-07 or F9-08.

## Completed evidence

- Fresh Visual Studio 2022 Release build produced 573 hashed binaries, manifests, reflection records, and embedded DXIL artifacts. All nine frozen source closures match.
- Registered execution passed 135 of 137 tests. The fluid-pair graph lifecycle and fluid-pair quality tests returned the configured skip code 77.
- SDK relocation and independent consumer checks passed 12 of 12.
- Plain mode completed all 30 public cases and executed all 12 scenario fixtures. Aggregate oracle evaluation did not run because sustained workload execution failed.
- `rigid-wall`, `fluid-rigid`, `deformable-mixed`, and `smoke-coupled` each completed 600 warmup and 7,200 measured ticks with zero failed ticks. All 115,200 raw timing values remain in the archive.

| Completed workload | Physics p50 ms | Physics p95 ms | Physics p99 ms |
|---|---:|---:|---:|
{rows}

These timing samples are retained as partial evidence. They do not qualify performance after the non-timing integration failure.

## Installed Gallery

The managed candidate-v10 installation contains the fresh D3D12 runtime and the hash-verified candidate-v10 CUDA runtime from F8-26. All installed hashes and the Start-menu target were checked.

Twenty-seven of 28 D3D12 headless scenes passed 240 frames with one physics step per frame. PEG PAINT completed 240 frames with zero capacity overflows, then failed with 0 painted texels against 100 required. That scene-quality class remains deferred to F9. Six-frame D3D12 interactive startup completed. The retained interactive image shows the timing overlay on a black scene frame, while the headless rigid image contains rendered scene geometry. A six-frame CUDA check also passed after the combined install.

## Evidence

- [Structured failed qualification report](F8-27-CANDIDATE-V10-WINDOWS-D3D12.json)
- [Raw evidence archive](F8-27-CANDIDATE-V10-WINDOWS-D3D12.zip)

Archive SHA-256 is `{report['artifacts']['sha256']}`. All {len(members)} member hashes and archive CRC checks pass. Archive size is {archive.stat().st_size:,} bytes.
"""
summary.write_text(text, encoding='utf-8', newline='\n')
print(json.dumps({'status': report['status'], 'artifacts': report['artifacts']}, indent=2))
