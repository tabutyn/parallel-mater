"""Install immutable v10 freeze metadata beside the exact-source SDK producer."""
import hashlib
import json
from pathlib import Path
import shutil

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f827-v10-evidence-20261104')
sdk = raw / 'sdk/relocated-sdk'
report = json.loads((raw / 'sdk/report.json').read_text(encoding='utf-8-sig'))
assert report['status'] == 'passed'
assert report['source_revision'] == '5bacbe2b1e0fbfad565fb9477bb6873396e31d5d'
assert len(report['checks']) == 12 and all(row['status'] == 'passed' for row in report['checks'])
for name, expected in report['sdk_sha256'].items():
    assert hashlib.sha256((sdk / name).read_bytes()).hexdigest() == expected, name
changes = []
for name in ('active-realtime-candidate.json', 'realtime-candidate-v10.json'):
    source = root / 'conformance/v1/qualification' / name
    target = sdk / 'share/parallel-mater/conformance/v1/qualification' / name
    before = hashlib.sha256(target.read_bytes()).hexdigest() if target.exists() else None
    shutil.copyfile(source, target)
    after = hashlib.sha256(target.read_bytes()).hexdigest()
    changes.append({'path': target.relative_to(sdk).as_posix(), 'before': before, 'after': after})
assert changes[1]['after'] == '29e051d94a89a39d51c2128b212165d60da6da7de4b2c107a72ae7cc5b77f20a'
for relative in ('conformance/v1/realtime_device_capture.py', 'conformance/v1/realtime_device_suite.py',
                 'conformance/v1/qualification/realtime-profile-v1.json',
                 'conformance/v1/realtime/oracle-suite-v1.json',
                 'conformance/v1/realtime/scenario-fixtures-v1.json'):
    source = root / relative
    target = sdk / 'share/parallel-mater' / relative
    assert source.read_bytes() == target.read_bytes(), relative
metadata = {
    'changes': changes,
    'execution_policy': 'Install immutable candidate-v10 manifest and routing before execution. Preserve producer, validator, fixtures, numerical and workload contracts, and native binaries.',
}
(raw / 'sdk-freeze-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Verified exact-source SDK with candidate-v10 freeze metadata')
