"""Verify the F8-27 lease, frozen source, build inputs and generated artifacts."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

root = Path.cwd()
frozen = Path('C:/Users/tabut/Repos/ballroller-2026/.codex-worktrees/parallel-mater-f826-v10-source-20261104')
build = Path('D:/Repos/parallel-mater-f827-v10-build-20261104')
raw = Path('D:/Repos/parallel-mater-f827-v10-evidence-20261104')
expected_revision = '5bacbe2b1e0fbfad565fb9477bb6873396e31d5d'
expected_tree = '67f5088c2e9f50938c55856e3683326e42675310'
expected_manifest = '29e051d94a89a39d51c2128b212165d60da6da7de4b2c107a72ae7cc5b77f20a'
expected_token = '1c6c2ca1-335f-469b-928e-11da3c9bb1a7'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(directory, *args):
    return subprocess.check_output(['git', '-C', str(directory), *args], text=True).strip()


task = read(root / 'docs/roadmap/tasks/F8-27.json')
canonical = json.loads(git(root, 'show', 'origin/main:docs/roadmap/tasks/F8-27.json'))
assert task == canonical
assert task['status'] == 'leased' and task['lease']['token'] == expected_token
assert git(root, 'rev-parse', '--abbrev-ref', 'HEAD') == task['lease']['branch']
assert datetime.now(timezone.utc) < datetime.fromisoformat(task['lease']['expires_at'].replace('Z', '+00:00'))
assert not git(root, 'status', '--porcelain')
assert git(frozen, 'rev-parse', 'HEAD') == expected_revision
assert git(frozen, 'rev-parse', 'HEAD^{tree}') == expected_tree
assert not git(frozen, 'status', '--porcelain')
candidate_path = root / 'conformance/v1/qualification/realtime-candidate-v10.json'
assert digest(candidate_path) == expected_manifest
candidate = read(candidate_path)
assert candidate['source']['revision'] == expected_revision
assert candidate['source']['tree'] == expected_tree

cache = (build / 'CMakeCache.txt').read_text(encoding='utf-8-sig', errors='replace')
required_cache = {
    'BUILD_TESTING:BOOL': 'ON',
    'PARALLEL_MATER_BUILD_CUDA:BOOL': 'OFF',
    'PARALLEL_MATER_BUILD_D3D12:BOOL': 'ON',
    'PARALLEL_MATER_BUILD_VULKAN:BOOL': 'OFF',
    'PARALLEL_MATER_BUILD_GALLERY:BOOL': 'ON',
    'PARALLEL_MATER_BUILD_SCENE_SDK:BOOL': 'ON',
    'PARALLEL_MATER_BUILD_CONFORMANCE:BOOL': 'ON',
    'PARALLEL_MATER_BUILD_SLANG_CPU_DRIVER:BOOL': 'OFF',
    'PARALLEL_MATER_BUILD_SLANG_MIRRORS:BOOL': 'ON',
    'PARALLEL_MATER_BUILD_SLANG_GEOMETRY_CONSTRAINTS:BOOL': 'ON',
    'PARALLEL_MATER_WINDOWS_GALLERY_AUTO_DEPLOY:BOOL': 'OFF',
}
for name, value in required_cache.items():
    assert f'{name}={value}' in cache, name

sys.path.insert(0, str(root / 'tools'))
spec = importlib.util.spec_from_file_location('f827_candidate_checker', root / 'tools/check_realtime_candidate_v10.py')
checker = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = checker
spec.loader.exec_module(checker)
requested = tuple((item['category'], tuple(item['patterns']))
                  for item in candidate['source']['protected_closures'])
tracked_closures = checker.revision_closure_identities(
    str(frozen), expected_revision, requested)
closures = []
for closure in candidate['source']['protected_closures']:
    count, sha = tracked_closures[closure['category']]
    assert count == closure['file_count'] and sha == closure['sha256'], closure['category']
    closures.append({'category': closure['category'], 'file_count': count, 'sha256': sha})

patterns = (
    '**/Release/*.exe', '**/Release/*.dll', '**/Release/*.pdb',
    'Release/manifests/**/*.json', 'generated/d3d12/**/*', 'generated/slang/dxil/**/*',
)
artifacts = {}
for pattern in patterns:
    for path in sorted(build.glob(pattern)):
        if path.is_file():
            name = path.relative_to(build).as_posix()
            artifacts[name] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
assert 'Release/parallel_mater_driver_slang_d3d12.dll' in artifacts
assert 'Release/Parallel-Mater.exe' in artifacts
assert 'Release/parallel-mater-conformance.exe' in artifacts
assert 'Release/manifests/portable/slang-d3d12.json' in artifacts
assert any(name.endswith('.dxil') for name in artifacts)

identity = {
    'captured_at': datetime.now(timezone.utc).isoformat(),
    'task': 'F8-27',
    'lease': task['lease'],
    'claim_pr': 'https://github.com/tabutyn/parallel-mater/pull/671',
    'harness_revision': git(root, 'rev-parse', 'HEAD'),
    'harness_tree': git(root, 'rev-parse', 'HEAD^{tree}'),
    'harness_clean': True,
    'source_revision': expected_revision,
    'source_tree': expected_tree,
    'candidate_id': candidate['id'],
    'candidate_manifest_sha256': expected_manifest,
    'exact_source_ci_run': 41708083151,
    'build_directory': str(build),
    'configure_command': read(raw / 'configure-command.json'),
    'configure_log_sha256': digest(raw / 'configure.log'),
    'build_command': read(raw / 'build-command.json'),
    'build_log_sha256': digest(raw / 'build.log'),
    'cmake_cache_sha256': digest(build / 'CMakeCache.txt'),
    'required_cache': required_cache,
    'protected_closures': closures,
    'build_artifacts': artifacts,
}
path = raw / 'identity.json'
assert not path.exists(), path
path.write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
print(f'Verified {len(artifacts)} D3D12 artifacts and {len(closures)} frozen closures')
