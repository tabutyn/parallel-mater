"""Assemble an exact-source D3D12 installer layout while retaining CUDA support."""
import hashlib
import json
from pathlib import Path
import shutil

raw = Path('D:/Repos/parallel-mater-f827-v10-evidence-20261104')
build = Path('D:/Repos/parallel-mater-f827-v10-build-20261104')
frozen = Path('C:/Users/tabut/Repos/ballroller-2026/.codex-worktrees/parallel-mater-f826-v10-source-20261104')
cuda_raw = Path('D:/Repos/parallel-mater-f826-v10-evidence-20261104')
cuda_stage = cuda_raw / 'gallery-install-stage'
stage = raw / 'gallery-install-stage'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert not stage.exists(), stage
identity = json.loads((raw / 'identity.json').read_text())
files = {'Parallel-Mater.exe': build / 'Release/Parallel-Mater.exe'}
files.update({path.name: path for path in (build / 'Release').glob('*.dll')})
for name, path in list(files.items()):
    expected = identity['build_artifacts']['Release/' + path.name]['sha256']
    assert digest(path) == expected, name
for path in (build / 'Release/assets').glob('*.glb'):
    assert path.read_bytes() == (frozen / 'examples/assets' / path.name).read_bytes(), path.name
    files['assets/' + path.name] = path
profile = build / 'Release/config/device-profiles.json'
assert profile.read_bytes() == (frozen / 'config/device-profiles.json').read_bytes()
files['config/device-profiles.json'] = profile
for path in (build / 'Release/manifests/portable').glob('*.json'):
    files['manifests/portable/' + path.name] = path
assert 'manifests/portable/slang-d3d12.json' in files
assert 'manifests/portable/validation.json' in files

cuda_report = json.loads((cuda_raw / 'gallery-install-staging.json').read_text())
for name in ('cudart64_12.dll', 'parallel_mater_driver_slang_cuda.dll', 'manifests/portable/slang-cuda.json'):
    path = cuda_stage / name
    assert digest(path) == cuda_report['files'][name]['sha256'], name
    files[name] = path

mapping = {}
for name, path in files.items():
    target = stage / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
    sha = digest(path)
    assert digest(target) == sha
    mapping[name] = {'source': str(path), 'sha256': sha, 'bytes': path.stat().st_size}
report = {
    'stage': str(stage),
    'files': mapping,
    'd3d12_build_revision': identity['source_revision'],
    'cuda_preservation_source': 'docs/roadmap/evidence/F8-26-CANDIDATE-V10-WINDOWS-CUDA.json',
    'cuda_preservation_revision': identity['source_revision'],
    'policy': 'Use the fresh candidate-v10 D3D12 Gallery and common binaries. Retain only the hash-verified candidate-v10 CUDA driver, CUDA runtime and portable manifest from F8-26.',
    'assets_and_device_profiles_match_frozen_source': True,
}
(raw / 'gallery-install-staging.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(f'Prepared {len(files)} verified combined install files')
