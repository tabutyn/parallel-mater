"""Classify and retain the candidate-v10 Windows D3D12 qualification failure."""
import hashlib
import json
import math
from pathlib import Path
import platform
import subprocess
import xml.etree.ElementTree as ET

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f827-v10-evidence-20261104')
build = Path('D:/Repos/parallel-mater-f827-v10-build-20261104')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()


identity = read(raw / 'identity.json')
task = read(root / 'docs/roadmap/tasks/F8-27.json')
canonical = json.loads(git('show', 'origin/main:docs/roadmap/tasks/F8-27.json'))
assert task == canonical
assert task['status'] == 'leased'
assert task['lease']['token'] == '1c6c2ca1-335f-469b-928e-11da3c9bb1a7'
assert identity['lease']['token'] == task['lease']['token']
assert identity['harness_revision'] == git('rev-parse', 'HEAD')
assert identity['harness_tree'] == git('rev-parse', 'HEAD^{tree}')
assert not git('status', '--porcelain')

candidate_path = root / 'conformance/v1/qualification/realtime-candidate-v10.json'
candidate = read(candidate_path)
assert digest(candidate_path) == identity['candidate_manifest_sha256']
assert candidate['source']['revision'] == identity['source_revision']
assert candidate['source']['tree'] == identity['source_tree']
assert candidate['capability_surface']['interaction_capability_count'] == 49
assert candidate['capability_surface']['capability_reduction_allowed'] is False

registered = read(raw / 'registered-tests.json')['tests']
names = {item['name'] for item in registered}
test_cases = ET.parse(raw / 'ctest.xml').getroot().findall('testcase')
assert {item.attrib['name'] for item in test_cases} == names
assert all(item.find('failure') is None and item.find('error') is None for item in test_cases)
skipped = {item.attrib['name']: item.find('skipped').attrib['message']
           for item in test_cases if item.find('skipped') is not None}
expected_skips = {
    'parallel-mater-d3d12-fluid-pair-graph-lifecycle-tests': 'SKIP_RETURN_CODE=77',
    'parallel-mater-d3d12-fluid-pair-quality-tests': 'SKIP_RETURN_CODE=77',
}
assert skipped == expected_skips
d3d12_tests = []
for test in registered:
    labels = next((item['value'] for item in test['properties'] if item['name'] == 'LABELS'), [])
    if 'd3d12' in labels:
        d3d12_tests.append(test['name'])

sdk = read(raw / 'sdk/report.json')
assert sdk['status'] == 'passed'
assert len(sdk['checks']) == 12 and all(item['status'] == 'passed' for item in sdk['checks'])
metadata = read(raw / 'sdk-freeze-metadata.json')
sdk_root = raw / 'sdk/relocated-sdk'
changed = {item['path']: item['after'] for item in metadata['changes']}
for name, expected in sdk['sdk_sha256'].items():
    normalized = name.replace('\\', '/')
    assert digest(sdk_root / name) == changed.get(normalized, expected), name
for name, expected in changed.items():
    assert digest(sdk_root / name) == expected, name

capture_result = read(raw / 'capture-result.json')
assert capture_result['exit_code'] == 2
public_paths = sorted((raw / 'capture/raw/plain/public-cases').glob('*.json'))
assert len(public_paths) == 30
assert all(read(path)['execution_status'] == 'completed' for path in public_paths)
scenario_paths = sorted((raw / 'capture/raw/plain/scenarios').rglob('*.json'))
assert len(scenario_paths) == 12
assert all(read(path)['execution_status'] == 'completed' for path in scenario_paths)

capabilities = read(raw / 'capture/logs/plain/capabilities.log')
assert len(capabilities) == 46
missing_capabilities = [{
    'first_family': 'FLUID', 'second_family': 'FLUID',
    'scope': 'SEPARATE_SYSTEM', 'mode': mode,
    'direction': 'BIDIRECTIONAL', 'material_profile': 'EQUAL',
    'max_graph_edges_per_simulation': 'simulation-capacity',
} for mode in ('CONTACT', 'PRESSURE', 'VISCOSITY')]
assert all(item not in capabilities for item in missing_capabilities)

workload_paths = {path.stem: path for path in (raw / 'capture/raw/plain/workloads').glob('*.json')}
assert set(workload_paths) == {
    'rigid-wall', 'fluid-rigid', 'deformable-mixed', 'smoke-coupled', 'six-family-mixed'}
workloads = {}
for name in ('rigid-wall', 'fluid-rigid', 'deformable-mixed', 'smoke-coupled'):
    path = workload_paths[name]
    value = read(path)
    assert value['id'] == name
    assert value['warmup_ticks'] == 600 and value['measured_ticks'] == 7200
    assert value['failed_ticks'] == 0
    assert set(value['raw_samples']) == {'cpu_ms', 'gpu_ms', 'physics_ms', 'frame_ms'}
    for clock, samples in value['raw_samples'].items():
        assert len(samples) == 7200 and all(math.isfinite(item) and item >= 0 for item in samples)
        ordered = sorted(samples)
        expected = {label: ordered[math.ceil(fraction * len(samples)) - 1]
                    for label, fraction in [('p50', .5), ('p95', .95), ('p99', .99)]}
        expected['maximum'] = ordered[-1]
        assert value['timings'][clock] == expected
    workloads[name] = {
        'sha256': digest(path), 'warmup_ticks': 600, 'measured_ticks': 7200,
        'failed_ticks': 0, 'counts': value['counts'], 'timings': value['timings'],
        'simulated_to_wall_time_ratio': value['simulated_to_wall_time_ratio'],
        'raw_samples_retained': {clock: len(samples) for clock, samples in value['raw_samples'].items()},
    }
failed_workload = read(workload_paths['six-family-mixed'])
assert failed_workload == {
    'execution_status': 'failed', 'id': 'six-family-mixed',
    'reason': 'no physical device supports workload six-family-mixed',
    'schema': 'parallel-mater-realtime-workload-capture/v1',
}
workload_log = (raw / 'capture/logs/plain/workloads.log').read_text()
assert 'Workloads: 4 completed, 1 failed' in workload_log
assert failed_workload['reason'] in workload_log

targeted = read(raw / 'targeted-six-family-reproduction/result.json')
assert {item['mode']: item['exit_code'] for item in targeted['results']} == {'plain': 2, 'validation': 2}
for mode in ('plain', 'validation'):
    text = (raw / 'targeted-six-family-reproduction' / f'{mode}.log').read_text()
    assert failed_workload['reason'] in text

gallery = read(raw / 'gallery-audit-report.json')
assert gallery['status'] == 'audit_complete' and len(gallery['executions']) == 30
assert gallery['d3d12_failed_scenes'] == ['peg-paint']
assert gallery['cuda_preservation_passed']
assert sum(item['backend'] == 'd3d12' and item['mode'] == 'headless' and item['exit_code'] == 0
           for item in gallery['executions']) == 27
peg = next(item for item in gallery['executions'] if item['backend'] == 'd3d12' and item['scene'] == 'peg-paint')
peg_log = raw / 'gallery-audit' / peg['log']
assert 'Paint coverage failed: 0 texels; need 100.' in peg_log.read_text()
assert 'capacity_overflows=0' in peg_log.read_text()
assert next(item for item in gallery['executions']
            if item['backend'] == 'd3d12' and item['mode'] == 'interactive')['exit_code'] == 0

for name in ('Release/parallel_mater_driver_slang_d3d12.dll', 'Release/Parallel-Mater.exe',
             'Release/parallel-mater-conformance.exe',
             'Release/manifests/portable/slang-d3d12.json'):
    item = identity['build_artifacts'][name]
    assert digest(build / name) == item['sha256'] and (build / name).stat().st_size == item['bytes']

installed = Path(gallery['installed_path'])
assert digest(installed / 'installation.json') == gallery['manifest_sha256']
for name, expected in gallery['manifest']['hashes'].items():
    assert digest(installed / name) == expected.lower(), name

report = {
    'schema': 'parallel-mater-realtime-device-qualification/v2',
    'task': 'F8-27',
    'status': 'failed_candidate_capability_reduction',
    'final_performance_qualified': False,
    'claim_pr': identity['claim_pr'],
    'lease_token': task['lease']['token'],
    'candidate': {
        'id': candidate['id'], 'source_revision': identity['source_revision'],
        'source_tree': identity['source_tree'],
        'manifest': 'conformance/v1/qualification/realtime-candidate-v10.json',
        'manifest_sha256': identity['candidate_manifest_sha256'],
        'exact_source_ci_run': 41708083151,
        'target': 'windows-gtx1080-slang-d3d12', 'runtime_variant': 'd3d12-runtime',
        'evidence_union_allowed': False,
    },
    'failure': {
        'classification': 'required capability reduction and frozen workload rejection',
        'integration_gate_failed': True,
        'timing_only': False,
        'scene_only': False,
        'expected_capability_rows': 49,
        'advertised_capability_rows': 46,
        'missing_capabilities': missing_capabilities,
        'missing_feature': 'liquidLiquidCoupling',
        'failed_workload': failed_workload,
        'plain_capture_exit_code': capture_result['exit_code'],
        'targeted_reproduction_exit_codes': {item['mode']: item['exit_code'] for item in targeted['results']},
        'why_not_deferred': 'F9-07/F9-08 defer numeric timing misses only. This target cannot select a required frozen workload and omits three non-optional capability rows.',
    },
    'source_and_build_provenance': identity,
    'host': {'platform': platform.platform(), 'python': platform.python_version()},
    'nvidia_device': subprocess.check_output([
        'nvidia-smi', '--query-gpu=name,uuid,driver_version,memory.total,pci.bus_id',
        '--format=csv,noheader'], text=True).strip(),
    'registered_tests': {
        'registered': len(test_cases), 'passed': len(test_cases) - len(skipped),
        'skipped': skipped, 'd3d12_labeled_tests': d3d12_tests,
        'classification': 'The two capability-gated skips corroborate missing separate-system fluid-pair support. They are not accepted as full candidate execution.',
    },
    'relocated_sdk': sdk,
    'installed_freeze_metadata': metadata,
    'partial_capture': {
        'finished_at': capture_result['finished_at'],
        'public_cases_completed': len(public_paths),
        'physical_scenarios_executed': len(scenario_paths),
        'physical_scenarios_evaluated': False,
        'advertised_capabilities': capabilities,
        'completed_workloads': workloads,
        'failed_workload': failed_workload,
        'measured_ticks_completed': 4 * 7200,
        'raw_timing_values_retained': 4 * 7200 * 4,
        'validation_mode_full_capture_started': False,
        'targeted_validation_failure_reproduced': True,
        'independent_aggregate_validation_available': False,
    },
    'installed_gallery': gallery,
    'gallery_install_staging': read(raw / 'gallery-install-staging.json'),
    'gallery_shortcut': read(raw / 'gallery-shortcut.json'),
    'scene_debt': {
        'scene': 'peg-paint', 'completed_frames': peg['frames'],
        'observed_painted_texels': 0, 'required_painted_texels': 100,
        'capacity_overflows': 0, 'repair_series': 'F9',
        'classification': 'Known scene-quality class. Preserved separately from the decisive capability failure.',
    },
    'visual_verification': {
        'headless': 'previews/d3d12-headless-rigid-body.png',
        'headless_observation': 'Software-rendered rigid scene contains the floor, bricks and red sphere.',
        'interactive': 'previews/d3d12-interactive-rigid-body.png',
        'interactive_observation': 'Interactive capture contains timing overlay and a black scene frame. Scene presentation repair remains deferred to F9.',
    },
    'verdicts': {
        'f8_windows_d3d12_integration': 'failed',
        'correctness_and_work_budget_matrix': 'incomplete after required workload selection failure',
        'performance': 'not adjudicated because a non-timing integration gate failed',
        'installed_gallery': '27/28 D3D12 headless scenes passed; PEG PAINT failed; interactive startup completed',
        'preserved_cuda_install': 'passed',
    },
}
output = raw / 'qualification-evaluation.json'
assert not output.exists(), output
output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({
    'status': report['status'], 'tests_passed': report['registered_tests']['passed'],
    'tests_skipped': list(skipped), 'capabilities': len(capabilities),
    'completed_workloads': list(workloads), 'failed_workload': failed_workload['id'],
    'gallery_failures': gallery['d3d12_failed_scenes'],
}, indent=2))
