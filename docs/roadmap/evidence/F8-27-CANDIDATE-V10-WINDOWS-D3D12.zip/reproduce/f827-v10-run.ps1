. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f827-v10-env.ps1
if (!(Test-Path -LiteralPath "$F827V10Evidence/identity.json")) { throw 'Exact source and binary identity must be verified first' }
if (Test-Path -LiteralPath "$F827V10Evidence/ctest.log") { throw 'Retain previous test evidence' }
Write-Output 'F8-27 fresh registered tests on exact-source D3D12 Release binaries'
ctest --test-dir $F827V10Build -C Release --show-only=json-v1 *> "$F827V10Evidence/registered-tests.json"
ctest --test-dir $F827V10Build -C Release --output-on-failure --no-tests=error -j 1 --output-junit "$F827V10Evidence/ctest.xml" *> "$F827V10Evidence/ctest.log"
$testCode = $LASTEXITCODE
Copy-Item -LiteralPath "$F827V10Build/Testing/Temporary/LastTest.log" -Destination "$F827V10Evidence/last-test.log"
Get-Content "$F827V10Evidence/ctest.log" -Tail 14
if ($testCode -ne 0) { exit $testCode }
Write-Output 'F8-27 fresh SDK relocation and independent consumers'
Set-Location -LiteralPath $F827V10Frozen
& $F827V10Python tools/check_sdk_install.py --build-dir $F827V10Build --output "$F827V10Evidence/sdk" --config Release *> "$F827V10Evidence/sdk.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F827V10Evidence/sdk.log" -Tail 25; exit $LASTEXITCODE }
Set-Location -LiteralPath $F827V10Source
& $F827V10Python C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f827-v10-sdk-metadata.py *> "$F827V10Evidence/sdk-freeze-metadata.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F827V10Evidence/sdk-freeze-metadata.log" -Tail 20; exit $LASTEXITCODE }
$sdk = "$F827V10Evidence/sdk/relocated-sdk"
$env:PATH = "$sdk/bin;" + $env:PATH
$capture = @("$sdk/share/parallel-mater/conformance/v1/realtime_device_capture.py",'--runner',"$sdk/bin/parallel-mater-conformance.exe",
    '--driver-manifest',"$sdk/share/parallel-mater/drivers.d/parallel_mater_slang_d3d12.json",
    '--validation-layer-manifest',"$sdk/share/parallel-mater/layers.d/parallel_mater_validation.json",
    '--runtime-variant','d3d12-runtime','--target-id','windows-gtx1080-slang-d3d12','--output',"$F827V10Evidence/capture")
@{executable=$F827V10Python; arguments=$capture} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F827V10Evidence/capture-command.json"
Write-Output 'F8-27 fresh v10 installed-public D3D12 capture'
& $F827V10Python @capture *> "$F827V10Evidence/capture.log"
$captureCode = $LASTEXITCODE
@{exit_code=$captureCode; finished_at=[DateTimeOffset]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -Encoding utf8 "$F827V10Evidence/capture-result.json"
Get-Content "$F827V10Evidence/capture.log" -Tail 18
if ($captureCode -gt 1 -or -not (Test-Path -LiteralPath "$F827V10Evidence/capture/report.json")) { exit 2 }
& $F827V10Python "$sdk/share/parallel-mater/conformance/v1/realtime_device_suite.py" --capture "$F827V10Evidence/capture/capture.json" --candidate-manifest "$sdk/share/parallel-mater/conformance/v1/qualification/realtime-candidate-v10.json" --output "$F827V10Evidence/independent-report.json" *> "$F827V10Evidence/independent-validation.log"
$validationCode = $LASTEXITCODE
if ($validationCode -gt 1 -or -not (Test-Path -LiteralPath "$F827V10Evidence/independent-report.json")) { exit 2 }
Write-Output 'F8-27 capture complete for separate correctness and timing review'
