. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f827-v10-env.ps1
if (!(Test-Path -LiteralPath "$F827V10Evidence/capture-result.json")) { throw 'Finish sustained capture before installed Gallery work' }
if (Test-Path -LiteralPath "$F827V10Evidence/gallery-audit-report.json") { throw 'Retain prior Gallery evidence' }
$galleryInstall = Join-Path $env:LOCALAPPDATA 'Programs/Parallel-Mater'
$previousManifest = Join-Path $galleryInstall 'installation.json'
if ((Test-Path -LiteralPath $previousManifest) -and !(Test-Path -LiteralPath "$F827V10Evidence/gallery-previous-installation.json")) {
    Copy-Item -LiteralPath $previousManifest -Destination "$F827V10Evidence/gallery-previous-installation.json"
}
& "$F827V10Frozen/scripts/Install-WindowsGallery.ps1" -BuildDirectory "$F827V10Evidence/gallery-install-stage" -BuildConfiguration Release -Version '0.3.0' *> "$F827V10Evidence/gallery-install.log"
Get-Content "$F827V10Evidence/gallery-install.log" -Tail 8
$installed = Get-Content -LiteralPath (Join-Path $galleryInstall 'installation.json') -Raw | ConvertFrom-Json
if ($installed.state -ne 'installed' -or $installed.revision -ne '5bacbe2b1e0fbfad565fb9477bb6873396e31d5d') { throw 'Installed identity differs from candidate v10' }
$shortcutPath = Join-Path ([Environment]::GetFolderPath('Programs')) 'Parallel-Mater.lnk'
$shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut($shortcutPath)
if ($shortcut.TargetPath -ne (Join-Path $galleryInstall 'Parallel-Mater.exe')) { throw 'Start menu target differs' }
@{path=$shortcutPath; target=$shortcut.TargetPath; working_directory=$shortcut.WorkingDirectory; installed_revision=$installed.revision} | ConvertTo-Json | Set-Content -Encoding utf8 "$F827V10Evidence/gallery-shortcut.json"
& $F827V10Python C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f827-v10-gallery-audit.py
exit $LASTEXITCODE
