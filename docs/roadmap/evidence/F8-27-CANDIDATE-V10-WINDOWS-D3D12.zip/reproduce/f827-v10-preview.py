"""Convert retained P6 Gallery captures to lossless PNG previews."""
from pathlib import Path
import struct
import zlib

raw = Path('D:/Repos/parallel-mater-f827-v10-evidence-20261104')
output = raw / 'previews'
output.mkdir(exist_ok=True)


def chunk(kind, data):
    checksum = zlib.crc32(kind + data) & 0xffffffff
    return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', checksum)


for name in ('d3d12-headless-rigid-body.ppm', 'd3d12-interactive-rigid-body.ppm',
             'd3d12-headless-peg-paint.ppm'):
    path = raw / 'gallery-audit' / name
    if not path.is_file():
        continue
    with path.open('rb') as stream:
        assert stream.readline() == b'P6\n'
        width, height = map(int, stream.readline().split())
        assert stream.readline() == b'255\n'
        pixels = stream.read()
    stride = width * 3
    assert len(pixels) == stride * height
    rows = b''.join(b'\0' + pixels[row * stride:(row + 1) * stride] for row in range(height))
    png = b'\x89PNG\r\n\x1a\n'
    png += chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0))
    png += chunk(b'IDAT', zlib.compress(rows, 9))
    png += chunk(b'IEND', b'')
    target = output / (path.stem + '.png')
    assert not target.exists(), target
    target.write_bytes(png)
    print(target)
