. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f876-env.ps1
$F876Build = 'D:/Repos/parallel-mater-f8-76-current-20261102'
$env:PATH = $F876Build + ';' + $env:PATH
Remove-Item Env:PM_TEST_VALIDATION -ErrorAction SilentlyContinue
if (Test-Path -LiteralPath $F876Build) { throw 'Current Release build must start in a fresh directory' }
$configure = @('-S',$F876Source,'-B',$F876Build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DBUILD_TESTING=ON',
    '-DCMAKE_CUDA_ARCHITECTURES=61','-DPARALLEL_MATER_BUILD_CUDA=ON','-DPARALLEL_MATER_BUILD_D3D12=OFF',
    '-DPARALLEL_MATER_BUILD_VULKAN=OFF','-DPARALLEL_MATER_BUILD_GALLERY=ON','-DPARALLEL_MATER_BUILD_CONFORMANCE=ON',
    '-DPARALLEL_MATER_BUILD_SLANG_MIRRORS=ON','-DPARALLEL_MATER_BUILD_SLANG_GEOMETRY_CONSTRAINTS=ON',
    '-DPARALLEL_MATER_WINDOWS_GALLERY_AUTO_DEPLOY=OFF',
    '-DFETCHCONTENT_SOURCE_DIR_PARALLEL_MATER_GLFW=D:/Repos/parallel-mater/build-d3d12-full/_deps/parallel_mater_glfw-src',
    "-DPython3_EXECUTABLE=$F876Python","-DPARALLEL_MATER_SLANGC_EXECUTABLE=$F826Slang")
@{ executable = 'cmake'; arguments = $configure; build_directory_existed = $false } | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F876Evidence/release-current-configure-command.json"
cmake @configure *> "$F876Evidence/release-current-configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F876Evidence/release-current-configure.log" -Tail 25; exit $LASTEXITCODE }
cmake --build $F876Build -j 4 *> "$F876Evidence/release-current-build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F876Evidence/release-current-build.log" -Tail 30; exit $LASTEXITCODE }
& $F876Python C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f876-identity.py after-current-release $F876Build
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
ctest --test-dir $F876Build --show-only=json-v1 *> "$F876Evidence/registered-current-tests.json"
ctest --test-dir $F876Build --output-on-failure --no-tests=error -j 1 --output-junit "$F876Evidence/ctest-current.xml" *> "$F876Evidence/ctest-current.log"
$code = $LASTEXITCODE
Copy-Item -LiteralPath "$F876Build/Testing/Temporary/LastTest.log" -Destination "$F876Evidence/ctest-current-last-test.log"
Get-Content "$F876Evidence/ctest-current.log" -Tail 15
if ($code -ne 0) { exit $code }
& C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f876-public-current.ps1
exit $LASTEXITCODE
