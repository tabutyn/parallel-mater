"""Build an independent public-API lifecycle probe from the canonical fixture."""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f8-76-evidence-20261102')
output = raw / 'lifecycle-source-v5'
assert not output.exists(), 'Retain existing probe source'
output.mkdir()
source = root / 'tests/api/native_realtime_runtime_tests.cpp'
text = source.read_text()
text = text.replace('PmDeviceMemory source_memory{}, auxiliary_output_memory{};',
                    'PmDeviceMemory source_memory{}, auxiliary_output_memory{}, soft_output_memory{};')
text = text.replace('const auto soft_output = buffer(1024U, &soft_output_map);',
                    'const auto soft_output = buffer(1024U, &soft_output_map, &soft_output_memory);')
if 'instance_info.enableValidation' not in text:
    text = text.replace('    instance_info.apiVersion = PM_API_VERSION_0_3;',
        '    instance_info.apiVersion = PM_API_VERSION_0_3;\n    instance_info.enableValidation = std::getenv("PM_TEST_VALIDATION") ? PM_TRUE : PM_FALSE;')
paint = r'''
        // F8-76: repeat asynchronous work, reject an edit without changing the
        // published field, then replace its resource and reuse the same slot.
        const auto metadata_tick = [&](const char *label) {
            execution_label = label;
            CHECK(pmBeginCommandBuffer(commands, &begin) == PM_SUCCESS);
            CHECK(pmCmdResetQueryPool(commands, query, 0U, 1U) == PM_SUCCESS);
            CHECK(pmCmdBeginStatisticsQuery(commands, query, 0U) == PM_SUCCESS);
            CHECK(pmCmdBindPhysicsPipeline(commands, pipeline) == PM_SUCCESS);
            CHECK(pmCmdStepSimulation(commands, mixed_simulation, &step) == PM_SUCCESS);
            CHECK(pmCmdCopyPaintField(commands, mixed_simulation, 0U, &paint_range) == PM_SUCCESS);
            CHECK(pmCmdEndStatisticsQuery(commands, query, 0U) == PM_SUCCESS);
            execute(PM_SUCCESS);
            PmRealtimeStepStatistics actual{};
            CHECK(pmGetQueryPoolResults(device, query, 0U, 1U, sizeof actual,
                &actual, sizeof actual, PM_QUERY_RESULT_WAIT_BIT) == PM_SUCCESS);
            CHECK(actual.timeAdvances == 1U);
            CHECK(actual.total.spatialIndexBuilds == 1U);
            CHECK(actual.total.spatialIndexPublications == 1U);
            CHECK(actual.total.intraTickHostReadbacks == 0U);
            CHECK(pmInvalidateMappedMemoryRanges(device, 1U, &auxiliary_output_range) == PM_SUCCESS);
        };
        for (unsigned tick = 0; tick < 4; ++tick) metadata_tick("paint repeated async tick");
        std::array<std::byte, 256> before_edit{};
        std::memcpy(before_edit.data(), static_cast<const std::byte *>(auxiliary_output_map) + paint_range.offset, before_edit.size());
        auto rejected_field = paint_field;
        rejected_field.width = paint_capacity.width + 1U;
        CHECK(pmBeginCommandBuffer(commands, &begin) == PM_SUCCESS);
        CHECK(pmCmdWritePaintFields(commands, mixed_simulation, 0U, 1U, &rejected_field) == PM_ERROR_CAPACITY_EXCEEDED);
        CHECK(pmCmdCopyPaintField(commands, mixed_simulation, 0U, &paint_range) == PM_SUCCESS);
        execute(PM_SUCCESS);
        CHECK(pmInvalidateMappedMemoryRanges(device, 1U, &auxiliary_output_range) == PM_SUCCESS);
        CHECK(std::memcmp(before_edit.data(), static_cast<const std::byte *>(auxiliary_output_map) + paint_range.offset, before_edit.size()) == 0);
        PmPaintRuleInfo disabled_rule{};
        auto replacement_field = paint_field;
        replacement_field.width = 2U;
        replacement_field.height = 3U;
        CHECK(pmBeginCommandBuffer(commands, &begin) == PM_SUCCESS);
        CHECK(pmCmdWritePaintRules(commands, mixed_simulation, 0U, 1U, &disabled_rule) == PM_SUCCESS);
        CHECK(pmCmdWritePaintFields(commands, mixed_simulation, 0U, 1U, &replacement_field) == PM_SUCCESS);
        CHECK(pmCmdWritePaintRules(commands, mixed_simulation, 0U, 1U, &paint_rule) == PM_SUCCESS);
        execute(PM_SUCCESS);
        metadata_tick("paint replacement recovery tick");
        CHECK(paint_header->activeCount == 6U);
        CHECK(paint_header->capacity == 6U);
        std::puts("F8_76_PAINT_LIFECYCLE repeated_ticks=5 rejected_edit_atomic=1 replacement_pixels=6");
        std::fflush(stdout);
'''
needle = '        execution_label = "paint clear and reset lifetime";'
assert text.count(needle) == 1
text = text.replace(needle, paint + '\n' + needle)
soft = r'''
        // Both complete replacements run in the same public simulation slot.
        for (unsigned generation = 0; generation < 2; ++generation) {
            const float shift = 0.2F * generation;
            const PmFloat3 nodes[5]{{0.2F + shift, 1.2F, 0},
                {0.15F + shift, 1, 0}, {0.25F + shift, 1, 0},
                {0.2F + shift, 1.1F, 0.05F}, {0.2F + shift, 1.1F, -0.05F}};
            const float masses[5]{0, 1, 1, 1, 1};
            std::array<PmSoftBodyBond, 10> bonds{};
            unsigned bond_count{};
            for (unsigned a = 0; a < 5; ++a) for (unsigned b = a + 1; b < 5; ++b) {
                const float x = nodes[a].x - nodes[b].x, y = nodes[a].y - nodes[b].y, z = nodes[a].z - nodes[b].z;
                bonds[bond_count++] = {a, b, std::sqrt(x*x + y*y + z*z)};
            }
            const PmFloat3 surface[4]{nodes[1], nodes[2], nodes[3], nodes[4]};
            const std::uint32_t indices[12]{0, 2, 1, 0, 1, 3, 0, 3, 2, 1, 2, 3};
            std::array<PmSoftBodySurfaceBinding, 4> bindings{};
            for (unsigned v = 0; v < 4; ++v) { bindings[v].nodes[0] = v + 1; bindings[v].weights[0] = 1; }
            const PmSoftBodyInfo body_info{PM_TRUE, 0U, 5U, nodes, 10U, bonds.data(), masses, 4U, surface, 12U, indices, bindings.data()};
            CHECK(pmBeginCommandBuffer(commands, &begin) == PM_SUCCESS);
            CHECK(pmCmdResetSimulation(commands, mixed_simulation) == PM_SUCCESS);
            CHECK(pmCmdBindPhysicsPipeline(commands, pipeline) == PM_SUCCESS);
            CHECK(pmCmdWriteSoftBodies(commands, mixed_simulation, 0U, 1U, &body_info) == PM_SUCCESS);
            execute(PM_SUCCESS);
            *particle = {};
            particle->position[0] = 0.2F + shift;
            particle->position[1] = 1.04F;
            CHECK(pmFlushMappedMemoryRanges(device, 1U, &particle_source_range) == PM_SUCCESS);
            PmCouplingStateInfo coupling{};
            coupling.sType = PM_STRUCTURE_TYPE_COUPLING_STATE_INFO;
            coupling.type = PM_COUPLING_LIQUID_SOFT_BODY;
            coupling.modeFlags = PM_INTERACTION_MODE_CONTACT_BIT;
            coupling.materialProfile = PM_INTERACTION_MATERIAL_ENDPOINT_NATIVE;
            coupling.parameters.mechanical.contactDistance = 0.02F;
            coupling.parameters.mechanical.friction = 0.2F;
            coupling.parameters.mechanical.twoWay = PM_TRUE;
            CHECK(pmBeginCommandBuffer(commands, &begin) == PM_SUCCESS);
            CHECK(pmCmdBindPhysicsPipeline(commands, pipeline) == PM_SUCCESS);
            CHECK(pmCmdPipelineBarrier(commands, 0U, nullptr, 1U, &particle_visibility) == PM_SUCCESS);
            // SetFluidParticles leaves native uploads pending before creation.
            CHECK(pmCmdSetFluidParticles(commands, mixed_simulation, 0U, &particle_input) == PM_SUCCESS);
            CHECK(pmCmdSetCouplings2(commands, mixed_simulation, 1U, &coupling) == PM_SUCCESS);
            execute(PM_SUCCESS);
            const PmBufferRange soft_range{soft_output, 0U, 1024U};
            const auto coupled_tick = [&] {
                CHECK(pmBeginCommandBuffer(commands, &begin) == PM_SUCCESS);
                CHECK(pmCmdResetQueryPool(commands, query, 0U, 1U) == PM_SUCCESS);
                CHECK(pmCmdBeginStatisticsQuery(commands, query, 0U) == PM_SUCCESS);
                CHECK(pmCmdBindPhysicsPipeline(commands, pipeline) == PM_SUCCESS);
                CHECK(pmCmdStepSimulation(commands, mixed_simulation, &step) == PM_SUCCESS);
                CHECK(pmCmdCopySoftBodyState(commands, mixed_simulation, 0U, &soft_range) == PM_SUCCESS);
                CHECK(pmCmdEndStatisticsQuery(commands, query, 0U) == PM_SUCCESS);
                execute(PM_SUCCESS);
                PmRealtimeStepStatistics actual{};
                CHECK(pmGetQueryPoolResults(device, query, 0U, 1U, sizeof actual, &actual, sizeof actual, PM_QUERY_RESULT_WAIT_BIT) == PM_SUCCESS);
                CHECK(actual.timeAdvances == 1U && actual.total.spatialIndexPublications == 1U);
                CHECK(actual.total.intraTickHostReadbacks == 0U);
                const PmMappedMemoryRange mapped{soft_output_memory, 0U, 1024U};
                CHECK(pmInvalidateMappedMemoryRanges(device, 1U, &mapped) == PM_SUCCESS);
                const auto *header = static_cast<const PmDomainOutputHeader *>(soft_output_map);
                const auto *values = reinterpret_cast<const PmSoftBodyNodeState *>(header + 1U);
                CHECK(header->activeCount == 5U);
                CHECK(values[0].position.x == nodes[0].x);
                for (unsigned n = 0; n < 5; ++n) CHECK(std::isfinite(values[n].position.y) && std::isfinite(values[n].velocity.y));
            };
            for (unsigned tick = 0; tick < 4; ++tick) coupled_tick();
            std::array<std::byte, 1024> retained{};
            std::memcpy(retained.data(), soft_output_map, retained.size());
            auto rejected_body = body_info;
            rejected_body.nodeCount = soft_capacity.nodeCapacity + 1U;
            CHECK(pmBeginCommandBuffer(commands, &begin) == PM_SUCCESS);
            CHECK(pmCmdBindPhysicsPipeline(commands, pipeline) == PM_SUCCESS);
            CHECK(pmCmdWriteSoftBodies(commands, mixed_simulation, 0U, 1U, &rejected_body) == PM_ERROR_INVALID_ARGUMENT);
            CHECK(pmCmdCopySoftBodyState(commands, mixed_simulation, 0U, &soft_range) == PM_SUCCESS);
            execute(PM_SUCCESS);
            const PmMappedMemoryRange recovered{soft_output_memory, 0U, 1024U};
            CHECK(pmInvalidateMappedMemoryRanges(device, 1U, &recovered) == PM_SUCCESS);
            CHECK(std::memcmp(retained.data(), soft_output_map, retained.size()) == 0);
            coupled_tick();
        }
        std::puts("F8_76_SOFT_FLUID_LIFECYCLE constructions=2 ticks=10 rejected_edits_atomic=2 reset_replacement=1");
        std::fflush(stdout);
'''
needle = '        execute(PM_ERROR_INVALID_STATE);\n    } else if (auxiliary_only) {'
assert text.count(needle) == 1
text = text.replace(needle, '        execute(PM_ERROR_INVALID_STATE);\n' + soft + '\n    } else if (auxiliary_only) {')
(output / 'lifecycle.cpp').write_text(text, encoding='utf-8', newline='\n')
build = Path('D:/Repos/parallel-mater-f8-76-build-20261102')
headers = list(build.rglob('realtime_fixture_contract.hpp'))
assert len(headers) == 1, headers
shutil.copy2(headers[0], output / 'realtime_fixture_contract.hpp')
metadata = {'base_fixture': str(source.relative_to(root)), 'base_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'base_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
            'probe_sha256': hashlib.sha256((output / 'lifecycle.cpp').read_bytes()).hexdigest(),
            'scope': 'Independent public API probe compiled against relocated SDK headers/import library; no runtime private state. Existing public fixture plus painted-field edit/replacement checks and queued-upload soft-body/fluid construction/recovery.'}
(output / 'source.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(metadata, indent=2))
