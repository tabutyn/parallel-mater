. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f876-env.ps1
$firstRelease = 'D:/Repos/parallel-mater-f8-76-final-20261102'
$gallery = "$F876Diagnostic/parallel-mater-command-gallery-tests.exe"
$auxiliary = "$F876Evidence/auxiliary-regression-control.exe"
$plans = @()
foreach ($scene in @('Pegs','SoftbodyFluid','RopeSoftbody','RopeCloth','Smoke','SmokeWater')) {
    foreach ($mode in @('plain','validation')) {
        $plans += [ordered]@{ id = "$scene-$mode"; mode = $mode; executable = $gallery; arguments = @('--backend','cuda','--scene',"$scene.glb",'--frames','8'); driver_manifest = "$F826Build/Release/manifests/slang-cuda.json"; layer_manifest = "$F826Build/Release/manifests/validation.json"; driver_binary = "$F826Build/parallel_mater_driver_slang_cuda.dll"; driver_source_revision = 'bf3ba752792cd54f144e0ddf525a05911d5f65d8'; driver_source_tree = '598912e3bfeb32f8c8f97f45842ed2b2cfc1973f' }
    }
}
foreach ($mode in @('plain','validation')) {
    $plans += [ordered]@{ id = "auxiliary-$mode"; mode = $mode; executable = $auxiliary; arguments = @('--production-managed-auxiliary'); driver_manifest = "$firstRelease/Release/manifests/slang-cuda.json"; layer_manifest = "$firstRelease/Release/manifests/validation.json"; driver_binary = "$firstRelease/parallel_mater_driver_slang_cuda.dll"; driver_source_revision = '8c24d4b2f6017a8def5e2db88036ec4093321290'; driver_source_tree = 'c1e0a5feab03ffa9fa2d69cae1f2530d23491188' }
}
foreach ($plan in $plans) {
    $plan.executable_sha256 = (Get-FileHash -Algorithm SHA256 $plan.executable).Hash.ToLowerInvariant()
    $plan.driver_binary_sha256 = (Get-FileHash -Algorithm SHA256 $plan.driver_binary).Hash.ToLowerInvariant()
    $plan.driver_manifest_sha256 = (Get-FileHash -Algorithm SHA256 $plan.driver_manifest).Hash.ToLowerInvariant()
    $plan.consumer_source_revision = git rev-parse HEAD
}
$plans | ConvertTo-Json -Depth 7 | Set-Content -Encoding utf8 "$F876Evidence/pinned-controls-plan.json"
$env:PATH = "$F876Diagnostic;$F876Evidence/sdk/relocated-sdk/bin;" + $env:PATH
foreach ($plan in $plans) {
    $env:PM_DRIVER_FILES = $plan.driver_manifest
    $env:PM_LAYER_FILES = $plan.layer_manifest
    if ($plan.mode -eq 'validation') { $env:PM_TEST_VALIDATION = '1' } else { Remove-Item Env:PM_TEST_VALIDATION -ErrorAction SilentlyContinue }
    $record = "$F876Evidence/pinned-before-$($plan.id).json"
    if (Test-Path -LiteralPath $record) { throw 'Retain existing control evidence' }
    $commandArgs = @($record, $plan.executable) + $plan.arguments
    & $F876Python C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f826-debug.py @commandArgs *> "$F876Evidence/pinned-before-$($plan.id)-harness.log"
    if ($LASTEXITCODE -ne 0) { throw "Control recorder failed: $($plan.id)" }
    $result = Get-Content $record -Raw | ConvertFrom-Json
    if ($result.exit_code -ne 3221225478) { throw "Expected managed access fault: $($plan.id), got $($result.exit_code)" }
    Write-Output "EXPECTED CRASH: $($plan.id)"
}
