. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f826-env.ps1
$F876Source = $F826Source
$F876Diagnostic = 'D:/Repos/parallel-mater-f8-76-diagnostic-20261102'
$F876Build = 'D:/Repos/parallel-mater-f8-76-build-20261102'
$F876Evidence = 'D:/Repos/parallel-mater-f8-76-evidence-20261102'
$F876Python = $F826Python
Remove-Item Env:CUDA_LAUNCH_BLOCKING -ErrorAction SilentlyContinue
Remove-Item Env:PM_DRIVER_FILES -ErrorAction SilentlyContinue
Remove-Item Env:PM_LAYER_FILES -ErrorAction SilentlyContinue
Remove-Item Env:PM_ENABLE_LAYERS -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $F876Evidence -Force | Out-Null
