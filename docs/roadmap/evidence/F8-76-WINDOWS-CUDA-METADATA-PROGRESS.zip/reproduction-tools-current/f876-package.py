import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f8-76-evidence-20261102')
helpers = Path('C:/Users/tabut/Repos/ballroller-2026/.codex-tmp')
destination = root / 'docs/roadmap/evidence'
stem = 'F8-76-WINDOWS-CUDA-METADATA-PROGRESS'
revision = '68e7d8f3af24c47d8d4d1da374d7ef600b9f04e2'
baseline = '7e0e86a18255c36d649eef7017fa4badf194f296'

def read(name):
    return json.loads((raw / name).read_text(encoding='utf-8-sig'))

def dump(path, value):
    assert not path.exists(), f'Retain existing artifact: {path}'
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)

assert git('rev-parse', 'HEAD').decode().strip() == revision
assert not git('status', '--porcelain').strip()
for suffix in ['.json', '.zip', '.md']:
    assert not (destination / (stem + suffix)).exists()
after = read('after-current-release-identity.json')
assert after['source_revision'] == revision and not after['source_status']
assert after['source_tree'] == git('rev-parse', 'HEAD^{tree}').decode().strip()
assert after['cuda_memory_attributes']['concurrent_managed_access']['value'] == 0
assert after['candidate_v9_manifest']['sha256'] == '4ed4ed7a097928944ac5667e8120e2447affda962a258e56c01dfd0d90d9dd4b'
suite = read('current-suite-verification.json')
assert suite['existing_tests'] == 130 and suite['all_existing_tests_retained']
cases = ET.parse(raw / 'ctest-current.xml').getroot().findall('testcase')
assert len(cases) == suite['total'] == 144
assert all(c.get('status') == 'run' and c.find('failure') is None and c.find('skipped') is None for c in cases)
sdk = read('sdk-current/report.json')
assert sdk['source_revision'] == revision and not sdk['source_dirty']
assert sdk['status'] == 'passed' and len(sdk['checks']) == 12
assert all(c['status'] == 'passed' for c in sdk['checks'])
capture = read('installed-public-current/capture.json')
evaluation = read('installed-public-current/report.json')
assert not evaluation['passed'] and evaluation['failure_count'] > 0, evaluation
assert len(capture['public_cases']) == 30 and len(capture['scenarios']) == 12
assert len(capture['workloads']) == len(capture['negative_controls']) == 5
assert all(c['execution_status'] == 'completed' for c in capture['public_cases'])
for item in capture['scenarios'] + capture['workloads']:
    assert [e['validation_enabled'] for e in item['executions']] == [False, True]
for mode in ['plain', 'validation']:
    assert len(list((raw / 'installed-public-current/raw' / mode / 'public-cases').glob('*.json'))) == 30
    assert len(list((raw / 'installed-public-current/raw' / mode / 'scenarios').iterdir())) == 12
    assert len(list((raw / 'installed-public-current/raw' / mode / 'workloads').glob('*.json'))) == 5
lifecycle = read('lifecycle-current-results.json')
assert [r['mode'] for r in lifecycle] == ['plain', 'validation']
for r in lifecycle:
    assert r['exit_code'] == 0 and not r['debugger'] and r['cuda_launch_blocking'] is None
    log = (raw / f"lifecycle-current-{r['mode']}.log").read_text()
    assert 'F8_76_PAINT_LIFECYCLE repeated_ticks=5 rejected_edit_atomic=1 replacement_pixels=6' in log
    assert 'F8_76_SOFT_FLUID_LIFECYCLE constructions=2 ticks=10 rejected_edits_atomic=2 reset_replacement=1' in log
controls = read('pinned-controls-plan.json')
assert len(controls) == 14
for c in controls:
    observed = read(f"pinned-before-{c['id']}.json")
    assert observed['exit_code'] == 0xc0000006 and observed['cuda_launch_blocking'] is None
    assert any(e['parameters'][-1] == '0xc0000022' and not e['first_chance'] for e in observed['exceptions'])
audit = read('schedule-audit-current.json')
closures = read('closure-classification-current.json')
assert closures['candidate_v9_manifest_unchanged'] and closures['frozen_limits_and_fixtures_unchanged']
assert audit['fixed_tick_backend']['entire_file_matches_only_five_host_metadata_substitutions']
assert audit['public_oracle_test_harness']['existing_fixture_assertions_tolerances_workloads_byte_identical']

fault_names = [
    'before-symbol-peg-symbols.json', 'before-symbol-soft-fluid-symbols.json',
    'repair-full-gallery-debug-symbols.json', 'repair-full-gallery-v2-symbols.json',
    'repair-full-gallery-v3-symbols.json', 'SmokeWater-before-plain-symbols.json',
    'lifecycle-extra-debug-symbols.json',
]
faults = []
for name in fault_names:
    value = read(name)
    e = next(e for e in value['exceptions'] if not e['first_chance'] and e['code'] == '0xc0000006')
    faults.append({'artifact': name, 'symbol': e['symbol'], 'source': e['source'],
                   'exception': e['code'], 'status': e['parameters'][-1]})

tools = raw / 'reproduction-tools-current'
assert not tools.exists()
tools.mkdir()
for name in ['f826-env.ps1', 'f876-env.ps1', 'f826-debug.py', 'f876-symbolize.py',
             'f876-release-current.ps1', 'f876-public-current.ps1', 'f876-controls-pinned.ps1',
             'f876-identity.py', 'f876-closures.py', 'f876-audit-current.py',
             'f876-lifecycle-probe.py', 'f876-package.py']:
    shutil.copy2(helpers / name, tools / name)
patch = raw / 'source-repair-current.patch'
assert not patch.exists()
patch.write_bytes(git('diff', baseline, revision))
manifest_copy = raw / 'candidate-v9-input-current.json'
assert not manifest_copy.exists()
shutil.copy2(root / 'conformance/v1/qualification/realtime-candidate-v9.json', manifest_copy)

prefixes = ('before-release-', 'before-symbol-', 'pinned-before-', 'repair-full-gallery-',
            'rope-soft-before-', 'rope-cloth-before-', 'Smoke-before-', 'SmokeWater-before-')
names = {
    'machine.json', 'baseline-source-provenance.json', 'pinned-controls-plan.json',
    'release-current-configure-command.json', 'release-current-configure.log', 'release-current-build.log',
    'diagnostic-configure-command.json', 'diagnostic-configure.log', 'diagnostic-build.log',
    'after-current-release-identity.json', 'after-final-release-identity.json', 'current-binary-hashes.json',
    'registered-tests.json', 'registered-current-tests.json', 'current-suite-verification.json',
    'ctest-current.xml', 'ctest-current.log', 'ctest-current-last-test.log',
    'sdk-current-command.json', 'sdk-current.log', 'installed-public-current-command.json', 'installed-public-current.log',
    'lifecycle-current-build-command.json', 'lifecycle-current-build.log', 'lifecycle-current-results.json',
    'lifecycle-current-plain-result.json', 'lifecycle-current-plain.log',
    'lifecycle-current-validation-result.json', 'lifecycle-current-validation.log',
    'lifecycle-extra-debug-symbols.json', 'lifecycle-extra-debug.json', 'lifecycle-extra-debug.log',
    'auxiliary-regression-control-build.log', 'closure-classification-current.json',
    'closure-classification-current.log', 'schedule-audit-current.json', 'frozen-candidate-current-check.log',
    'source-repair-current.patch', 'candidate-v9-input-current.json', 'workload-power-observation.json',
}
members = {p.relative_to(raw).as_posix(): p for p in raw.iterdir()
           if p.is_file() and (p.name in names or p.name.startswith(prefixes))}
for directory in ['installed-public-current', 'lifecycle-source-v5', 'reproduction-tools-current']:
    for p in (raw / directory).rglob('*'):
        if p.is_file():
            members[p.relative_to(raw).as_posix()] = p
for p in (raw / 'sdk-current').iterdir():
    if p.is_file():
        members[p.relative_to(raw).as_posix()] = p
assert names.issubset({p.name for p in members.values()}), names - {p.name for p in members.values()}
assert not any(p.suffix.lower() in ['.exe', '.dll', '.obj', '.pdb', '.lib'] for p in members.values())
member_manifest = {name: {'sha256': sha(p), 'bytes': p.stat().st_size}
                   for name, p in sorted(members.items())}
manifest_path = raw / 'SHA256SUMS-current.json'
dump(manifest_path, member_manifest)
archive = destination / (stem + '.zip')
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for name, path in sorted(members.items()):
        output.write(path, name)
    output.write(manifest_path, 'SHA256SUMS-current.json')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for name, item in member_manifest.items():
        data = check.read(name)
        assert hashlib.sha256(data).hexdigest() == item['sha256'] and len(data) == item['bytes']

report = {
    'schema': 'parallel-mater-runtime-ownership-repair/v1', 'task': 'F8-76', 'status': 'incomplete',
    'captured_at': datetime.now(timezone.utc).isoformat(),
    'claim_pr': 'https://github.com/tabutyn/parallel-mater/pull/642',
    'lease_token': '3d5aa79b-50c7-4545-aaee-a5b3e03779eb',
    'scope': 'Repair Windows CUDA host access to managed metadata; repaired-source progress evidence against unchanged frozen v9 limits. Acceptance remains incomplete.',
    'baseline_provenance': read('baseline-source-provenance.json'),
    'fresh_baseline_symbol_build': read('before-symbol-identity.json'),
    'after': after, 'machine': read('machine.json'),
    'ownership_diagnosis': {
        'contract': 'This GTX 1080 supports managed memory but concurrentManagedAccess is zero. A public idle frame does not retire asynchronous native uploads. Ordinary host metadata stays accessible while the managed device arenas are unavailable to the CPU.',
        'faults': faults,
        'repair': [
            'Keep paint descriptors, mesh generation/liveness and immutable body-to-mesh identities in ordinary host storage; publish device paint descriptors at resource edits and retire payloads after publication completes.',
            'Retire pending execution once at each fluid/soft-body, rope/soft-body and rope/cloth constructor before CPU geometry/attachment traversal. Services.wait_idle may be device-wide; these three waits are resource-edit boundaries outside fixed ticks.',
            'Snapshot all live fluid counts together before public hit-box query launches, retaining the host destinations through transfer completion even on error; use immutable counts until the existing final query completion.',
        ],
        'fixed_tick': 'Only five host-metadata substitutions in the entire production realtime backend. No kernel, dispatch, equation, iteration, timestep, publication or budget-formula change; no added fixed-tick wait/readback.',
        'hit_box_cost': 'Public host-result query adds one batched count-completion boundary (one wait becomes two when live fluids exist), outside fixed ticks; no per-kernel synchronization blanket.',
    },
    'clean_release_tests': suite,
    'relocated_sdk': {k: sdk[k] for k in sdk if k != 'sdk_sha256'},
    'public_lifecycle': {'executions': lifecycle, 'source': read('lifecycle-source-v5/source.json'),
                         'paint': {'repeated_ticks_per_mode': 5, 'rejected_edit_atomic': True, 'replacement_pixels': 6, 'clear_reset': True},
                         'soft_fluid': {'constructions_per_mode': 2, 'ticks_per_mode': 10, 'rejected_edits_atomic_per_mode': 2, 'reset_replacement': True},
                         'tick_assertions': 'Every successful probe tick asserts one advance/publication and zero intra-tick host readbacks; rejected edits preserve public bytes and recovery advances once.'},
    'failing_before_regressions': {'total': 14, 'all_expected_crashes_observed': True, 'plan': controls},
    'installed_public_capture': {'report': evaluation, 'public_cases': 30, 'scenarios': 12, 'workloads': 5, 'negative_controls': 5,
                                 'modes': ['plain', 'validation'], 'workload_warmup_ticks': 600, 'workload_measured_ticks': 7200,
                                 'capture_sha256': sha(raw / 'installed-public-current/capture.json'),
                                 'report_sha256': sha(raw / 'installed-public-current/report.json'),
                                 'qualification_identity': 'Candidate v9 is an immutable qualification input, execution_identity_claimed is false. Actual executing source is the after identity above.'},
    'performance_observations': {
        mode: {p.stem: {k: v for k, v in read(p.relative_to(raw)).items() if k != 'raw_samples'} for p in
               (raw / 'installed-public-current/raw' / mode / 'workloads').glob('*.json')}
        for mode in ['plain', 'validation']
    },
    'remaining_work': [
        'The complete unmodified capture fails the frozen performance acceptance. All observed stalls remain in the raw samples; the task card must not be marked done or this implementation merged.',
        'Investigate the existing public fence polling sleep and GPU execution cost. A Windows performance-only expansion beyond managed metadata ownership needs the release/replan/claim workflow before implementation.',
        'The five negative controls require a passing unmodified baseline; their statuses remain exactly as emitted by the canonical evaluator.',
    ],
    'source_audit': audit, 'closure_classification': closures,
    'frozen_candidate_check': (raw / 'frozen-candidate-current-check.log').read_text().strip(),
    'limitations': [
        'This is F8-76 repaired-source regression evidence on one physical Windows GTX 1080; it is not final F8-26 qualification or evidence for other physical devices.',
        'F8-74 must refreeze after the Metal F8-73 and Windows F8-76 production repairs; final Windows qualification requires a fresh F8-26 lease.',
        'public_oracle and work_budget closure hashes change because their native realtime test source gains validation/strict-selector routing. Existing numerical fixtures, tolerances, workloads and budget assertions are byte-identical.',
        'Original baseline raw source fields identify the capture harness checkout; the preserved baseline-source-provenance.json records the retained binary compiled-source identity from the authoritative F8-26 failure report.',
    ],
    'artifacts': {'archive': f'docs/roadmap/evidence/{stem}.zip', 'sha256': sha(archive), 'bytes': archive.stat().st_size,
                  'files': len(members) + 1, 'member_manifest': 'SHA256SUMS-current.json', 'member_manifest_sha256': sha(manifest_path),
                  'verification': 'ZIP CRC and every member SHA-256/size verified after writing; raw executable/driver hashes retained without binary payloads.'},
}
assert report['frozen_candidate_check'].startswith('PASS:')
dump(destination / (stem + '.json'), report)
notes = f'''# F8-76: Windows CUDA managed metadata repair

Windows GTX 1080 normal execution now passes all registered tests and the focused
ownership regressions. The complete public capture still fails frozen performance
acceptance, so **F8-76 remains incomplete; do not merge**. Actual executing source is
`{revision}`, tree `{after['source_tree']}`. This report does not qualify F8-26.

## Ownership diagnosis and repair

The device reports managed memory support with `concurrentManagedAccess=0`.
Retiring public frames does not retire earlier asynchronous native uploads.
The CPU therefore cannot inspect managed arenas merely because the public
runtime is idle.

PEG PAINT faults in `native_realtime_limits` while reading managed paint
liveness (baseline line 437). The installed `soft-body-fluid` case faults in
`add_fluid_soft_body_coupling` while traversing managed rest geometry (line
2137). Full regression and lifecycle execution also exposed rope/soft-body,
rope/cloth, smoke body/mesh identity, and public hit-box count accesses. Exact
symbols, source lines and exception parameters are in the JSON report and raw
archive; every retained failing-before control reports `0xc0000006` with
underlying status `0xc0000022` and no `CUDA_LAUNCH_BLOCKING` override.

Paint descriptors and immutable mesh/body identities now have ordinary host
owners. Device descriptors are published at resource edits, and retirement
completes before payload release. Three geometry/attachment constructors wait
at their CPU resource-edit boundary. The public hit-box query snapshots live
counts together before launching queries. Its host-result path gains one
batched completion boundary; no fixed-tick wait or readback is added.

The entire production realtime backend matches the original file except five
host metadata substitutions. Kernels, numerical equations, dispatches,
iterations, timestep, spatial publication and budget formulas remain unchanged.
The three constructor waits use `Services.wait_idle`, which may be device-wide;
they are outside fixed ticks and are not per-kernel synchronization.

## Acceptance evidence

- Fresh Release: **144/144 tests pass, zero skips**, retaining all original 130
  tests and adding 14 strict plain/validation ownership regressions.
- All 14 corresponding controls fail against the pinned earlier drivers.
- Relocated SDK: all 12 packaging/public ABI checks pass.
- Public SDK lifecycle probe, both modes: painted-fluid creation, five repeated
  ticks, rejected edit with identical public bytes, six-pixel field replacement,
  clear/reset; soft-body/fluid construction twice, ten ticks, two atomic rejected
  edits, reset/replacement and recovery. Each successful probe tick checks one
  advance, one publication and zero intra-tick host readbacks.
- Installed public capture retained in full, both modes: 30 cases, 12 scenarios,
  five desktop workloads and five negative controls, with 600 warmup and 7,200
  measured ticks per workload at frozen counts and limits. **The evaluator fails**;
  the JSON report contains every failure and the archive retains every sample.
- Candidate v9 checker passes; original manifest SHA-256 remains
  `4ed4ed7a097928944ac5667e8120e2447affda962a258e56c01dfd0d90d9dd4b`.

Reviewable evidence: [{stem}.json]({stem}.json) and
[{stem}.zip]({stem}.zip). Archive SHA-256:
`{report['artifacts']['sha256']}`. Every archived member is hash-verified.
The archive includes exact commands, source diff, binary/SDK hashes, JUnit,
raw public samples, lifecycle source/results, before controls and diagnosis.

## Remaining performance acceptance

The unchanged desktop physics p95 limit is 10 ms and frame budget is 16.667 ms.
The public workload critical path includes completion waits. The existing
`pmWaitForFences` loop sleeps for 50 microseconds between checks; the observations
show Windows timer-sized latency plateaus. This is a source/measurement lead,
not a proved causal attribution. Six-family GPU execution itself also exceeds
10 ms in this capture. Read-only GPU samples observed low clocks; no device power
or clock configuration was changed. These observations do not justify discarding
stalls, modifying measurement boundaries or increasing limits.

Performance-only implementation beyond the leased managed-metadata repair scope
requires release/replan/claim before editing. The five negative controls require
a passing unmodified baseline, so failed baseline acceptance also prevents those
controls from establishing success. Their exact emitted statuses are retained.

## Refreeze boundary

The closure classification records each changed file and each protected hash.
API/ABI, kernel, adapter binding and contract categories are unchanged by this
repair. Runtime and schedule/telemetry metadata ownership changes require
refreeze. The public oracle and work-budget closure hashes also change because
the native realtime test file gains validation and strict-selector routing;
its existing fixtures, assertions, tolerances and workloads are byte-identical.

The capture uses v9 as an immutable qualification input and explicitly sets
`execution_identity_claimed=false`. F8-74 must refreeze after F8-73 and F8-76;
final Windows qualification needs a fresh F8-26 lease. No other physical device
is qualified by this Windows run.

Baseline provenance is explicit: the original retained Release identity record
describes the evidence harness checkout. Its separate, preserved provenance
annotation identifies the actual compiled source from the authoritative F8-26
failure report. Neither the original raw record nor candidate v9 was rewritten.
'''
(destination / (stem + '.md')).write_text(notes, encoding='utf-8', newline='\n')
print(json.dumps({'report': str(destination / (stem + '.json')), 'report_sha256': sha(destination / (stem + '.json')),
                  'archive': report['artifacts'], 'source': revision, 'tests': suite, 'capture': evaluation}, indent=2))
