import hashlib
import json
import subprocess
from pathlib import Path

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f8-76-evidence-20261102')
base = '7e0e86a18255c36d649eef7017fa4badf194f296'
def original(relative): return subprocess.check_output(['git', 'show', f'{base}:{relative}']).decode()
relative = 'src/simulation/production_realtime_backend.cu.inc'
before = original(relative)
expected = before.replace('for (const auto &field : std::span(\n                 state.paint_fields, state.options.paint_field_capacity))',
                          'for (const auto &field : state.paint_fields_host)')
expected = expected.replace('state_.paint_fields[slot]', 'state_.paint_fields_host[slot]')
expected = expected.replace('state_.meshes[owner->mesh.index]', 'state_.mesh_slots[owner->mesh.index]')
assert expected == (root / relative).read_text()
cpp = 'tests/api/native_realtime_runtime_tests.cpp'
old = original(cpp)
changed = old.replace('''    const bool auxiliary_only = argc == 2 &&
        std::strcmp(argv[1], "--production-auxiliary") == 0;''', '''    const bool metadata_auxiliary_only = argc == 2 &&
        std::strcmp(argv[1], "--production-managed-auxiliary") == 0;
    const bool auxiliary_only = metadata_auxiliary_only || (argc == 2 &&
        std::strcmp(argv[1], "--production-auxiliary") == 0);''')
changed = changed.replace('    instance_info.apiVersion = PM_API_VERSION_0_3;', '''    instance_info.apiVersion = PM_API_VERSION_0_3;
    instance_info.enableValidation = std::getenv("PM_TEST_VALIDATION")
        ? PM_TRUE : PM_FALSE;''')
needle = '    if (production && !couplings_only && !smoke_couplings_only &&\n'
changed = changed.replace(needle, '''    if (metadata_auxiliary_only)
        CHECK(mixed_info.fluidCount != 0U && mixed_info.clothCount != 0U &&
              mixed_info.paintFieldCount != 0U && mixed_info.debugFrameCapacity != 0U);
''' + needle, 1)
assert changed == (root / cpp).read_text(), 'Unexpected existing fixture/assertion change'
query_file = (root / 'src/simulation/runtime_rigid.cu.inc').read_text()
query = query_file.split('Status SimulationRuntime::query_hit_box(', 1)[1].split('\nStatus SimulationRuntime::', 1)[0]
between = query.split('simulation::query_rigid_hit_box(', 1)[1].split('PmResult error = wait_queue(stream);', 1)[0]
assert '*owner->count' not in between
assert 'fluid_counts[slot]' in between
assert query.count('wait_queue(stream)') == 2
closure = json.loads((raw / 'closure-classification-current.json').read_text())
categories = {c['category']: c for c in closure['protected_closures']}
unchanged = ['api_abi','kernel','adapter_binding','contract']
assert all(not categories[c]['changed_by_F8_76'] for c in unchanged)
assert {c['path'] for c in categories['public_oracle']['changes']} == {cpp}
assert {c['path'] for c in categories['work_budget']['changes']} == {cpp}
report = {
    'source_revision': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'fixed_tick_backend': {'path': relative, 'before_sha256': hashlib.sha256(before.encode()).hexdigest(),
        'after_sha256': hashlib.sha256(expected.encode()).hexdigest(),
        'entire_file_matches_only_five_host_metadata_substitutions': True,
        'dispatches_iterations_timestep_publications_budget_formulas_unchanged': True,
        'no_added_fixed_tick_wait_or_readback': True},
    'public_oracle_test_harness': {'path': cpp, 'only_cli_validation_and_strict_auxiliary_selector_added': True,
        'existing_fixture_assertions_tolerances_workloads_byte_identical': True},
    'work_budget_closure': {'changed_file': cpp, 'change_is_test_routing_only': True,
        'existing_budget_assertions_and_production_budget_formulas_unchanged': True},
    'public_hit_box': {'no_managed_count_read_between_query_launches_and_existing_completion': True,
        'counts_snapshotted_together_at_public_readback_boundary': True,
        'query_wait_count_before': 1, 'query_wait_count_after': 2,
        'scope': 'Host-result query outside the fixed tick; no per-kernel wait or launch-count change.'},
    'resource_construction': 'Three CPU geometry/attachment constructors retire pending native work at resource-edit boundaries; no fixed-tick ownership blanket.',
    'unchanged_protected_categories': unchanged,
    'frozen_candidate_limits_and_fixtures_unchanged': True,
}
destination = raw / 'schedule-audit-current.json'
assert not destination.exists(), 'Retain existing evidence'
destination.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report,indent=2))
