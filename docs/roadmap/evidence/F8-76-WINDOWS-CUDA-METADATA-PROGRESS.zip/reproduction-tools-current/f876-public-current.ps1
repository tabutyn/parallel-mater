. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f876-env.ps1
$F876Build = 'D:/Repos/parallel-mater-f8-76-current-20261102'
$sdkOutput = "$F876Evidence/sdk-current"
$captureOutput = "$F876Evidence/installed-public-current"
$env:PATH = $F876Build + ';' + $env:PATH
Remove-Item Env:PM_TEST_VALIDATION -ErrorAction SilentlyContinue
if ((Test-Path -LiteralPath $sdkOutput) -or (Test-Path -LiteralPath $captureOutput)) { throw 'Retain existing evidence; use a new output directory' }
$sdkArgs = @('tools/check_sdk_install.py', '--build-dir', $F876Build, '--output', $sdkOutput, '--config', 'Release')
@{ executable = $F876Python; arguments = $sdkArgs } | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F876Evidence/sdk-current-command.json"
& $F876Python @sdkArgs *> "$F876Evidence/sdk-current.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F876Evidence/sdk-current.log" -Tail 25; exit $LASTEXITCODE }
$sdk = "$sdkOutput/relocated-sdk"
$env:PATH = "$sdk/bin;" + $env:PATH
$env:PM_DRIVER_FILES = "$sdk/share/parallel-mater/drivers.d/parallel_mater_slang_cuda.json"
$env:PM_LAYER_FILES = "$sdk/share/parallel-mater/layers.d/parallel_mater_validation.json"
$probe = "$F876Evidence/lifecycle-current-probe.exe"
$compile = @('/nologo','/std:c++20','/EHsc','/O2',"/I$sdk/include","/I$F876Evidence/lifecycle-source-v5",
    "$F876Evidence/lifecycle-source-v5/lifecycle.cpp","/Fe$probe","/Fo$F876Evidence/lifecycle-current-probe.obj",
    '/link',"/LIBPATH:$sdk/lib",'parallel-mater.lib')
@{ executable = (Get-Command cl).Source; arguments = $compile; private_source_includes = $false } | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F876Evidence/lifecycle-current-build-command.json"
cl @compile *> "$F876Evidence/lifecycle-current-build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F876Evidence/lifecycle-current-build.log" -Tail 20; exit $LASTEXITCODE }
$observations = @()
foreach ($mode in @('plain','validation')) {
    if ($mode -eq 'validation') { $env:PM_TEST_VALIDATION = '1' } else { Remove-Item Env:PM_TEST_VALIDATION -ErrorAction SilentlyContinue }
    $watch = [Diagnostics.Stopwatch]::StartNew()
    & $probe --production-auxiliary *> "$F876Evidence/lifecycle-current-$mode.log"
    $code = $LASTEXITCODE
    $watch.Stop()
    $observation = [ordered]@{ mode = $mode; exit_code = $code; elapsed_seconds = $watch.Elapsed.TotalSeconds; command = @($probe,'--production-auxiliary'); debugger = $false; cuda_launch_blocking = $null; probe_sha256 = (Get-FileHash -Algorithm SHA256 $probe).Hash.ToLowerInvariant(); driver_manifest = $env:PM_DRIVER_FILES; validation_layer_manifest = $env:PM_LAYER_FILES }
    $observation | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F876Evidence/lifecycle-current-$mode-result.json"
    Get-Content "$F876Evidence/lifecycle-current-$mode.log" -Tail 5
    if ($code -ne 0) { exit $code }
    $probeLog = Get-Content "$F876Evidence/lifecycle-current-$mode.log" -Raw
    if (-not $probeLog.Contains('F8_76_PAINT_LIFECYCLE') -or -not $probeLog.Contains('F8_76_SOFT_FLUID_LIFECYCLE')) { throw "Required lifecycle checks did not run in $mode" }
    $observations += $observation
}
$observations | ConvertTo-Json -Depth 6 | Set-Content -Encoding utf8 "$F876Evidence/lifecycle-current-results.json"
Remove-Item Env:PM_TEST_VALIDATION -ErrorAction SilentlyContinue
$captureArgs = @('conformance/v1/realtime_device_capture.py','--runner',"$sdk/bin/parallel-mater-conformance.exe",
    '--driver-manifest',$env:PM_DRIVER_FILES,'--validation-layer-manifest',$env:PM_LAYER_FILES,
    '--runtime-variant','cuda-runtime','--target-id','windows-gtx1080-slang-cuda','--output',$captureOutput)
@{ executable = $F876Python; arguments = $captureArgs; source_revision = (git rev-parse HEAD); purpose = 'F8-76 repaired-source regression comparison, not final F8-26 qualification'; cuda_launch_blocking = $null } | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F876Evidence/installed-public-current-command.json"
& $F876Python @captureArgs *> "$F876Evidence/installed-public-current.log"
$code = $LASTEXITCODE
Get-Content "$F876Evidence/installed-public-current.log" -Tail 12
exit $code
