import hashlib
import importlib.util
import io
import json
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f8-76-evidence-20261102')
before = '7e0e86a18255c36d649eef7017fa4badf194f296'
after = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
manifest_path = root / 'conformance/v1/qualification/realtime-candidate-v9.json'
candidate = json.loads(manifest_path.read_text())
spec = importlib.util.spec_from_file_location('checker', root / 'tools/check_realtime_candidate.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
explanations = {
    'CMakeLists.txt': 'Register fourteen public-scene/auxiliary ownership regressions; production configuration and workload parameters unchanged.',
    'src/simulation/runtime.cpp': 'Own paint descriptors and mesh generation/liveness identities in ordinary host storage; retain existing GPU storage and capacities.',
    'src/simulation/runtime_deformables.cu.inc': 'Publish/retire paint descriptors at resource-edit boundaries; acquire CPU arena ownership once when constructing fluid/soft-body, rope/soft-body and rope/cloth couplings. Publish host mesh identities with existing mesh lifecycle.',
    'src/simulation/runtime_rigid.cu.inc': 'Retain immutable body-to-mesh identity in host slots and validate paint references through host descriptors. Snapshot live particle counts at the public hit-box readback boundary before asynchronous query launches.',
    'src/simulation/runtime_domains.cu.inc': 'Read immutable host body-to-mesh identity when constructing smoke/rigid coupling.',
    'src/simulation/production_realtime_backend.cu.inc': 'Read host metadata in telemetry-limit planning, paint boundary backup, abort restoration and smoke coupling mesh validation. Dispatch sequence, numerical equations and budget values unchanged.',
    'tests/gallery/command_gallery_tests.cpp': 'Request the validation layer for explicit validation regression executions.',
    'tests/api/native_realtime_runtime_tests.cpp': 'Enable explicit validation executions and a strict auxiliary regression selector; existing fixtures, assertions and tolerances unchanged.',
}
def sha(data): return hashlib.sha256(data).hexdigest()
def extract(revision, path):
    data = subprocess.check_output(['git', 'archive', '--format=tar', revision])
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        archive.extractall(path, filter='data')
def files(base, patterns):
    return {p.relative_to(base).as_posix(): p for pattern in patterns for p in base.glob(pattern) if p.is_file()}
closures = []
with tempfile.TemporaryDirectory(prefix='f876-closures-') as temporary:
    base = Path(temporary)
    snapshots = {}
    for label, revision in [('before', before), ('after', after), ('frozen', candidate['source']['revision'])]:
        snapshots[label] = base / label
        snapshots[label].mkdir()
        extract(revision, snapshots[label])
    for closure in candidate['source']['protected_closures']:
        identities = {label: dict(zip(['file_count', 'sha256'], checker.closure_identity(path, closure['patterns']))) for label, path in snapshots.items()}
        assert identities['frozen'] == {'file_count': closure['file_count'], 'sha256': closure['sha256']}
        old, new = [files(snapshots[label], closure['patterns']) for label in ['before', 'after']]
        changes = []
        for relative in sorted(old.keys() | new.keys()):
            a = old[relative].read_bytes() if relative in old else None
            b = new[relative].read_bytes() if relative in new else None
            if a != b:
                assert relative in explanations, relative
                changes.append({'path': relative, 'before_sha256': sha(a) if a is not None else None,
                                'after_sha256': sha(b) if b is not None else None, 'classification': explanations[relative]})
        closures.append({'category': closure['category'], 'patterns': closure['patterns'],
                         'frozen_identity_verified': True, 'identities': identities,
                         'changed_by_F8_76': bool(changes), 'changes': changes})
changed = subprocess.check_output(['git', 'diff', '--name-only', before, after], text=True).splitlines()
assert set(changed) == set(explanations), changed
immutable = ['conformance/v1/qualification/realtime-candidate-v9.json',
             'conformance/v1/qualification/active-realtime-candidate.json',
             'conformance/v1/qualification/realtime-profile-v1.json',
             'conformance/v1/realtime/scenario-fixtures-v1.json']
assert not subprocess.check_output(['git', 'diff', '--name-only', before, after, '--', *immutable]).strip()
assert sha(manifest_path.read_bytes()) == '4ed4ed7a097928944ac5667e8120e2447affda962a258e56c01dfd0d90d9dd4b'
report = {'before_revision': before, 'after_revision': after,
          'after_tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
          'method': 'SHA-256 over clean Git archives; ignored/generated cache files excluded.',
          'candidate_v9_manifest_unchanged': True, 'frozen_limits_and_fixtures_unchanged': True,
          'changed_files': [{'path': p, 'classification': explanations[p]} for p in changed],
          'protected_closures': closures,
          'qualification_status': 'F8-76 repair regression only. Changed source requires F8-74 refreeze and a fresh F8-26 qualification lease.'}
name = 'closure-classification-current.json' if '--current' in sys.argv else ('closure-classification-final.json' if '--final' in sys.argv else 'closure-classification.json')
output = raw / name
assert not output.exists(), 'Retain existing evidence'
output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'after_revision': after, 'categories': [{k: c[k] for k in ['category', 'changed_by_F8_76']} for c in closures]}, indent=2))
