import ctypes as C
from ctypes import wintypes as W
import json
import struct
import sys
from pathlib import Path

class Symbol(C.Structure):
    _fields_ = [('SizeOfStruct', W.ULONG), ('TypeIndex', W.ULONG),
                ('Reserved', C.c_ulonglong * 2), ('Index', W.ULONG),
                ('Size', W.ULONG), ('ModBase', C.c_ulonglong),
                ('Flags', W.ULONG), ('Value', C.c_ulonglong),
                ('Address', C.c_ulonglong), ('Register', W.ULONG),
                ('Scope', W.ULONG), ('Tag', W.ULONG),
                ('NameLen', W.ULONG), ('MaxNameLen', W.ULONG),
                ('Name', C.c_char * 2048)]

class Line(C.Structure):
    _fields_ = [('SizeOfStruct', W.DWORD), ('Key', C.c_void_p),
                ('LineNumber', W.DWORD), ('FileName', C.c_wchar_p),
                ('Address', C.c_ulonglong)]

dbg = C.WinDLL('dbghelp', use_last_error=True)
dbg.SymInitializeW.argtypes = [W.HANDLE, W.LPCWSTR, W.BOOL]
dbg.SymInitializeW.restype = W.BOOL
dbg.SymLoadModuleExW.argtypes = [W.HANDLE, W.HANDLE, W.LPCWSTR, W.LPCWSTR, C.c_ulonglong, W.DWORD, C.c_void_p, W.DWORD]
dbg.SymLoadModuleExW.restype = C.c_ulonglong
dbg.SymFromAddr.argtypes = [W.HANDLE, C.c_ulonglong, C.POINTER(C.c_ulonglong), C.POINTER(Symbol)]
dbg.SymFromAddr.restype = W.BOOL
dbg.SymGetLineFromAddrW64.argtypes = [W.HANDLE, C.c_ulonglong, C.POINTER(W.DWORD), C.POINTER(Line)]
dbg.SymGetLineFromAddrW64.restype = W.BOOL
process = W.HANDLE(-1)
dbg.SymSetOptions(0x10 | 0x4 | 0x2 | 0x80000)
assert dbg.SymInitializeW(process, str(Path(sys.argv[2])), False), C.get_last_error()
record = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8-sig'))
loaded = []
for module in record['modules']:
    path = Path(module['path'].removeprefix('\\\\?\\'))
    if 'parallel' not in path.name.lower() or not path.is_file():
        continue
    blob = path.read_bytes()
    pe = struct.unpack_from('<I', blob, 0x3c)[0]
    size = struct.unpack_from('<I', blob, pe + 0x50)[0]
    base = int(module['base'], 16)
    result = dbg.SymLoadModuleExW(process, None, str(path), None, base, size, None, 0)
    loaded.append({'path': str(path), 'base': base, 'size': size, 'loaded': bool(result), 'error': C.get_last_error() if not result else 0})
for exception in record['exceptions']:
    address = int(exception['address'], 16)
    module = next((m for m in loaded if m['base'] <= address < m['base'] + m['size']), None)
    exception['module'] = module
    symbol = Symbol()
    symbol.SizeOfStruct, symbol.MaxNameLen = 88, 2048
    displacement = C.c_ulonglong()
    if dbg.SymFromAddr(process, address, C.byref(displacement), C.byref(symbol)):
        exception['symbol'] = symbol.Name.decode(errors='replace')
        exception['symbol_offset'] = displacement.value
    else:
        exception['symbol_error'] = C.get_last_error()
    line = Line()
    line.SizeOfStruct = C.sizeof(Line)
    offset = W.DWORD()
    if dbg.SymGetLineFromAddrW64(process, address, C.byref(offset), C.byref(line)):
        exception['source'] = {'file': line.FileName, 'line': line.LineNumber, 'offset': offset.value}
    else:
        exception['source_error'] = C.get_last_error()
record['symbol_modules'] = loaded
output = Path(sys.argv[1]).with_name(Path(sys.argv[1]).stem + '-symbols.json')
output.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(record['exceptions'], indent=2))
