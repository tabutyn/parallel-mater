// Generated from scenario-fixtures-v1.json; do not edit.
#pragma once
#include <array>
#include <cstdint>
#include <string_view>
namespace parallel_mater::realtime_fixture_contract {
struct Scenario {
    std::string_view id;
    std::string_view builder;
    std::uint32_t ticks;
    std::uint32_t domain_count;
    std::uint32_t tag_count;
};
inline constexpr std::string_view id = "fixed-tick-public-scenarios-v1";
inline constexpr std::string_view sha256 = "564fff6a2fefdf3647fdee66ddca1d826532081712729b539e851828583c07de";
inline constexpr float timestep_seconds = 1.0F / 60.0F;
inline constexpr std::uint32_t substeps = 1U;
inline constexpr std::uint32_t measurement_count = 37U;
inline constexpr std::array<std::string_view, 5> runtime_variants{{
    "cpu-runtime",
    "cuda-runtime",
    "vulkan-runtime",
    "d3d12-runtime",
    "metal-runtime",
}};
inline constexpr std::array<Scenario, 12> scenarios{{
    Scenario{"rigid-cold-impact-rotation", "conformance-case", 120U, 1U, 5U},
    Scenario{"rigid-settled-long-run", "installed-public-analytic", 3600U, 1U, 1U},
    Scenario{"fluid-closed-container-source-outflow", "installed-public-analytic", 600U, 1U, 4U},
    Scenario{"cloth-stiff-pin-impact", "installed-public-analytic", 600U, 1U, 3U},
    Scenario{"soft-body-mass-ratio-volume", "installed-public-analytic", 600U, 1U, 3U},
    Scenario{"rope-attachment-rotation", "conformance-case", 600U, 1U, 3U},
    Scenario{"smoke-analytic-transport-long-run", "installed-public-analytic", 3600U, 1U, 3U},
    Scenario{"fluid-cloth-rigid-containment", "installed-public-analytic", 600U, 3U, 3U},
    Scenario{"six-family-mixed", "public-mixed-scene-v1", 600U, 6U, 5U},
    Scenario{"boundary-replacement-generation", "public-mixed-scene-v1", 4U, 3U, 3U},
    Scenario{"capacity-overflow-atomic-recovery", "public-adverse-capacity-v1", 3U, 3U, 2U},
    Scenario{"empty-and-sparse-capacity", "public-mixed-scene-v1", 2U, 6U, 2U},
}};
} // namespace parallel_mater::realtime_fixture_contract
