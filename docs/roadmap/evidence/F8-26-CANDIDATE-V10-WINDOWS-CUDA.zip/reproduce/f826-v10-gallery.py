"""Exercise every installed Gallery scene plus normal interactive presentation."""
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from datetime import datetime, timezone

frozen = Path('C:/Users/tabut/Repos/ballroller-2026/.codex-worktrees/parallel-mater-f826-v10-source-20261104')
raw = Path('D:/Repos/parallel-mater-f826-v10-evidence-20261104')
installed = Path(os.environ['LOCALAPPDATA']) / 'Programs/Parallel-Mater'
output = raw / 'gallery'
assert not output.exists(), output
output.mkdir()
manifest_path = installed / 'installation.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8-sig'))
assert manifest['state'] == 'installed'
assert manifest['revision'] == '5bacbe2b1e0fbfad565fb9477bb6873396e31d5d'
for name, expected in manifest['hashes'].items():
    assert hashlib.sha256((installed / name).read_bytes()).hexdigest() == expected.lower(), name
executable = installed / 'Parallel-Mater.exe'
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = subprocess.SW_HIDE
environment = dict(os.environ)
for name in ('PM_DRIVER_FILES', 'PM_LAYER_FILES', 'PM_ENABLE_LAYERS', 'PM_TEST_VALIDATION', 'CUDA_LAUNCH_BLOCKING'):
    environment.pop(name, None)
version = subprocess.check_output([str(executable), '--version'], cwd=installed,
    env=environment, text=True, startupinfo=startup, creationflags=subprocess.CREATE_NO_WINDOW).strip()
assert manifest['revision'] in version and version == manifest['reportedVersion']
context = (frozen / 'examples/support/include/parallel_mater_gallery/gallery_context.hpp').read_text()
entries = context.split('inline constexpr std::array gallery_entries{', 1)[1].split('\n};', 1)[0]
scenes = []
for block in entries.split('GalleryEntry{')[1:]:
    identity = re.search(r'"([^"]+)"', block).group(1)
    option = re.search(r'"(--[^"]+)"', block)
    scenes.append((identity, [option.group(1)] if option else []))
assert len(scenes) == 28, len(scenes)
report = {
    'source_revision': manifest['revision'], 'installed_path': str(installed),
    'version': version, 'manifest': manifest,
    'manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
    'scope': 'All catalog scenes use their normal defaults for three headless simulation/render frames. A six-frame interactive smoke exercises the installed startup/presentation path. Frozen workload qualification runs separately.',
    'executions': [], 'status': 'running',
}
report_path = raw / 'gallery-report.json'
try:
    runs = [('headless', identity, options, 3) for identity, options in scenes]
    runs.append(('interactive', 'rigid-body', [], 6))
    for mode, identity, options, frames in runs:
        stem = mode + '-' + identity
        image = output / (stem + '.ppm')
        timings = output / (stem + '.csv')
        capture_flag = '--headless' if mode == 'headless' else '--interactive-smoke'
        command = [str(executable), '--backend', 'cuda', *options, '--frames', str(frames),
                   capture_flag, str(image), '--frame-timings', str(timings)]
        completed = subprocess.run(command, cwd=installed, env=environment,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=300,
            startupinfo=startup, creationflags=subprocess.CREATE_NO_WINDOW)
        log = output / (stem + '.log')
        log.write_text(completed.stdout, encoding='utf-8')
        result = {'mode': mode, 'scene': identity, 'command': command,
                  'exit_code': completed.returncode, 'log': log.name}
        report['executions'].append(result)
        assert completed.returncode == 0, (identity, completed.stdout[-1500:])
        assert image.is_file() and image.stat().st_size > 1000, identity
        assert image.read_bytes().startswith(b'P6'), identity
        with timings.open(newline='', encoding='utf-8-sig') as stream:
            rows = list(csv.DictReader(stream))
        assert len(rows) == frames, (identity, len(rows))
        steps = [int(row['physics_steps']) for row in rows]
        assert all(step == 1 for step in steps) if mode == 'headless' else all(0 <= step <= 1 for step in steps)
        assert all(row['mode'] == mode for row in rows)
        result.update({'frames': frames, 'physics_steps': steps,
            'image': image.name, 'image_sha256': hashlib.sha256(image.read_bytes()).hexdigest(),
            'timings': timings.name, 'timings_sha256': hashlib.sha256(timings.read_bytes()).hexdigest()})
        report_path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
        print(f'{mode} {identity}: {frames} frames passed', flush=True)
    report['status'] = 'passed'
finally:
    report['finished_at'] = datetime.now(timezone.utc).isoformat()
    report_path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
