"""Assemble the installer layout from hash-verified frozen Ninja outputs."""
import hashlib
import json
from pathlib import Path
import shutil

raw = Path('D:/Repos/parallel-mater-f826-v10-evidence-20261104')
build = Path('D:/Repos/parallel-mater-f878-integration-build-20261103')
frozen = Path('C:/Users/tabut/Repos/ballroller-2026/.codex-worktrees/parallel-mater-f826-v10-source-20261104')
stage = raw / 'gallery-install-stage'
assert not stage.exists(), stage
identity = json.loads((raw / 'identity.json').read_text())
files = {'Parallel-Mater.exe': build / 'Parallel-Mater.exe'}
files.update({path.name: path for path in build.glob('*.dll')})
for name, path in files.items():
    assert hashlib.sha256(path.read_bytes()).hexdigest() == identity['retained_build_artifacts_verified'][name]['sha256'], name
for path in (build / 'assets').glob('*.glb'):
    assert path.read_bytes() == (frozen / 'examples/assets' / path.name).read_bytes(), path.name
    files['assets/' + path.name] = path
profile = build / 'config/device-profiles.json'
assert profile.read_bytes() == (frozen / 'config/device-profiles.json').read_bytes()
files['config/device-profiles.json'] = profile
for path in (build / 'Release/manifests/portable').glob('*.json'):
    files['manifests/portable/' + path.name] = path
assert 'manifests/portable/slang-cuda.json' in files
assert 'manifests/portable/validation.json' in files
mapping = {}
for name, path in files.items():
    target = stage / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    assert hashlib.sha256(target.read_bytes()).hexdigest() == sha
    mapping[name] = {'source': str(path), 'sha256': sha, 'bytes': path.stat().st_size}
report = {
    'stage': str(stage), 'files': mapping,
    'reason': 'The Ninja build places executables at its root and portable manifests under Release/manifests. The frozen installer expects both under one BuildDirectory. This staging copies those generated outputs into that layout without changing their bytes.',
    'assets_and_device_profiles_match_frozen_source': True,
}
(raw / 'gallery-install-staging.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(f'Prepared {len(files)} verified install files')
