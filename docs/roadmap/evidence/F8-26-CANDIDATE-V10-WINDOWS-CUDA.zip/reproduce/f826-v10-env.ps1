$ErrorActionPreference = 'Stop'
$F826V10Source = 'C:/Users/tabut/Repos/ballroller-2026/.codex-worktrees/parallel-mater-f826-v10-20261104'
$F826V10Frozen = 'C:/Users/tabut/Repos/ballroller-2026/.codex-worktrees/parallel-mater-f826-v10-source-20261104'
$F826V10Build = 'D:/Repos/parallel-mater-f878-integration-build-20261103'
$F826V10Evidence = 'D:/Repos/parallel-mater-f826-v10-evidence-20261104'
$F826V10Python = 'C:/Users/tabut/AppData/Local/Programs/Python/Python313/python.exe'
& 'C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation | Out-Null
$env:PATH = 'C:/Users/tabut/AppData/Local/Programs/Python/Python313;C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja;C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v12.9/bin;' + $env:PATH
$env:GIT_CONFIG_COUNT = '4'
$env:GIT_CONFIG_KEY_0 = 'safe.directory'
$env:GIT_CONFIG_VALUE_0 = $F826V10Source
$env:GIT_CONFIG_KEY_1 = 'safe.directory'
$env:GIT_CONFIG_VALUE_1 = $F826V10Frozen
$env:GIT_CONFIG_KEY_2 = 'safe.directory'
$env:GIT_CONFIG_VALUE_2 = 'C:/Users/tabut/Repos/ballroller-2026/.codex-worktrees/parallel-mater-f8-performance-deferral-20261103'
$env:GIT_CONFIG_KEY_3 = 'core.autocrlf'
$env:GIT_CONFIG_VALUE_3 = 'false'
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
foreach ($name in @('CUDA_LAUNCH_BLOCKING','PM_DRIVER_FILES','PM_LAYER_FILES','PM_ENABLE_LAYERS','PM_TEST_VALIDATION')) {
    Remove-Item "Env:$name" -ErrorAction SilentlyContinue
}
Set-Location -LiteralPath $F826V10Source
