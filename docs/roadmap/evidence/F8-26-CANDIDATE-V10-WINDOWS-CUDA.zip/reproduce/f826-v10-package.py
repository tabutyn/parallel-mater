"""Accept retained exact-source results under the merged F8-26 scene deferral."""
import hashlib
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone
import zipfile

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f826-v10-evidence-20261104')
build = Path('D:/Repos/parallel-mater-f878-integration-build-20261103')
temporary = Path('C:/Users/tabut/Repos/ballroller-2026/.codex-tmp')
destination = root / 'docs/roadmap/evidence'
archive = destination / 'F8-26-CANDIDATE-V10-WINDOWS-CUDA.zip'
output = destination / 'F8-26-CANDIDATE-V10-WINDOWS-CUDA.json'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()


assert not archive.exists() and not output.exists()
assert not git('status', '--porcelain')
task_path = root / 'docs/roadmap/tasks/F8-26.json'
task = read(task_path)
canonical = json.loads(git('show', 'origin/main:docs/roadmap/tasks/F8-26.json'))
assert task == canonical
assert task['status'] == 'leased' and task['lease']['token'] == '2ea51857-9fb2-4fc2-9aff-d5917efde830'
assert git('rev-parse', '--abbrev-ref', 'HEAD') == task['lease']['branch']
assert datetime.now(timezone.utc) < datetime.fromisoformat(task['lease']['expires_at'].replace('Z', '+00:00'))
assert 'F9-09' in task['scope'] and any('7 texels' in item for item in task['acceptance'])
assert read(root / 'docs/roadmap/tasks/F9-09.json')['status'] == 'deferred'
report = read(raw / 'qualification-evaluation.json')
assert report['status'] == 'incomplete_under_original_gallery_contract'
assert report['candidate']['manifest_sha256'] == digest(root / report['candidate']['manifest'])
assert report['candidate']['source_revision'] == '5bacbe2b1e0fbfad565fb9477bb6873396e31d5d'
assert report['registered_tests']['passed'] == 146 and report['registered_tests']['skipped'] == 0
assert len(report['registered_tests']['cuda_labeled_tests']) == 58
assert report['relocated_sdk']['status'] == 'passed' and len(report['relocated_sdk']['checks']) == 12
assert all(row['correctness_work_recovery_passed'] for row in report['capture']['modes'].values())
assert report['capture']['measured_ticks_total'] == 72000
gallery = report['installed_gallery']
assert gallery['failed_scenes'] == ['peg-paint'] and len(gallery['executions']) == 29
assert sum(row['exit_code'] == 0 for row in gallery['executions']) == 28
debt = read(root / 'docs/roadmap/evidence/F8-26-CANDIDATE-V10-GALLERY-DEBT.json')
assert debt['completed_frames'] == 240 and debt['observed_painted_texels'] == 7
assert debt['required_painted_texels'] == 100 and debt['capacity_overflows'] == 0
assert debt['stdout_sha256'] == gallery['known_scene_quality_failure']['log_sha256']
assert debt['timing_csv_sha256'] == gallery['known_scene_quality_failure']['timings_sha256']
for name, identity in report['build_artifacts'].items():
    assert digest(build / name) == identity['sha256'], name
installed = Path(gallery['installed_path'])
assert digest(installed / 'installation.json') == gallery['manifest_sha256']
for name, expected in gallery['manifest']['hashes'].items():
    assert digest(installed / name) == expected.lower(), name
sdk = raw / 'sdk/relocated-sdk'
metadata = {row['path']: row['after'] for row in report['installed_freeze_metadata']['changes']}
for name, expected in report['relocated_sdk']['sdk_sha256'].items():
    normalized = name.replace('\\', '/')
    assert digest(sdk / name) == metadata.get(normalized, expected), name
for name, expected in metadata.items():
    assert digest(sdk / name) == expected, name

report['schema'] = 'parallel-mater-realtime-device-qualification/v2'
report['status'] = 'passed_with_disclosed_scene_and_timing_debt'
report['captured_at'] = report['capture']['finished_at']
report['accepted_at'] = datetime.now(timezone.utc).isoformat()
report['physical_execution_lease_token'] = report['lease_token']
report['physical_execution_claim_pr'] = report['claim_pr']
report['lease_token'] = task['lease']['token']
report['claim_pr'] = 'https://github.com/tabutyn/parallel-mater/pull/668'
report['scope_plan_pr'] = 'https://github.com/tabutyn/parallel-mater/pull/667'
report['release_pr'] = 'https://github.com/tabutyn/parallel-mater/pull/665'
report['acceptance_contract'] = {
    'card_sha256': digest(task_path), 'acceptance': task['acceptance'],
    'metadata_revision': git('rev-parse', 'HEAD'),
    'retained_original_evaluation_sha256': digest(raw / 'qualification-evaluation.json'),
    'adoption': 'Fresh physical executions were recorded under the earlier lease on the exact frozen v10 source. The release, planning and new claim change acceptance metadata. Original results remain intact.',
}
report['verdicts'] = {
    'f8_windows_cuda_integration': 'passed',
    'gallery_scene_quality': 'PEG PAINT failed, assigned to F9-09',
    'performance': 'timing targets and canonical control qualification deferred to F9-07/F9-08',
}
report['candidate']['active_pointer_sha256'] = digest(root / 'conformance/v1/qualification/active-realtime-candidate.json')
report['candidate']['evidence_union_allowed'] = False
report['scene_debt'] = {
    'task': 'F9-09', 'report': 'docs/roadmap/evidence/F8-26-CANDIDATE-V10-GALLERY-DEBT.json',
    'sha256': digest(root / 'docs/roadmap/evidence/F8-26-CANDIDATE-V10-GALLERY-DEBT.json'),
}
report['visual_verification'] = {
    'capture': 'previews/interactive-rigid-body.png',
    'observed': 'Installed interactive capture renders the rigid scene and timing overlay with one displayed physics step. Scene-quality repair remains separate.',
}

files = {}
for path in sorted(raw.rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(raw)
    if relative.parts[0] == 'gallery-install-stage':
        continue
    if relative.parts[0] == 'sdk' and len(relative.parts) != 2:
        continue
    files[relative.as_posix()] = path
for name in ('f826-v10-env.ps1', 'f826-v10-prepare.py', 'f826-v10-sdk-metadata.py',
             'f826-v10-run.ps1', 'f826-v10-gallery-stage.py', 'f826-v10-install-gallery.ps1',
             'f826-v10-gallery.py', 'f826-v10-gallery-full.py', 'f826-v10-gallery-audit.py',
             'f826-v10-preview.py', 'f826-v10-evaluate.py', 'f826-v10-package.py'):
    files['reproduce/' + name] = temporary / name
members = {}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for name, path in files.items():
        data = path.read_bytes()
        members[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        stream.writestr(name, data)
    stream.writestr('archive-members.json', json.dumps(members, indent=2) + '\n')
with zipfile.ZipFile(archive) as stream:
    assert stream.testzip() is None
    assert set(stream.namelist()) == set(members) | {'archive-members.json'}
    for name, identity in members.items():
        data = stream.read(name)
        assert len(data) == identity['bytes']
        assert hashlib.sha256(data).hexdigest() == identity['sha256']
assert archive.stat().st_size < 99 * 1024 * 1024
report['artifacts'] = {
    'archive': archive.relative_to(root).as_posix(), 'bytes': archive.stat().st_size,
    'sha256': digest(archive), 'files': len(members), 'all_member_hashes_verified': True,
    'contents': 'Complete fresh captures, original failures, separate mode/control diagnostics, Gallery images/frame records, installer staging and deployment identities, test/SDK logs and reproduction scripts.',
}
output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'status': report['status'], 'artifacts': report['artifacts']}, indent=2))
