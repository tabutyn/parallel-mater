. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f826-v10-env.ps1
if (!(Test-Path -LiteralPath "$F826V10Evidence/identity.json")) { throw 'Exact source and binary identity must be verified first' }
if (Test-Path -LiteralPath "$F826V10Evidence/ctest.log") { throw 'Retain previous run evidence' }
$env:PATH = "$F826V10Build;" + $env:PATH
Write-Output 'F8-26 fresh registered tests on exact-source Release binaries'
ctest --test-dir $F826V10Build --show-only=json-v1 *> "$F826V10Evidence/registered-tests.json"
ctest --test-dir $F826V10Build --output-on-failure --no-tests=error -j 1 --output-junit "$F826V10Evidence/ctest.xml" *> "$F826V10Evidence/ctest.log"
$testCode = $LASTEXITCODE
Copy-Item -LiteralPath "$F826V10Build/Testing/Temporary/LastTest.log" -Destination "$F826V10Evidence/last-test.log"
Get-Content "$F826V10Evidence/ctest.log" -Tail 12
if ($testCode -ne 0) { exit $testCode }
Write-Output 'F8-26 fresh SDK relocation and independent consumers'
Set-Location -LiteralPath $F826V10Frozen
& $F826V10Python tools/check_sdk_install.py --build-dir $F826V10Build --output "$F826V10Evidence/sdk" --config Release *> "$F826V10Evidence/sdk.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F826V10Evidence/sdk.log" -Tail 25; exit $LASTEXITCODE }
Set-Location -LiteralPath $F826V10Source
& $F826V10Python C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f826-v10-sdk-metadata.py *> "$F826V10Evidence/sdk-freeze-metadata.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F826V10Evidence/sdk-freeze-metadata.log" -Tail 20; exit $LASTEXITCODE }
$sdk = "$F826V10Evidence/sdk/relocated-sdk"
$env:PATH = "$sdk/bin;" + $env:PATH
$capture = @("$sdk/share/parallel-mater/conformance/v1/realtime_device_capture.py",'--runner',"$sdk/bin/parallel-mater-conformance.exe",
    '--driver-manifest',"$sdk/share/parallel-mater/drivers.d/parallel_mater_slang_cuda.json",
    '--validation-layer-manifest',"$sdk/share/parallel-mater/layers.d/parallel_mater_validation.json",
    '--runtime-variant','cuda-runtime','--target-id','windows-gtx1080-slang-cuda','--output',"$F826V10Evidence/capture")
@{executable=$F826V10Python; arguments=$capture; cuda_launch_blocking=$null} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F826V10Evidence/capture-command.json"
Write-Output 'F8-26 fresh v10 installed-public capture'
& $F826V10Python @capture *> "$F826V10Evidence/capture.log"
$captureCode = $LASTEXITCODE
@{exit_code=$captureCode; finished_at=[DateTimeOffset]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -Encoding utf8 "$F826V10Evidence/capture-result.json"
Get-Content "$F826V10Evidence/capture.log" -Tail 15
if ($captureCode -gt 1 -or -not (Test-Path -LiteralPath "$F826V10Evidence/capture/report.json")) { exit 2 }
& $F826V10Python "$sdk/share/parallel-mater/conformance/v1/realtime_device_suite.py" --capture "$F826V10Evidence/capture/capture.json" --candidate-manifest "$sdk/share/parallel-mater/conformance/v1/qualification/realtime-candidate-v10.json" --output "$F826V10Evidence/independent-report.json" *> "$F826V10Evidence/independent-validation.log"
$validationCode = $LASTEXITCODE
if ($validationCode -gt 1 -or -not (Test-Path -LiteralPath "$F826V10Evidence/independent-report.json")) { exit 2 }
Write-Output 'F8-26 capture complete for separate correctness/timing review'
