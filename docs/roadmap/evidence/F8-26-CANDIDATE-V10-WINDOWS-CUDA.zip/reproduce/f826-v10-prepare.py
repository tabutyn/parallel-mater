"""Verify the frozen source and retained exact-source build before fresh execution."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

root = Path.cwd()
frozen = Path('C:/Users/tabut/Repos/ballroller-2026/.codex-worktrees/parallel-mater-f826-v10-source-20261104')
build = Path('D:/Repos/parallel-mater-f878-integration-build-20261103')
raw = Path('D:/Repos/parallel-mater-f826-v10-evidence-20261104')
expected_revision = '5bacbe2b1e0fbfad565fb9477bb6873396e31d5d'
expected_manifest = '29e051d94a89a39d51c2128b212165d60da6da7de4b2c107a72ae7cc5b77f20a'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(directory, *args):
    return subprocess.check_output(['git', '-C', str(directory), *args], text=True).strip()


task = read(root / 'docs/roadmap/tasks/F8-26.json')
assert task['lease']['token'] == '1ebf889f-b148-449a-bf31-cf46b413c729'
assert datetime.now(timezone.utc) < datetime.fromisoformat(task['lease']['expires_at'].replace('Z', '+00:00'))
assert not git(root, 'status', '--porcelain')
assert git(frozen, 'rev-parse', 'HEAD') == expected_revision
assert not git(frozen, 'status', '--porcelain')
candidate_path = root / 'conformance/v1/qualification/realtime-candidate-v10.json'
assert digest(candidate_path) == expected_manifest
candidate = read(candidate_path)
assert candidate['source']['revision'] == expected_revision
assert git(frozen, 'rev-parse', 'HEAD^{tree}') == candidate['source']['tree']
previous_path = root / 'docs/roadmap/evidence/F8-78-WINDOWS-INTEGRATION.json'
previous = read(previous_path)
assert previous['source']['revision'] == expected_revision
assert previous['source']['tree'] == candidate['source']['tree']
for name, identity in previous['build_artifacts'].items():
    assert digest(build / name) == identity['sha256'], name
sys.path.insert(0, str(root / 'tools'))
spec = importlib.util.spec_from_file_location('f826_candidate_checker', root / 'tools/check_realtime_candidate_v10.py')
checker = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = checker
spec.loader.exec_module(checker)
closures = []
for closure in candidate['source']['protected_closures']:
    count, sha = checker.closure_identity(frozen, closure['patterns'])
    assert count == closure['file_count'] and sha == closure['sha256'], closure['category']
    closures.append({'category': closure['category'], 'file_count': count, 'sha256': sha})
assert not raw.exists(), raw
raw.mkdir()
identity = {
    'captured_at': datetime.now(timezone.utc).isoformat(), 'task': 'F8-26', 'lease': task['lease'],
    'harness_revision': git(root, 'rev-parse', 'HEAD'), 'harness_tree': git(root, 'rev-parse', 'HEAD^{tree}'),
    'harness_clean': True, 'source_revision': expected_revision, 'source_tree': candidate['source']['tree'],
    'candidate_id': candidate['id'], 'candidate_manifest_sha256': expected_manifest,
    'build_origin_report': previous_path.relative_to(root).as_posix(),
    'build_origin_report_sha256': digest(previous_path),
    'retained_build_artifacts_verified': previous['build_artifacts'],
    'protected_closures': closures,
    'execution_plan': 'Reuse verified exact-source Release artifacts and execute fresh registered tests, SDK relocation, v10-bound installed-public capture and installed Gallery checks. Earlier capture observations remain historical evidence.',
}
(raw / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
print(f"Verified {len(previous['build_artifacts'])} build artifacts and {len(closures)} frozen closures")
