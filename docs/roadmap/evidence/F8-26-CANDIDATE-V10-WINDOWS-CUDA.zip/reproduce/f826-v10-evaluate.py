"""Evaluate fresh F8-26 candidate-v10 correctness, timing and Gallery evidence."""
import copy
import csv
import ctypes
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f826-v10-evidence-20261104')
sdk_root = raw / 'sdk/relocated-sdk'
build = Path('D:/Repos/parallel-mater-f878-integration-build-20261103')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()


def timing_failure(failure):
    allowed = {
        '.timings.physics_ms.p95': 'physics p95 exceeds the target tier',
        '.timings.frame_ms.p95': 'frame p95 exceeds the 60 Hz budget',
        '.simulated_to_wall_time_ratio': 'sustained workload missed the realtime rate',
    }
    actual = failure.get('actual')
    return (
        failure['path'].startswith('$.workloads[')
        and any(failure['path'].endswith(suffix) and failure['message'] == message
                for suffix, message in allowed.items())
        and isinstance(actual, (int, float)) and not isinstance(actual, bool)
        and math.isfinite(actual) and actual >= 0
    )


capture_module = load_module('f826_capture', sdk_root / 'share/parallel-mater/conformance/v1/realtime_device_capture.py')
candidate_path = capture_module._candidate_path()
contracts = (
    read(capture_module.PROFILE_PATH), read(capture_module.INVENTORY_PATH),
    read(capture_module.CAPABILITY_PATH), read(capture_module.SUITE_PATH),
    read(candidate_path), capture_module.file_sha256(candidate_path, portable_text=True),
)
assert digest(candidate_path) == '29e051d94a89a39d51c2128b212165d60da6da7de4b2c107a72ae7cc5b77f20a'
source = read(raw / 'identity.json')
assert source['harness_revision'] == git('rev-parse', 'HEAD')
assert source['harness_tree'] == git('rev-parse', 'HEAD^{tree}')
assert source['harness_clean'] and not git('status', '--porcelain')
assert source['lease']['token'] == '1ebf889f-b148-449a-bf31-cf46b413c729'
assert source['source_revision'] == contracts[4]['source']['revision']
assert source['source_tree'] == contracts[4]['source']['tree']

registered = read(raw / 'registered-tests.json')['tests']
previous = read(Path('D:/Repos/parallel-mater-f8-77-final-evidence-20261102/registered-tests.json'))['tests']
names = {test['name'] for test in registered}
previous_names = {test['name'] for test in previous}
assert previous_names <= names
test_cases = ET.parse(raw / 'ctest.xml').getroot().findall('testcase')
assert {test.attrib['name'] for test in test_cases} == names
assert all(test.attrib.get('status') == 'run' and test.find('failure') is None
           and test.find('error') is None and test.find('skipped') is None
           for test in test_cases)
sdk = read(raw / 'sdk/report.json')
assert sdk['status'] == 'passed'

aggregate = read(raw / 'capture/capture.json')
original_report = read(raw / 'capture/report.json')
assert len(aggregate['public_cases']) == 30 and len(aggregate['scenarios']) == 12
assert aggregate['candidate'] == {
    'id': contracts[4]['id'], 'source_revision': source['source_revision'],
    'manifest_sha256': source['candidate_manifest_sha256'],
}
assert read(raw / 'independent-report.json') == original_report
metadata = read(raw / 'sdk-freeze-metadata.json')
changed_metadata = {row['path'] for row in metadata['changes']}
for name, expected in sdk['sdk_sha256'].items():
    if name.replace('\\', '/') not in changed_metadata:
        assert digest(sdk_root / name) == expected, name
gallery = read(raw / 'gallery-audit-report.json')
assert gallery['status'] == 'audit_complete'
assert gallery['source_revision'] == source['source_revision']
assert len(gallery['executions']) == 29
assert gallery['failed_scenes'] == ['peg-paint']
assert sum(row['exit_code'] == 0 for row in gallery['executions']) == 28
peg = next(row for row in gallery['executions'] if row['scene'] == 'peg-paint')
peg_log = raw / peg['artifact_directory'] / peg['log']
assert 'Paint coverage failed: 7 texels; need 100.' in peg_log.read_text()
assert 'capacity_overflows=0' in peg_log.read_text()
peg_timings = raw / 'gallery-full/headless-peg-paint.csv'
with peg_timings.open(newline='', encoding='utf-8-sig') as stream:
    peg_rows = list(csv.DictReader(stream))
assert len(peg_rows) == 240 and all(int(row['physics_steps']) == 1 for row in peg_rows)
gallery['known_scene_quality_failure'] = {
    'scene': 'peg-paint', 'completed_frames': 240, 'physics_steps_per_frame': 1,
    'painted_texels': 7, 'required_painted_texels': 100, 'capacity_overflows': 0,
    'log_sha256': digest(peg_log), 'timings_sha256': digest(peg_timings),
    'classification': 'Scene-quality failure awaiting explicit F9 routing and an F8-26 scope replan.',
}
controls = capture_module.SUITE.REQUIRED_NEGATIVE_CONTROLS
mutations = {
    'candidate_missing_pair': lambda value: value['capabilities'].pop(),
    'atomic_failure_violation': lambda value: next(item for item in value['scenarios']
        if item['id'] == 'capacity-overflow-atomic-recovery')['tick_work'][1].update({'state_unchanged': False}),
    'hidden_retry_violation': lambda value: next(item for item in value['scenarios']
        if item['id'] == 'capacity-overflow-atomic-recovery')['tick_work'][1].update({'hidden_retries': 1}),
    'timing_stall_retained': lambda value: value['workloads'][0]['timings']['physics_ms'].pop('maximum'),
    'timing_failed_tick': lambda value: value['workloads'][0].update({'failed_ticks': 1}),
}
expected_paths = {
    'candidate_missing_pair': '$.capabilities',
    'atomic_failure_violation': '$.scenarios[capacity-overflow-atomic-recovery].tick_work[1].state_unchanged',
    'hidden_retry_violation': '$.scenarios[capacity-overflow-atomic-recovery].tick_work[1].hidden_retries',
    'timing_stall_retained': '$.workloads[rigid-wall].timings.physics_ms.maximum',
    'timing_failed_tick': '$.workloads[rigid-wall].failed_ticks',
}
modes = {}
for mode in ('plain', 'validation'):
    selected = copy.deepcopy(aggregate)
    workloads = {}
    provenance = read(raw / 'capture/logs' / mode / 'provenance.log')
    assert provenance['source_commit'] == source['source_revision']
    public = list((raw / 'capture/raw' / mode / 'public-cases').glob('*.json'))
    assert len(public) == 30
    assert all(read(path)['execution_status'] == 'completed' for path in public)
    for index, template in enumerate(aggregate['workloads']):
        path = raw / 'capture/raw' / mode / 'workloads' / (template['id'] + '.json')
        workload = read(path)
        assert workload['warmup_ticks'] == 600 and workload['measured_ticks'] == 7200
        assert workload['failed_ticks'] == 0
        assert set(workload['raw_samples']) == {'cpu_ms', 'gpu_ms', 'physics_ms', 'frame_ms'}
        for clock_name, samples in workload['raw_samples'].items():
            assert len(samples) == 7200 and all(math.isfinite(x) and x >= 0 for x in samples)
            ordered = sorted(samples)
            expected = {name: ordered[math.ceil(fraction * len(samples)) - 1]
                        for name, fraction in [('p50', .5), ('p95', .95), ('p99', .99)]}
            expected['maximum'] = ordered[-1]
            assert workload['timings'][clock_name] == expected
        workload.pop('raw_samples')
        workloads[template['id']] = {'sha256': digest(path), **copy.deepcopy(workload)}
        workload['executions'] = copy.deepcopy(template['executions'])
        selected['workloads'][index] = workload
    selected['negative_controls'] = capture_module._negative_controls(selected, contracts)
    canonical = capture_module.SUITE.evaluate(selected, *contracts)
    # The existing control evaluator uses placeholders to avoid recursive control checks.
    # This diagnostic baseline is separate from the retained canonical verdict above.
    baseline = copy.deepcopy(selected)
    baseline['negative_controls'] = [{'id': identity, 'passed': True} for identity in controls]
    baseline_report = capture_module.SUITE.evaluate(baseline, *contracts)
    assert all(timing_failure(failure) for failure in baseline_report['failures']), baseline_report
    baseline_failures = {json.dumps(failure, sort_keys=True) for failure in baseline_report['failures']}
    injected_results = {}
    for identity in controls:
        injected = copy.deepcopy(baseline)
        mutations[identity](injected)
        injected_report = capture_module.SUITE.evaluate(injected, *contracts)
        new_failures = [failure for failure in injected_report['failures']
                        if json.dumps(failure, sort_keys=True) not in baseline_failures]
        assert any(failure['path'] == expected_paths[identity] for failure in new_failures), (identity, new_failures)
        injected_results[identity] = {
            'injected_defect_rejected_independently': True,
            'new_failures': new_failures,
            'full_injected_report': injected_report,
        }
    expected_control_failures = {
        '$.negative_controls[' + identity + ']' for identity in controls
    }
    assert all(timing_failure(failure) or failure['path'] in expected_control_failures
               for failure in canonical['failures'])
    modes[mode] = {
        'provenance': provenance, 'public_cases_passed': 30, 'physical_scenarios_passed': 12,
        'correctness_work_recovery_passed': True,
        'workloads': workloads, 'original_canonical_report': canonical,
        'canonical_negative_controls': selected['negative_controls'],
        'diagnostic_baseline_report': baseline_report,
        'negative_control_differential_diagnostics': injected_results,
    }

closures = source['protected_closures']
for item in contracts[4]['source']['protected_closures']:
    actual = next(row for row in closures if row['category'] == item['category'])
    assert actual['sha256'] == item['sha256'] and actual['file_count'] == item['file_count']

runtime = ctypes.WinDLL('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v12.9/bin/cudart64_12.dll')
memory = {}
for name, enum in [('managed_memory', 83), ('concurrent_managed_access', 89)]:
    value = ctypes.c_int()
    result = runtime.cudaDeviceGetAttribute(ctypes.byref(value), enum, 0)
    memory[name] = {'result': result, 'value': value.value}
assert memory['concurrent_managed_access'] == {'result': 0, 'value': 0}
artifacts = {path.name: {'bytes': path.stat().st_size, 'sha256': digest(path)}
             for path in sorted(build.iterdir())
             if path.is_file() and (path.suffix.lower() in ('.dll', '.exe', '.pdb') or path.name == 'CMakeCache.txt')}
assert artifacts == source['retained_build_artifacts_verified']
cuda_tests = []
for test in registered:
    labels = next((item['value'] for item in test['properties'] if item['name'] == 'LABELS'), [])
    if 'cuda' in labels:
        cuda_tests.append(test['name'])
report = {
    'schema': 'parallel-mater-realtime-device-qualification/v1', 'task': 'F8-26',
    'status': 'incomplete_under_original_gallery_contract', 'final_performance_qualified': False,
    'claim_pr': 'https://github.com/tabutyn/parallel-mater/pull/663',
    'lease_token': source['lease']['token'],
    'candidate': {
        'id': contracts[4]['id'], 'source_revision': source['source_revision'],
        'source_tree': source['source_tree'],
        'manifest': 'conformance/v1/qualification/realtime-candidate-v10.json',
        'manifest_sha256': source['candidate_manifest_sha256'],
        'exact_source_ci_run': 41708083151,
        'target': 'windows-gtx1080-slang-cuda', 'runtime_variant': 'cuda-runtime',
    },
    'source_and_build_provenance': source,
    'cuda_memory_attributes': memory,
    'nvidia_device': subprocess.check_output([
        'nvidia-smi', '--query-gpu=name,uuid,driver_version,memory.total,pci.bus_id',
        '--format=csv,noheader'], text=True).strip(),
    'registered_tests': {'registered': len(names), 'passed': len(test_cases), 'skipped': 0,
                         'previous_registered': len(previous_names),
                         'all_previous_tests_retained': True, 'cuda_labeled_tests': cuda_tests},
    'relocated_sdk': sdk, 'installed_freeze_metadata': metadata,
    'installed_gallery': gallery,
    'initial_gallery_smoke': {
        'report': read(raw / 'gallery-report.json'),
        'classification': 'The exploratory three-frame paint capture failed its coverage threshold. The normal 240-frame audit reproduced that failure with 7 painted texels against the unchanged 100-texel requirement.',
    },
    'gallery_install_staging': read(raw / 'gallery-install-staging.json'),
    'gallery_shortcut': read(raw / 'gallery-shortcut.json'),
    'capture': {
        'finished_at': read(raw / 'capture-result.json')['finished_at'],
        'original_report': original_report, 'independent_validator_agrees': True,
        'modes': modes, 'capabilities': len(aggregate['capabilities']),
        'measured_ticks_total': 72000, 'raw_timing_values_total': 288000,
        'all_samples_and_stalls_retained': True,
    },
    'protected_closures': closures, 'build_artifacts': artifacts,
    'limitations': [
        'Timing-only misses and timing-contaminated canonical control baselines remain F9-07/F9-08 obligations.',
        'This row qualifies the registered Windows GTX 1080 CUDA tuple. Other device tasks retain their own execution requirements.',
        'Gallery captures verify installed execution and presentation. F9-01 through F9-06 own convincing scene behavior.',
        'The frozen Ninja build required a verified staging directory to align executable and portable-manifest locations for the existing Windows installer.',
    ],
}
output = raw / 'qualification-evaluation.json'
assert not output.exists(), output
output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({
    'tests_passed': len(test_cases), 'cuda_labeled_tests': len(cuda_tests),
    'sdk_checks': len(sdk['checks']), 'gallery_executions': len(gallery['executions']),
    'workloads': {
        mode: {name: value['timings']['physics_ms']['p95'] for name, value in row['workloads'].items()}
        for mode, row in modes.items()
    },
}, indent=2))
