# Blender-authored triangle scenes

Gallery scenes are `.glb` assets, not C++ recipes. Render triangles drive
collision by default, while an optional Blender-authored lower-resolution mesh
can be selected per body as its collision proxy. ParallelMater has no separate
sphere, box, capsule, or plane collider types.

For the complete custom-property index, see
[Supported `pm_*` properties](#supported-pm_-properties) below.

## Authoring contract

1. Model every rigid object as a Blender mesh. Open, disconnected,
   non-manifold, and inconsistently wound surfaces are accepted; every triangle
   collides from both sides.
2. Use one Blender unit as one metre and keep simulated objects at the scene
   root.
3. Select each object and choose **Object → Rigid Body → Add Active** or
   **Add Passive**. Blender `ACTIVE` maps to `MotionType::dynamic`; an ACTIVE
   body with **Animated** enabled maps to `MotionType::kinematic`; `PASSIVE`
   maps to `MotionType::static_body`.
4. Set mass, friction, restitution, linear damping, angular damping, and an
   optional collision margin in Blender's Rigid Body panel.
5. Put the object origin near its intended center of mass. The current loader
   recenters local geometry from its AABB and preserves the resulting world
   pose. A zero API inertia uses the mesh AABB approximation; an application
   can supply a measured inertia diagonal later.
6. For a detailed object, optionally create a separate low-resolution mesh and
   set the rigid object's custom string property `pm_collision_proxy` to that
   object's Blender name. The proxy may have its own transform and modifiers;
   the exporter evaluates it into the rigid body's local frame. Do not add a
   Blender Rigid Body to the proxy. Keep silhouettes and support surfaces close
   enough that the physical approximation remains intentional.
7. To author a grid of independent identical rigid bodies, add Array modifiers
   to one ACTIVE mesh and keep the evaluated copies disconnected. The exporter
   splits each copy into its own rigid node with a shared triangle mesh. It
   rejects arrays with overlapping or non-identical copies rather than
   silently simulating them as one compound body.
8. To author a non-colliding trigger volume, use a scene-root mesh with no
   rigid body and set its Boolean custom property `pm_hit_box = true`. The
   evaluated local bounds, object transform, and name become one oriented
   `HitBox`; the source mesh is not rendered or added as collision geometry.
   `pm_load_box = true` is accepted as a compatibility alias.
9. Gallery scenes with screen-space gravity steering can keep selected dynamic
   scenery under ordinary vertical gravity by setting its Boolean custom
   property `pm_gravity_tilt = false`. The body remains fully dynamic and can
   still be displaced by contacts and impulses; the full acceleration stays
   vertical while other bodies follow steering. Array instances inherit the
   source property. Use a Boolean property with the checkbox **unchecked**.
10. For direct arrow-key force, give an ACTIVE, non-Animated rigid body a
    numeric custom property `pm_arrow = 100.0`. While held, arrow keys apply
    100 newtons at its center of mass. The requested screen-space direction is
    projected onto the floor and normalized, so force stays parallel to the
    ground and diagonals still total 100 N. Opposite keys cancel, and releasing
    keys stops the force without removing momentum. Each Array instance inherits
    the full force. Scenes with a positive `pm_arrow` use arrows for force
    instead of gravity tilt or their other arrow-key controls; ordinary
    vertical gravity remains. Scenes without it keep their existing controls.

The exporter rejects parented rigid bodies for now. Continuous collision,
compound bodies, and automatic convex decomposition are not part of this
milestone.

For an invisible collider, assign a material and set its **Principled BSDF →
Alpha** to `0`. Blender exports the material alpha; the gallery hides those
faces from camera and depth rays while keeping the rigid body and all its
collision triangles. This works per material slot, not by object name. Constant
glTF `MASK` alpha respects its cutoff; `BLEND` alpha zero is invisible. Partial
alpha blending and alpha textures are not supported yet; glTF `OPAQUE`
materials remain visible regardless of their alpha value.

## Point constraint scene

`examples/assets/Celestial.blend` supplies the gallery's **Constraint: Point**
entry, replacing the original demo. There is no separate Celestial gallery entry.
The original `ConstraintPoint.blend`/`.glb` remain test/conformance fixtures.
Rebuild its editable source with:

```bash
blender --background --python examples/assets/tools/make_celestial_scene.py
blender --background examples/assets/Celestial.blend \
  --python tools/blender/export_parallel_mater_scene.py -- \
  --output examples/assets/Celestial.glb
./build-gallery/parallel-mater-gallery --constraint-point
```

Four dynamic meshes each combine a straight gray arm with a plain colored sphere.
The arms have different lengths; the base and central post are undecorated. Native
POINT constraints connect them to `CelestialAnchor` at Blender `(0, 0, 6.3)`.
Separate low-resolution collision meshes retain arms and spheres, omitting the
shared pivot neighborhood. The passive base has its own collider. Collision
proxies are hidden in the Blender viewport and render.
No motors, keyframed movement or scene-specific solver forces are used.
The exported `pm_initial_velocity` values start opposing motion in ParallelMater;
Blender's own playback does not apply those custom initial velocities.

The source includes a presentation camera and studio lights for editing/rendering.
The gallery uses its own camera and material-color lighting. Arrows tilt gravity; Space releases
or restores the assembly; R resets. The GPU scene test checks shared anchor drift,
motion, tilted gravity, release and restoration at the gallery's four substeps.

## Dump truck

`DumpTruck.blend` supplies DUMP. Rebuild and export it with:

```bash
blender --background --python examples/assets/tools/make_dump_truck_scene.py
blender --background examples/assets/DumpTruck.blend \
  --python tools/blender/export_parallel_mater_scene.py -- \
  --output examples/assets/DumpTruck.glb
./build-gallery/parallel-mater-gallery --dump
```

The builder derives four motor-driven wheels and four suspended steering hubs
from `ConstraintMotorSpring.blend`, preserving that source. `MotorChassis` includes
a simple cab; `DumpBucket` is one dynamic mesh containing a floor and four solid
walls, with no lid. `DumpLift` holds its rear pivot to the dynamic chassis. The
gallery smoothly rotates that generic constraint's chassis-side frame from zero
to 100 degrees on Space, then holds it; another Space press lowers it. The solver
owns the resulting rigid motion, payload contacts and suspension reactions.

Add a scene-root **Empty named `SphereCluster`** where the payload grid should be
centered. Its position and rotation drive every load, including the default 100
and all P / `--dump-spheres` choices from 10 to 1,000. Save and re-export after
moving the Empty. Display size and scale do not resize the spheres. The old
`DumpLoadVolume` helper is ignored by payload packing and may be removed.

The shared exporter writes `pm_system=sphere_cluster`: a non-simulated template
at the Empty's pose, carrying an 80-triangle icosphere of radius 0.1 m, mass
0.04 kg and friction 0.35. Runtime instances share that mesh and use 0.23 m
center spacing. The occupied grid's bounds are centered on the Empty, including
partial top layers; larger loads may start above the bucket and fall into it.
No authored sphere mesh or Array is required. The low-friction bucket
liner is intentional: at 100 degrees the rear wall slopes only ten degrees
toward the open rim, so a grippy wall would retain some of the payload.
Arrow controls match Motor + Spring; P edits the load count and R resets.

## Smoke flow

`Smoke.blend` is reproducible with `examples/assets/tools/make_smoke_scene.py`.
It has a passive rigid Icosphere and one mesh with **Fluid → Flow**, **Flow
Type: Smoke**, **Flow Behavior: Inflow**, and initial velocity along +X. The
flow mesh is a world-YZ plane. Its optional `pm_smoke_obstacle` custom string
property names a rigid obstacle mesh to opt into smoke contact.
Exporting creates `pm_system=smoke_emitter`, separate
from Liquid Inflow; no Blender domain cache is needed. `pm_smoke_capacity`,
`pm_smoke_rate`, `pm_smoke_lifetime`, `pm_smoke_radius`, `pm_smoke_buoyancy`,
`pm_smoke_wind_response`, `pm_smoke_rest_number_density`,
`pm_smoke_pressure_stiffness`, `pm_smoke_viscosity`, and
`pm_smoke_vorticity_confinement` are optional emitter properties. The shallow
air grid also accepts `pm_smoke_grid_resolution` (horizontal X and Z, default
128; zero selects the particle-only mode),
`pm_smoke_grid_vertical_resolution` (world Y, default 32), and
`pm_smoke_grid_pressure_iterations` (maximum multigrid work, default 24),
`pm_smoke_grid_kinematic_viscosity` (default `1.5e-5`),
`pm_smoke_grid_les_coefficient` (default `0.12`), and
`pm_smoke_grid_pressure_tolerance` (relative residual, default `1e-3`). The older
`pm_smoke_response` and `pm_smoke_wake_strength` properties are ignored.
The exporter now writes smoke model version 3 with defaults of 12, 2, 0.1,
and 0.5/s for rest number density, pressure stiffness, vorticity confinement,
and wind response.
Existing GLBs that omit those optional values inherit the new defaults
without changing the authored Blender files; explicit values remain intact.
The gallery registers a `SmokeOptions` resource and couples dynamic rigid
bodies automatically; the named passive obstacle is coupled too. Coupled
obstacles may be any rigid triangle mesh; smoke contact
follows its translation and rotation. One smoke
inlet per scene is supported.

`SmokeSoftbody.blend` uses the same Smoke Inflow and a twenty-object grid of
Blender Soft Body meshes. Each `Top` Goal group is an exact pin; the smoke
carrier bends the remaining nodes, and the current soft skin deflects smoke
tracers through the pipeline's smoke/soft-body `PmCouplingState`. No extra Blender
coupling marker is required when both systems exist in the scene. The source
cylinders use 16 radial sides and nine axial rings, with
`pm_node_spacing = 0.12` and `pm_solver_iterations = 4`; this keeps the
entire grid at 3,520 nodes and 57,720 springs rather than the default
refinement's roughly 56,000 nodes and 4.8 million springs. Increase spacing
or reduce authored face resolution to control cost before reducing solver
stiffness. The single exporter still owns `.glb` generation.

`SmokeCloth.blend` pairs the same Smoke Inflow with a 17×17 cloth sheet. Its
Blender Cloth **Pin** group fixes 34 edge vertices. The gallery registers the
API's smoke/cloth coupling when a scene contains both systems; the exporter
does not bake a wind force or add a scene-specific property. Wind bends free
vertices and tracer contact follows the cloth's current triangles. Native
cloth quality and material properties continue through the regular Cloth
export path.

## Smoke and water boiling

`SmokeWater.blend` combines a Smoke Inflow with a Liquid Flow/Geometry volume.
Put a `pm_temperature` custom property (degrees Celsius) on the liquid object
to set its initial particle temperature; liquid Inflow objects can set it too.
Add a scene-root plane with no Fluid modifier or rigid body and set
`pm_temperature` to make a heated surface. `Hot` uses 500°C. The single
exporter writes `pm_system=thermal_surface`; the gallery imports its triangles
as a visible passive collision plate and configures the API coupling from its
finite plane and temperature. Optional plane properties are
`pm_heat_transfer_rate`, `pm_smoke_drag`, and `pm_steam_rise_speed`.
Water particles transfer to the separate smoke system at 100°C, so keep the
passive container open above the heater. Blender's own fluid cache is unused.

## Rope curves and attachments

Use one open Bézier spline at the scene root. Select an endpoint control point
in Edit Mode and use a Hook modifier targeting a native passive or active rigid
body, or a mesh with Soft Body physics. Use strength 1 and no distance falloff (a zero falloff radius also works).
Each Hook must contain exactly one endpoint control point, not interior points.
The endpoints may target distinct rigid or soft bodies, or an endpoint may be free.

For a rope-to-cloth joint, use an open **Poly** curve with a Soft Body modifier
and place its endpoint exactly on an authored cloth vertex. The exporter infers
that endpoint joint without a Hook. It also infers a rigid attachment when an
unhooked endpoint lies on or inside one rigid mesh, passive or active. If several targets
overlap, the nearest surface wins only when clearly closer; ambiguous targets
are rejected. A Hook, where present, takes precedence over inference. Poly
curves with Hooks are not supported; use Bézier for explicit Hook attachments.
The geometry decides *which* objects connect; the pipeline's rope/cloth
`PmCouplingState` implements the physical joint after export.

`RopeCloth.blend` has four such post-to-corner curves. Its Simple Subdivision
modifier sits before Cloth and becomes a 17×17 physical sheet during export;
the original four corner positions remain exact for rope binding. Only Simple
pre-Cloth subdivision, up to five viewport levels, is currently mapped.

`SmokeRope.blend` uses four Poly curves with a Soft Body modifier as rope
markers. Their panel ends touch an active rigid plane; their other ends lie
inside two passive rigid posts. The exporter infers all four joints from that
geometry, without Hooks. The active panel retains the Boolean
`pm_smoke_collider` authoring marker; dynamic rigid bodies now receive the
API's generic smoke/rigid coupling automatically alongside the four
smoke/rope couplings. The ground and vortex sphere remain separate rigid
bodies. Re-export with the same single exporter after editing the source.

The exporter evaluates Blender's actual Hook deformation, including bind
matrices and moved targets. It removes Soft Body only from a temporary copy so
cached simulation does not replace the rest curve. Sampling and runtime
constraints are implemented by the physics API; there is no Blender bake.

Optional curve custom properties:

| Property | Meaning / default |
|---|---|
| `pm_rope_radius` | Physical radius; bevel depth, or 0.01 m when unbevelled |
| `pm_rope_spacing` | Maximum node spacing; default twice the radius |
| `pm_rope_mass` | Total rope mass; native Soft Body mass, or 0.1 kg |
| `pm_rope_compliance` | Stretch compliance; 0 requests a stiff rope |
| `pm_rope_friction` | Coulomb contact friction; 0.4 |
| `pm_rope_damping` | Velocity damping per second; 0.1 |
| `pm_rope_maximum_substep_timestep` | Maximum shared integration step in seconds; 1/480 |
| `pm_rope_iterations` | Nominal constraint/contact budget; 24. High-strain recovery allows up to 4×, capped at 32 |

Keep the rest curve outside collision geometry, except its attachment
neighborhoods. Material alpha zero hides a collider but does not disable it.
Author enough curve length for intended wraps: three turns need at least
`3 * 2 * pi * (post radius + rope radius + margin)`, plus the remaining lengths
between the wraps and the two attachments. A stiff rope cannot create slack.

The schema stores `pm_system = "rope"`, `pm_rope_points` as world-space Y-up
polyline samples, and `pm_rope_first_body` / `pm_rope_last_body`,
`pm_rope_first_soft_body` / `pm_rope_last_soft_body`, or
`pm_rope_first_cloth` / `pm_rope_last_cloth` as target names. A soft Hook
follows the closest rest-surface triangle, while all other rope segments collide
with its deformed skin through the shared rope/soft-body API. To keep a soft post
rooted while the rope winds, assign its bottom vertices to a Blender Soft Body
Goal group with full effective weight; an ungrouped Goal restores shape but
does not pin the post in world space.
Ambiguous instanced Hook targets and unsupported curve modifiers are rejected.

## One Blender–ParallelMater export interface

`tools/blender/export_parallel_mater_scene.py` is the single exporter for rigid
bodies, rigid-body constraints, collision proxies, Arrays, hit boxes, soft
bodies, cloth/pins/fracture, liquid Inflow/Outflow/Geometry, and paint metadata.
New physics systems extend this script and the versioned scene contract, not a
per-example exporter. It has no gallery scene names or scene-specific physics
settings.

In Blender 4.5+, install that one `.py` file as an add-on, or open it in the
Scripting workspace and run it once. Use **File → Export → ParallelMater Scene
(.glb)** in Object Mode. The file browser uses the same `export_scene()` entry
point as headless export:

```bash
blender --background examples/assets/PassiveActive.blend \
  --python tools/blender/export_parallel_mater_scene.py -- \
  --output examples/assets/PassiveActive.glb
```

When `--output` is omitted, the script writes a `.glb` beside the currently
open `.blend` using the same filename stem. The script is non-destructive:
it exports evaluated rigid copies and undeformed soft/cloth rest copies, bakes scale
into their vertices, triangulates all polygons, writes schema-2 glTF extras, and removes
the temporary data. The source `.blend` is not saved or changed.
Saving a `.blend` does not update the gallery by itself; re-export its `.glb`
after changing physics properties such as mass.
After updating the exporter script, restart Blender and load the current
script before using its File menu entry; an already registered operator can
still run an older in-memory version. For the wall, the direct command is:

```bash
blender --background examples/assets/RigidBody.blend \
  --python tools/blender/export_parallel_mater_scene.py -- \
  --output examples/assets/RigidBody.glb
```

Restart the gallery or press `R` to reload the GLB. Its startup message should
read `Rigid gravity tilt: 1 follow, 384 keep vertical`. Missing GLB tilt flags
default to `true` for older scenes, even if the `.blend` has them set to false.
Selection and the active object are restored on success and failure. Soft-body,
cloth-only, and fluid-only scenes are supported; a dummy rigid body is not required.

Other Blender automation can import this file and call
`export_scene(filepath)` (or omit `filepath` to use the open blend's stem).
Importing the module does not export, register a UI, or edit the scene.
`register()` / `unregister()` manage the optional menu. Installation of the
CMake package also ships this same file under
`share/parallel-mater/blender/`; it does not add a Blender dependency to the
physics library.

The exporter is the Blender-facing boundary. GLB schema 2 is the interchange
contract; the current gallery loader consumes it and constructs public API
resources. A reusable runtime scene importer and Blender property panels can
grow around this boundary without introducing another export implementation.

## Supported `pm_*` properties

This is the authoring index for
[`tools/blender/export_parallel_mater_scene.py`](../tools/blender/export_parallel_mater_scene.py)
and the gallery loader. Add these under **Object Properties → Custom
Properties** on the applicable object, then save and export. Names are
case-sensitive. Defaults below combine exporter and gallery defaults.
Distances use metres, masses kilograms, time seconds, and angles radians.
Properties do not replace Blender's native physics panels unless explicitly
listed as overrides. Unlisted custom properties are not supported controls.

### Rigid bodies, triggers, and paint

| Property | Type / default | Meaning |
|---|---|---|
| `pm_arrow` | Number, `0` | Continuous force in newtons at the rigid body's center of mass. Its camera-relative screen direction is projected onto the floor, normalized, and applied parallel to the ground. Finite, non-negative float; positive values require ACTIVE, non-Animated bodies. Applies once per physics step, not per rendered frame. Enables force-only arrow controls scene-wide. |
| `pm_gravity_tilt` | Boolean, `true` | Follow gallery gravity steering. `false` keeps full vertical gravity on this dynamic body; it does not freeze it. |
| `pm_initial_velocity` | Three numbers, `[0, 0, 0]` | Initial rigid velocity in Blender world X/Y/Z, m/s. Export converts it to glTF Y-up. |
| `pm_collision_proxy` | String, unset | Name of a separate collision mesh without a Rigid Body; detailed mesh still renders. |
| `pm_hit_box` | Boolean, `false` | Export a root mesh without a rigid body as an oriented, non-rendered trigger volume. |
| `pm_load_box` | Boolean, `false` | Compatibility alias for `pm_hit_box`; explicit `pm_hit_box` takes precedence. |
| `pm_smoke_collider` | Boolean, `false` | Opt static/kinematic rigid geometry into smoke coupling. Dynamic rigid bodies couple automatically. |
| `pm_paintable` | Boolean, `false` | Register a paint field on a rigid body or cloth. |
| `pm_paint_resolution` | Integer, `512` | Square paint-mask size, 32–2048 texels per side. |
| `pm_paint_source` | String, empty | On cloth, name the rigid body that paints it on contact. |
| `pm_paint_brush_radius` | Number, `0.15` | Cloth contact-paint brush radius in metres. |

`pm_arrow = 100.0` applies **100 N**, not 100 m/s² or an impulse. A free
1 kg body gains 100 m/s each second; a 4 kg body gains 25 m/s each second,
before gravity, damping, and contact/constraint reactions. Diagonal input is
normalized. Release adds no force and preserves momentum. Arrays inherit the
force per body, not divided across the array. This is gallery input metadata,
not a scene-specific API; other clients record the same force with
`pmCmdApplyRigidInputs`. Materials determine surface
color; the renderer no longer adds a procedural floor pattern.

### Cloth

These require a native Cloth modifier. Pins and pressure come from its native
settings; paint properties above also apply.

| Property | Default | Meaning |
|---|---|---|
| `pm_vertex_mass` | `0.001` | Mass per cloth vertex, kg. |
| `pm_thickness` | `0.025` | Collision thickness, m. |
| `pm_stretch_compliance` | `1e-6` | Stretch softness; zero requests stiff constraints. |
| `pm_solver_iterations` | `8` | Constraint iteration budget, integer. |
| `pm_velocity_damping` | Native Air Damping | Velocity damping override. |
| `pm_contact_friction` | `0.4` | Contact friction coefficient. |
| `pm_break_strain` | `0` | Relative extension that can break a bond; zero disables strain tearing. |
| `pm_fracture_persistence_substeps` | `4` | Consecutive over-strain substeps required to tear, integer. |
| `pm_impact_break_impulse` | `0` | Impact tear threshold; zero disables impact tearing. |
| `pm_contains_fluid` | `false` | Boolean; a closed pressure cloth contains fluid. |

### Soft bodies

These require a native Soft Body modifier. Goal-group pins come from Blender.

| Property | Default | Meaning |
|---|---|---|
| `pm_total_mass` | Native Mass | Total soft-body mass, kg. |
| `pm_node_spacing` | Geometry-derived | Physical lattice spacing, m. See the Soft-body scenes section. |
| `pm_node_radius` | `0.35 × pm_node_spacing` | Physical node radius, m. |
| `pm_stretch_compliance` | `1e-7` | Spring softness; zero requests stiff constraints. |
| `pm_velocity_damping` | Non-negative native Damping | Velocity damping override. |
| `pm_spring_damping` | `0.85` | Relative spring-velocity damping. |
| `pm_contact_friction` | Native Friction | Contact friction coefficient. |
| `pm_shape_matching_stiffness` | Native Goal Default × Stiffness, or `0` | Co-rotated shape recovery; native default applies only with Goal enabled and no Goal vertex group. |
| `pm_maximum_projection_fraction` | `0.20` | Per-projection correction fraction cap. |
| `pm_constraint_velocity_response` | `0.70` | Constraint correction contribution to velocity. |
| `pm_maximum_speed` | `2.0` | Node speed cap, m/s. |
| `pm_solver_iterations` | `16` | Constraint iteration budget, integer. |

### Ropes

Use a supported open curve. Endpoint attachments come from Hooks or inferred
endpoint geometry, not hand-written target-name properties.

| Property | Default | Meaning |
|---|---|---|
| `pm_rope_radius` | Bevel depth, otherwise `0.01` | Physical radius, m. |
| `pm_rope_spacing` | `2 × pm_rope_radius` | Maximum node spacing, m. |
| `pm_rope_mass` | Native Soft Body Mass, otherwise `0.1` | Total rope mass, kg. |
| `pm_rope_compliance` | `0` | Stretch softness; zero requests a stiff rope. |
| `pm_rope_friction` | `0.4` | Contact friction coefficient. |
| `pm_rope_damping` | `0.1` | Velocity damping per second. |
| `pm_rope_maximum_substep_timestep` | `1/480` | Maximum shared integration step, seconds. |
| `pm_rope_iterations` | `24` | Nominal constraint/contact budget, integer. |

### Liquid and heated surfaces

| Property | Default | Meaning / applicable object |
|---|---|---|
| `pm_particle_spacing` | `0.06` | Initial particle spacing, m; Liquid Geometry flow. |
| `pm_gravity_scale` | `1` | Gravity multiplier on Liquid Geometry flow; affects the gallery scene, not just that fluid volume. |
| `pm_source_spacing` | `0` | Liquid Inflow emission-site spacing, m; zero uses fluid support radius. Also exported for Smoke Inflow. |
| `pm_temperature` | `20` for liquid | Temperature in °C on Liquid Geometry/Inflow. On a root mesh with no rigid body or fluid modifier, presence of this property defines a heated surface; set its temperature explicitly. |
| `pm_heat_transfer_rate` | `0.2` | Heated-surface heat-transfer rate, inverse seconds at contact. |
| `pm_smoke_drag` | `2.0` | Heated-surface steam drag. |
| `pm_steam_rise_speed` | `2.0` | Heated-surface steam rise speed. |

Native Fluid Flow settings select Geometry/Inflow/Outflow and initial velocity.
No custom properties are required for Liquid Outflow.

### Smoke Inflow

| Property | Default | Meaning |
|---|---|---|
| `pm_smoke_obstacle` | Unset | String naming a rigid mesh to couple to smoke. |
| `pm_smoke_capacity` | `4500` | Maximum tracer count, integer 1–1,000,000. |
| `pm_smoke_rate` | `900` | Emission rate, tracers/s. |
| `pm_smoke_lifetime` | `5` | Tracer lifetime, seconds. |
| `pm_smoke_radius` | `0.085` | Tracer radius, m. |
| `pm_smoke_buoyancy` | `0.12` | Buoyancy coefficient. |
| `pm_smoke_wind_response` | `0.5` | Wind response per second. |
| `pm_smoke_rest_number_density` | `12` | Tracer rest number density. |
| `pm_smoke_pressure_stiffness` | `2` | Particle pressure coefficient. |
| `pm_smoke_viscosity` | `0.02` | Particle viscosity coefficient. |
| `pm_smoke_vorticity_confinement` | `0.1` | Vorticity confinement strength. |
| `pm_smoke_grid_resolution` | `128` | Horizontal X/Z grid resolution, integer 16–256; zero disables the grid. |
| `pm_smoke_grid_vertical_resolution` | `32` | World-Y grid resolution, integer 8–256. |
| `pm_smoke_grid_pressure_iterations` | `24` | Maximum pressure-solve work, integer 4–128. |
| `pm_smoke_grid_kinematic_viscosity` | `1.5e-5` | Air-grid kinematic viscosity. |
| `pm_smoke_grid_les_coefficient` | `0.12` | Subgrid turbulence coefficient. |
| `pm_smoke_grid_pressure_tolerance` | `1e-3` | Relative pressure residual tolerance, greater than zero and at most one. |

### Generated GLB metadata — not Blender custom overrides

The exporter also writes the fields below. Change the corresponding native
Blender setting or geometry, not a same-named source custom property.
`AXIS` means each of `x`, `y`, and `z`; `END` means `first` and `last`.
Authoring overrides listed above retain their documented exceptions (for
example, `pm_solver_iterations` is an override on cloth/soft bodies but comes
from the native constraint panel on joints).

| Fields | Source |
|---|---|
| `pm_schema`, `pm_system`, `pm_name`, `pm_source_name` | Schema version, resource kind, exported name, and original object name. |
| `pm_motion`, `pm_mass`, `pm_friction`, `pm_restitution`, `pm_linear_damping`, `pm_angular_damping`, `pm_collision_margin` | Native Rigid Body settings; disabled custom margin exports `0.005 m`. |
| `pm_initial_velocity_AXIS` | Converted `pm_initial_velocity` vector. |
| `pm_constraint_type`, `pm_body_a`, `pm_body_b`, `pm_enabled`, `pm_disable_collisions`, `pm_breaking_impulse_threshold`, `pm_solver_iterations` | Native Rigid Body Constraint settings and target names. |
| `pm_use_limit_lin_AXIS`, `pm_limit_lin_AXIS_lower`, `pm_limit_lin_AXIS_upper`, `pm_use_limit_ang_AXIS`, `pm_limit_ang_AXIS_lower`, `pm_limit_ang_AXIS_upper` | Native per-axis limits. |
| `pm_use_spring_AXIS`, `pm_spring_stiffness_AXIS`, `pm_spring_damping_AXIS`, `pm_use_spring_ang_AXIS`, `pm_spring_stiffness_ang_AXIS`, `pm_spring_damping_ang_AXIS` | Native per-axis springs. |
| `pm_use_motor_lin`, `pm_motor_lin_target_velocity`, `pm_motor_lin_max_impulse`, `pm_use_motor_ang`, `pm_motor_ang_target_velocity`, `pm_motor_ang_max_impulse` | Native motor settings. |
| `pm_half_extent_AXIS` | Hit-box bounds; pose comes from the glTF node. |
| `pm_weld_vertices`, `pm_pin_group`, `pm_pin_vertices`, `pm_pin_stiffness` | Evaluated cloth topology and native pins; soft bodies also export Goal pin group/vertices. |
| `pm_pressure_enabled`, `pm_uniform_pressure`, `pm_pressure_scale`, `pm_pressure_custom_volume`, `pm_pressure_target_volume`, `pm_pressure_fluid_density` | Native Cloth pressure settings. |
| `pm_rope_points`, `pm_rope_END_body`, `pm_rope_END_soft_body`, `pm_rope_END_cloth` | Evaluated curve and resolved endpoint attachments. |
| `pm_velocity_AXIS` | Native fluid/smoke Initial Velocity, converted to Y-up. |
| `pm_smoke_model_version` | Exporter smoke model version (`3`). |

Hit boxes export as empty `pm_system = "hit_box"` nodes with `pm_name` and
`pm_half_extent_x/y/z`. Their scene-root translation and rotation define the
world-space trigger frame. They consume no persistent simulation capacity;
applications record `pmCmdQueryHitBox` when they need the result.

When a proxy is selected, the exporter adds a non-rendered
`pm_system = "collision_mesh"` glTF node and references it from the rigid-body
node. The gallery still renders the detailed mesh. Proxies are explicit
authored data: the loader does not decimate or invent collision geometry.

Built-in rigid-body settings are exported automatically. The optional `pm_*`
properties configure features without a standard Blender panel yet. Names are
labels except for explicit references such as collision proxies and paint
sources; they do not select scene-specific physics.

## Rigid body constraints

Add Blender's native **Rigid Body Constraint** to a scene-root Empty and assign
two rigid-body objects. Fixed, Point, Hinge, Slider, Piston, Generic, Generic
Spring, and Motor types map directly to `RigidConstraintType`. The Empty's
world transform becomes the joint frame; Blender linear and angular limit
flags, spring stiffness/damping, motor targets/impulses, enabled state,
collision suppression, breaking threshold, and solver-iteration override are
preserved. Constraint axes retain their Blender meaning across glTF's Y-up
conversion: Hinge uses the Empty's local Z, while Slider, Piston, and Motor use
their documented local axes. Array-modified rigid bodies are rejected as
ambiguous targets.

The exporter writes one `pm_system = "rigid_constraint"` node with both target
names and all built-in settings. The gallery loader resolves those names,
converts the world frame to body-local frames, and creates the public API
resource after both bodies. Runtime interaction changes the API resource, not
the Blender source or GLB metadata.

The committed constraint `.blend` files are maintained as artist-authored
sources. The Fixed scene authors one enabled joint that seeds a runtime
cluster; the gallery adds fixed constraints when collision results report a
loose sphere touching the large collector directly. Attached small spheres do
not collect other spheres.
`LargeCollision` is an explicit 5,120-triangle spherical collision proxy for
the collector, centered on its origin with radius matching the evaluated
render mesh's outer radius. Its maximum face sag is below 2 mm; the original
subdivided render surface produced visibly uneven rolling support. The proxy
is stored in the Blender source and exported through `pm_collision_proxy`.
The initially welded `Small.048` is seated 0.5 mm from that collision surface.
Collision-disabled fixed joints suppress contacts throughout the welded group
while preserving ground contacts. Fixed-scene captures retain 300 frames
(five seconds at 60 Hz), including the lead-up to a visible jolt or launch.
Arrow input gives every attached member the same 30-degree, screen-space gravity
vector; loose spheres retain downward gravity until collected. Ground uses friction
`4.0`; all 49 small spheres use friction `16.0`. Their effective
small-sphere/ground coefficient is `8.0`, making attached spheres grip the
floor and rotate the collector instead of letting the cluster slide.
The Hinge + Slider scene's first active `Gear` includes its paddle and axial
cylinder. Their mass distribution and the paddle's gravity torque drive the
gear train, so they must remain in the simulated rigid body. All three gears
hinge against passive `Ground.001`. The first hinge passes through the gear's
axle, offset from the complete driver's bounds center; this offset lets gravity
on the paddle generate torque. Each constraint frame's Z axis is copied from
its gear's local Z axis.
The gear rings include closed inner walls, including where the driver's axle
overlaps the ring. Open annular shells are not valid solids for mesh-overlap
checks and leave missing collision surfaces.
Closed concave shells retain outward-facing collision normals. Contacts in
directions locked by both unbreakable, frame-anchored hinges do not add a
competing rest-gap correction; the in-plane tooth contacts still transfer torque. Triangle search
margins are not treated as penetration depths when intersecting concave faces
have no previous separated witness.
Tooth contact propagates through both interfaces, so adjacent gears rotate in
opposite directions and the first and third rotate in the same direction. The
authored center distances, starting phases, collision search margins,
64-iteration hinges, and four gallery substeps retain closing tooth flanks at
the solver's small rest offset throughout a full mesh cycle. All three gears
use `0.08` tooth friction and zero restitution so they roll without binding or
rebounding; both followers use mass `1.0` and angular damping `0.01` so they
follow through freely instead of pushing the driver back. The scene has no
loose ball. `Ground.002` is an active rod carrying a Slider constraint against
the passive `Ground.001` frame, with its authored vertical local-X axis and
unlimited travel. The rack uses the same `0.08` tooth friction as the gears,
not the passive frame's `4.0` friction. A light return spring (`5 N/m`,
`0.5 N s/m` damping) along that free axis keeps the rack near the gear train;
gear teeth still support and drive its visible motion. The earlier `50 N/m`,
`14 N s/m` spring and high rack friction prevented gravity-driven full turns.
Constraint Object 1 and Object 2 must both be assigned in Blender,
including when the constraint lives on a rigid mesh rather than an Empty.
The scene contains five rigid bodies; the old separate `Ground` floor is removed.
The command-API full-rotation regression pumps the paddle with normal gallery
arrow-controlled gravity for 40 seconds and requires a complete turn. It keeps
the authored masses, damping, friction, rack, and springs, with no motor,
prescribed motion, or initial spin. Settling and fixed-period steering replays
also check slider travel, orientation, lateral drift, gear contacts, and joint
impulses. An independent CPU mesh check samples rack and gear surfaces every
four frames with the gallery's four substeps, limiting overlap to 2 mm;
reported contact counts or contact depths alone cannot prove this. Full turns
require about pi metres of rack travel, so the old one-metre travel assertion
has been replaced by a check that the rack stays within the follower gear's
axial reach throughout the replay.
Export every source through the same shared exporter; no
scene-specific export path exists.

## Validate the result

With Blender installed, the gallery build adds
`parallel-mater-blender-export-tests` to CTest. This exports all committed
source scenes into temporary files and checks them with the runtime loader,
plus soft-body-only/cloth-only/fluid-only scenes, the menu operator, CLI, and error cleanup.
No committed assets are rewritten.

```bash
ctest --test-dir build-gallery --output-on-failure -R blender-export
```

To run the Blender checks without building the gallery loader:

```bash
blender --background --factory-startup --threads 1 --python-exit-code 1 \
  --python tests/blender/export_scene_tests.py
```

To render an exported scene:

```bash
./build-gallery/parallel-mater-gallery \
  --scene examples/assets/PassiveActive.glb \
  --headless /tmp/parallel-mater-scene-check.ppm \
  --frames 180
```

The committed `PassiveActive.blend` contains a scaled passive bowl, an ACTIVE
Animated cube, and dynamic ACTIVE icosphere and Suzanne meshes. The detailed
bowl remains its own collision mesh; the three detailed dynamic objects carry
authored decimated proxies. Regression checks cover scale baking,
triangulation, proxy selection, kinematic targets, tilted gravity, toppling,
and containment.

The gallery's Rigid Body entry instead loads `RigidBody.blend`. Its two ACTIVE
brick sources each use stacked Array modifiers; export produces 192 independent
bodies per source while reusing one mesh per layer. `LoadBox` authors the
non-rendered goal volume through the legacy `pm_load_box` marker, exercising
the same canonical `hit_box` GLB schema and public query API.

The wall's coplanar faces must produce support contacts on the first step;
collision margins must not eject touching bricks or let layers sink together.
The wall regression checks all 384 bricks through ten seconds of authored
support, including a 0.01-radian rotation limit, impact response, and
contact-history invalidation after edits. No mortar, fixed joints, or
static-body substitution is implied by an Array modifier.

## Collision behavior

`pmCmdBuildGeometry` validates the bound vertex and index buffers and builds a
deterministic private BVH. Mesh–mesh narrow phase uses exact
edge/triangle closest features with a small two-sided shell. When motion over a
substep exceeds that shell, conservative swept triangle-pair tests cover the
linearized previous-to-current vertex paths before the discrete solve. This
handles fast translation, rotation, open surfaces, and contacts from either
side, but it is not an exact analytic time-of-impact solution for curved
rotational trajectories. Substeps remain the accuracy control for extreme
angular motion and multiple impacts. The collision margin remains numerical
thickness rather than visible geometry.

Future rope and smoke schemas will be introduced only
with their reviewed public APIs. Unknown systems and schema versions fail
explicitly rather than silently changing scene meaning.

## Soft Body closed volume

Add Blender's **Physics → Soft Body** modifier to one closed, scene-root mesh.
The shared exporter writes its undeformed triangle surface as
`pm_system = "soft_body"`, including Blender mass, damping, and friction. The
runtime loader calls the API's `build_soft_body_geometry`: it subdivides long
surface edges to the same spacing as the HCP interior, then connects surface
and interior nodes into one spring graph. Every refined surface vertex is a
physical node, not interpolation between distant authored corners. Refinement
preserves the authored piecewise-planar shape, closed seams, normals and UVs;
it does not round or inflate the object. The installed API builds and advances
the lattice; the gallery only transfers rendering attributes.

Optional object properties tune conversion and the reusable solver:
`pm_node_spacing`, `pm_node_radius`, `pm_stretch_compliance`,
`pm_velocity_damping`, `pm_spring_damping`, `pm_contact_friction`,
`pm_shape_matching_stiffness`,
`pm_maximum_projection_fraction`, `pm_constraint_velocity_response`,
`pm_maximum_speed`, and `pm_solver_iterations`. Smaller spacing creates more
nodes and bonds. The gallery export defaults to the old lab's `2 m/s` soft-body
speed cap, `0.2` per-pass projection bound, `0.7` projection velocity response,
and 16 graph iterations. The first stage supports passive rigid triangle
collision. Active rigid triangle bodies use the same collision pass and receive
balanced reaction impulses automatically; no extra Blender property or
scene-specific force is needed. `SoftbodyRigidBody.blend` demonstrates two
active spheres contacting one soft body. Authored cloth and fluid systems can
also register the API's explicit soft-body coupling resources.

When Blender **Soft Body → Goal** is enabled **without a vertex group**, the exporter maps Default Weight
times Stiffness to `pm_shape_matching_stiffness`. ParallelMater interprets that
signal as co-rotated rest-shape matching rather than a world-space pin: the
body can translate and roll, compresses under load, and restores its authored
shape after the load leaves. Restoration yields during any substep with active
rigid contact, preventing the Goal projection from rebuilding through a
collider. A custom `pm_shape_matching_stiffness` overrides the Blender-derived
value; zero disables restoration.

With a Goal vertex group, full effective weight (`Min + weight * (Max - Min)`
equal to 1) instead exports an exact fixed node. This uses API inverse mass
zero, not a gallery force. Matching is position-based so triangulation and
glTF normal/UV seams do not lose pins. Refined vertices on an edge or face whose
original vertices are all pinned also stay fixed, preserving the attached area
rather than only its original corners. Partial Goal weights remain movable;
animated targets and weighted attachment springs are not implemented. A group
does not implicitly enable whole-body shape matching; the explicit custom
property remains available. See Blender's [Goal settings](https://docs.blender.org/manual/en/5.0/physics/soft_body/settings/goal.html).

`SoftbodyFluid.blend` demonstrates four pinned Goal vertices, one liquid inflow,
one liquid outflow, and passive rigid boundaries. Export it with the same
`export_parallel_mater_scene.py` script. The exporter does not modify the source blend.
Default lattice spacing retains the existing nine-sample thin-axis rule for
roughly isotropic bodies; for slabs it targets 18 samples along the long axis
while retaining at least three through the thickness. `pm_node_spacing`
overrides this resolution choice.

The fixture now explicitly authors a **coarser, firm material** on its soft
object: `pm_node_spacing = 0.12`, `pm_shape_matching_stiffness = 1.0`,
`pm_solver_iterations = 64`, `pm_maximum_projection_fraction = 0.5`, and
`pm_stretch_compliance = 0.0`. It uses 777 nodes rather than 2,104, with 944
supported surface triangles and 19 fixed nodes across the same Goal attachment.
Mass, gravity, source geometry and Goal weights are unchanged. This is material
configuration passed through the exporter and shared API, not a gallery force.

### Stiffening the exported soft body

On the soft object, use **Object Properties → Custom Properties** and re-export:

- `pm_shape_matching_stiffness = 0.35` restores the co-rotated rest shape while
  retaining the fixed Goal region. Increase toward 1 for stronger restoration;
  this is whole-body form recovery, not a local bending modulus.
- `pm_solver_iterations = 32` gives the spring graph more time to transmit load
  from the fixed region. Up to 64 is supported, at additional simulation cost.
- `pm_stretch_compliance` controls spring softness: smaller is stiffer, zero is
  the hard-constraint limit. The default `1e-7` is already nearly hard; simply
  reducing it cannot compensate for insufficient solver convergence.

Before the coarser preset, on the 2,104-node `SoftbodyFluid` fixture, after four seconds of gravity without
water, maximum node displacement was 1.79 m at defaults and 0.65 m with shape
matching 0.35 plus 32 graph iterations.
Shape matching 0.5 plus 64 iterations reduced it further to 0.38 m.
That firmer preset roughly doubled physics time in a short water-loaded run
(20.4 to 40.9 ms/frame on the test GPU); use 0.35/32 as a cheaper starting point.
These are displacement measurements (including rotation), not vertical sag or
material guarantees. The current 777-node preset holds the slab much closer to
its authored position: about 8 cm of unloaded sag after ten seconds, while
still flexing under the water stream. The stronger correction bound is a tested
setting for this material, not a new global solver default.

Blender's native **Edges → Pull, Push, Bending, Stiff Quads** affect Blender's
own solver but are **not currently exported** to ParallelMater. Do not expect
those controls to change this runtime. For Blender-only simulation, Pull/Push
resist stretching/compression and Bending resists angular deformation; damping
reduces motion, not static sag. See the [Blender Edges reference](https://docs.blender.org/manual/en/5.0/physics/soft_body/settings/edges.html).

## Cloth Shape Pin Group

`examples/assets/Cloth.blend` has a 33×33 subdivided sheet. Its top and
bottom rows belong to `FixedVertices`, selected in **Cloth → Shape → Pin
Group**, with pin stiffness `1.0`. The exporter writes the undeformed rest
mesh, not Blender's evaluated Cloth modifier, and records each weighted pin
coordinate in schema-2 `pm_system = "cloth"` metadata. Pin coordinates are
matched to glTF positions after triangulation, including vertices split by
UVs or normals. Weight 1 becomes zero inverse mass and is exactly fixed;
partial weights retain proportionate motion. Optional `pm_vertex_mass` and
`pm_thickness` object properties set the cloth's physical scale.
Keep the exported surface topologically connected: separate coincident
vertices are distinct solver particles even when they receive the same pin.

## Closed pressure cloth and contained fluid

For an air-filled closed cloth such as `ClothWater.blend`, enable **Cloth →
Physical Properties → Pressure**. Leave **Custom Volume** off to preserve the
authored initial volume, and leave Fluid Density at zero for air. Pressure
Scale maps to inverse volume compliance. A pressure cloth may be unpinned; the
exporter welds glTF vertices split only by render seams before building its
closed physics topology.

Set the cloth object's Boolean custom property `pm_contains_fluid` when a
Geometry-flow liquid volume belongs inside that cloth. The gallery translates
this relationship into a fluid/cloth `PmCouplingState`; containment,
reaction forces, and volume preservation live in the installed physics API,
not in scene-specific gallery code. Uniform Pressure Force is currently
required to remain zero because the API implements target-volume pressure,
not a separate constant inflation force.

The gallery records cloth creation through `pmCmdWriteCloths` and updates its
OptiX triangles each frame. The scene also contains the authored passive box
and active sphere. All four Cloth gallery entries start with gravity straight
down. Arrow keys steer it camera-relatively within a 45-degree tilt, returning
to straight down when released.
The API advances rigid bodies and cloth together at each substep. Cloth vertex
velocity damping (`ClothOptions::velocity_damping`, default 5/s) and
tangential contact friction (`contact_friction`, default 0.4) are configurable.
Rigid and cloth exchange friction impulses while touching, but separating
bodies shed tangential friction and are free to escape; cloth-side impulses
are limited to avoid local vertex pops.
Run `--cloth` for headless output or select Cloth with `Tab`; `R` resets it and
`F` shows rigid/cloth timings.

`ClothTear.blend` derives from the same sheet, authoring
`pm_break_strain = 0.96`, 16 persistent substeps,
`pm_impact_break_impulse = 0.001`, zero stretch compliance, and 24 solver
iterations. The sheet retains its original size. The 35 kg rigid sphere keeps
its original position and ground friction, so it falls first and can then be
rolled into the sheet with arrow-key gravity. The API breaks loaded bonds and
separates triangle-local surface faces without deleting them; the gallery does
not decide which bonds fail.

`SoftbodyCloth.blend` contains two independent cloths. Select a cloth object and
open **Object Properties → Custom Properties** to edit its ParallelMater settings:

- `Plane.002`, the bridge: `pm_break_strain = 0` keeps all bonds intact.
- `Plane.003`, the curtain: `pm_break_strain = 0.10` permits a bond to tear after
  extending 10% beyond its rest length for `pm_fracture_persistence_substeps = 4`
  consecutive substeps. It uses no impact-triggered fracture.
- Both retain their authored `PinEdge` groups and pin stiffness 1.0.
- `pm_solver_iterations` is 48 for the loaded bridge and 24 for the curtain.
  Increasing this improves spring convergence under load, at additional cost.

Blender's Cloth modifier does not supply a native tearing toggle for this
export contract; the custom properties travel through the same exporter used
by all scenes. Zero break strain and zero impact threshold mean unbreakable.
Change these properties, save, then export through **ParallelMater Scene**.
The gallery starts with gravity down; arrow steering tilts it up to 45°.
`X` includes cloth/soft-body reactions, `V` and `B` show the two systems' spring
and surface structures, and `M` includes both systems' contact forces.

`ClothPaint.blend` derives from the supplied `Cloth.blend`. It retains the pinned
top and bottom rows and the active rigid sphere, authors `pm_paintable = true`,
a 128×128 paint mask, `pm_paint_source` naming that sphere, and a 0.18-unit
world-space paint brush radius. The sphere has an authored forward velocity
so it can contact the cloth while gravity remains straight down. The gallery
records the cloth UVs with `pmCmdWritePaintFields` and registers a rigid-to-cloth
paint rule. Rigid–cloth collision and disk-shaped texel stamping are in the API;
the gallery chooses blue and cubic filtering, while the variant has a neutral
dry material so contact marks are visible. The cloth remains intact.
The example authoring helper `examples/assets/tools/make_cloth_variants.py`
preserves the original `.blend` file. It only creates source `.blend` variants;
export both through the common exporter above.

## Liquid Flow scene

`examples/assets/Fluid.blend` is the PR 7 source. It contains `Inflow` with
Blender **Fluid → Flow → Liquid → Inflow**, `Outflow` with Liquid Outflow, and a
sculpted `Plane` with **Rigid Body → Passive**. The exporter maps the Flow
modifiers to `pm_system = "fluid_inflow"` and `"fluid_outflow"` glTF nodes.
Plane geometry, transform, initial velocity, and flow behavior come from the
authored file. Blender's fluid solver and Domain are not used at runtime.

An inflow exports its actual triangle surface. The API subdivides it into
coarse sites; a site emits only after nearby water clears. Blender's enabled
Initial Velocity controls the new particles and naturally changes throughput.
Optional `pm_source_spacing` sets site spacing/clearance in metres; zero uses
the fluid support radius. The old `pm_particles_per_second` property is ignored.
No rectangular approximation is used for inflow. Outflow remains a rectangle.
The gallery uses a 30,000-particle capacity, 0.045 m particle radius, and 0.18 m
support radius; those are example settings, not hidden physics-world defaults.
The passive surface is exported as its authored triangles and collides on both
sides. Bright agitated surface particles visualize foam; the gallery also
reconstructs a continuous, example-only water surface.

Export with:

```bash
blender --background examples/assets/Fluid.blend \
  --python tools/blender/export_parallel_mater_scene.py -- \
  --output examples/assets/Fluid.glb
./build-gallery/parallel-mater-gallery --fluid
```

`examples/assets/FluidRigid.blend` adds a 4×4×4 Array of ACTIVE icospheres to
the same inflow, outflow, and passive triangle terrain. Export it with the
same script to `FluidRigid.glb`, then run the gallery with `--fluid-rigid`.
The 64 spheres are separate dynamic bodies, not one compound mesh; they share
one uploaded triangle mesh. Particle impacts change their linear and angular
velocity, while their moving triangles push particles and produce opt-in
contact events.

## One-shot Geometry flow and paint

`examples/assets/Pegs.blend` contains a closed cylinder with **Fluid → Flow →
Liquid → Geometry**, a passive bowl, four passive pegs, an invisible passive
containment cylinder, and one ACTIVE icosphere. The exporter marks the flow
cylinder as
`pm_system = "fluid_initial_volume"`. The gallery uses the public geometry
sampler to fill its authored mesh on a deterministic HCP lattice, then creates
those particles once when the scene starts. No Blender Domain or baked cache
is needed, and the flow does not emit on later frames. `P` changes the maximum
particle count and restarts; if lower than the authored fill, the gallery
selects an evenly distributed subset.

The Geometry-flow object can author `pm_particle_spacing` (metres) and
`pm_gravity_scale` as Blender custom properties. The Peg source uses 0.052 m
spacing and 2× standard gravity. Particle rest volume follows the HCP cell
volume, so denser sampling does not silently increase fluid mass. These are
general flow settings, not Peg-specific solver branches.

The Peg Paint example paints persistent blue masks from qualifying fluid
contacts with the bodies' exported UV surfaces. The simulation owns the
two-sided paint field; the gallery renderer chooses blue and cubic filtering. The
exporter retains each render mesh's UV coordinates. Only the bowl has
`pm_paintable = true`; the active sphere and four pegs remain unpainted. Other
scenes do not allocate paint masks unless their authors opt in. Front and back
faces maintain separate paint channels, so
water touching the inside of a thin bowl does not tint its outside. Run with
`./build-gallery/parallel-mater-gallery --peg-paint`.
The four peg caps have a slight authored crown, giving resting droplets a
downhill path off the posts without peg-specific fluid forces.
The bowl and invisible containment cylinder use Blender rigid-body friction
`0.05`, while the pegs retain `0.5`. This lets water slide down the curved
wall instead of accumulating as a thin raised layer. Contact paint records
one texel per qualifying contact and reconstructs the mask with a smooth cubic
B-spline filter.
The bowl authors `pm_paint_resolution = 64`; its half-height UV chart uses
64×32 texels. Larger future paintable surfaces retain the default resolution.

The ACTIVE Icosphere is authored at 125 kg and starts above the bowl at
Y 0.4 m. At its 0.268 m radius, a 1 kg sphere floats in a water-density
fill; the heavier value falls through the water and settles against the bowl.
Keep mass and initial position as authored Rigid Body properties rather than
hidden scene-specific runtime overrides.
