// SPDX-License-Identifier: MIT
#include <parallel_mater_gallery/physics_debug.hpp>
#include <scene_builder.hpp>

#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>

namespace {

void check(bool condition, const char *message) {
    if (!condition) throw std::runtime_error(message);
}

} // namespace

int main() try {
    parallel_mater::gallery::CommandSceneFrame frame;
    frame.revision = 42U;
    frame.rigid_states.resize(1U);
    frame.constraint_states.push_back({PM_TRUE, PM_FALSE, 3.5F});
    PmContactEvent contact{};
    contact.first = 0U;
    contact.second = 1U;
    contact.normalImpulse = 2.25F;
    frame.contacts.push_back(contact);
    parallel_mater::gallery::PhysicsDebugHistory history(2U);
    PmStepInfo step{};
    step.timestep = 1.0F / 60.0F;
    step.substeps = 4U;
    step.gravity[1] = -9.81F;
    std::string error;
    for (auto revision : {40U, 41U, 42U}) {
        frame.revision = revision;
        check(history.record(frame, step, error), "record capture history");
    }
    check(history.frames().size() == 2U &&
          history.frames().front().revision == 41U &&
          history.frames().back().revision == 42U,
          "capture must retain the newest frames in chronological order");

    const auto stamp = std::chrono::steady_clock::now()
                           .time_since_epoch().count();
    const std::filesystem::path output =
        std::filesystem::temp_directory_path() /
        ("parallel-mater-physics-debug-test-" + std::to_string(stamp) +
         ".log");
    check(parallel_mater::gallery::write_physics_debug_capture(
              frame, output, error, &history),
          error.empty() ? "write physics capture" : error.c_str());

    std::ifstream stream(output);
    const std::string contents{std::istreambuf_iterator<char>(stream),
                               std::istreambuf_iterator<char>()};
    std::error_code remove_error;
    std::filesystem::remove(output, remove_error);
    check(contents.find("parallel_mater_physics_capture 4") !=
              std::string::npos,
          "capture must report the current format");
    check(contents.find("frame 42 rigid 1 constraints 1") !=
              std::string::npos,
          "capture header must count constraint states");
    check(contents.find(
              "constraint 0 enabled 1 broken 0 applied_impulse 3.5") !=
              std::string::npos,
          "capture must include constraint state");
    check(contents.find("rigid_history 2") != std::string::npos &&
          contents.find("history_frame 41 timestep") <
              contents.find("history_frame 42 timestep") &&
          contents.find("substeps 4 gravity 0 -9.81") != std::string::npos,
          "capture must write the motion history and its gravity inputs");
    const auto history_end = contents.find("end_history_frame");
    check(contents.find("normal_impulse 2.25") < history_end &&
          contents.find("applied_impulse 3.5") < history_end,
          "history must retain contacts and joint forces, not just poses");
    frame.revision = 1U;
    check(history.record(frame, step, error) && history.frames().size() == 1U &&
          history.frames().front().revision == 1U,
          "reset must discard history from the previous simulation");
    return 0;
} catch (const std::exception &exception) {
    std::cerr << "FAIL: " << exception.what() << '\n';
    return 1;
}
