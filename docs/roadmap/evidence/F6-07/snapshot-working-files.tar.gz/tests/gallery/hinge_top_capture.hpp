// SPDX-License-Identifier: MIT
#pragma once

#include <parallel_mater_gallery/scene.hpp>

#include <array>

namespace hinge_top_capture {
using parallel_mater::RigidBodyState;

// M capture 1792074468968, frame 2073: immediately before Right is pressed.
// Only public body state is restored; contact/solver caches start empty.
// Keep the authored meshes, masses, friction, joints and spring unchanged.
inline constexpr std::array<const char *, 4> names{
    "Gear", "Gear.001", "Gear.002", "Ground.002"};
inline constexpr std::array<RigidBodyState, 4> states{{
    {{-1.39690912F, 5.26486826F, 0.321522236F},
     {0.347802937F, -0.615656555F, -0.615656614F, 0.347802997F},
     {2.07317781F, 3.48106813F, 9.62050908e-5F},
     {1.19576362e-6F, 3.80805545e-6F, -2.49270654F}},
    {{-0.00123224803F, 1.39732695F, 1.87125552F},
     {0.63220185F, 0.316734195F, 0.316734165F, 0.632202268F},
     {2.38274811e-6F, 1.19136739e-5F, 3.69530085e-6F},
     {1.25820543e-5F, -2.43598333e-6F, 1.36825073F}},
    {{3.06544256F, 1.39732742F, 2.2055459F},
     {0.669637799F, -0.22712338F, -0.227123454F, 0.669638038F},
     {-4.87874095e-5F, 7.7194627e-6F, -7.69934559e-6F},
     {8.225491e-6F, -1.14934692e-5F, -0.605497777F}},
    {{5.19924974F, 3.47652507F, 2.20538616F},
     {-2.23634771e-7F, 5.45621504e-8F, 0.707106948F, 0.70710659F},
     {2.72171364e-5F, -1.2084924F, 8.29557102e-5F},
     {2.1786871e-5F, -1.2911597e-5F, 3.79184439e-6F}},
}};
} // namespace hinge_top_capture
