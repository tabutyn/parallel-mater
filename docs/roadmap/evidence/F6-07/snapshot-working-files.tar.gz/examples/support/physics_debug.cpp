// SPDX-License-Identifier: MIT
#include <parallel_mater_gallery/physics_debug.hpp>
#include <scene_builder.hpp>

#include <chrono>
#include <fstream>
#include <iomanip>
#include <new>
#include <system_error>

namespace parallel_mater::gallery {
namespace {

std::size_t sample_bytes(const RigidPhysicsSample &sample) {
    return sizeof(sample) + sample.bodies.size() * sizeof(PmRigidState) +
        sample.constraints.size() * sizeof(PmConstraintState) +
        sample.contacts.size() * sizeof(PmContactEvent);
}

void write_rigid_states(std::ostream &stream,
                        const std::vector<PmRigidState> &states) {
    for (std::size_t index = 0; index < states.size(); ++index) {
        const auto &state = states[index];
        stream << "rigid " << index << " position";
        for (float value : state.position) stream << ' ' << value;
        stream << " orientation";
        for (float value : state.orientation) stream << ' ' << value;
        stream << " linear_velocity";
        for (float value : state.linearVelocity) stream << ' ' << value;
        stream << " angular_velocity";
        for (float value : state.angularVelocity) stream << ' ' << value;
        stream << '\n';
    }
}

void write_constraint_states(std::ostream &stream,
                             const std::vector<PmConstraintState> &states) {
    for (std::size_t index = 0; index < states.size(); ++index) {
        const auto &state = states[index];
        stream << "constraint " << index << " enabled " << state.enabled
               << " broken " << state.broken << " applied_impulse "
               << state.appliedImpulse << '\n';
    }
}

void write_contacts(std::ostream &stream,
                     const std::vector<PmContactEvent> &contacts) {
    for (const auto &contact : contacts)
        stream << "contact " << static_cast<unsigned>(contact.type)
               << ' ' << contact.first << ' ' << contact.second
               << " position " << contact.position.x << ' '
               << contact.position.y << ' ' << contact.position.z
               << " normal " << contact.normal.x << ' '
               << contact.normal.y << ' ' << contact.normal.z
               << " penetration " << contact.penetration
               << " normal_impulse " << contact.normalImpulse << '\n';
}

[[nodiscard]] bool default_capture_path(std::uint64_t frame,
                                        std::filesystem::path &output,
                                        std::string &error) {
    std::error_code filesystem_error;
    const std::filesystem::path temporary =
        std::filesystem::temp_directory_path(filesystem_error);
    if (filesystem_error) {
        error = "could not find the temporary directory: " +
                filesystem_error.message();
        return false;
    }
    const auto stamp = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    output = temporary /
        ("parallel-mater-physics-" + std::to_string(stamp) + "-frame-" +
         std::to_string(frame) + ".log");
    return true;
}

} // namespace

bool PhysicsDebugHistory::record(const CommandSceneFrame &frame,
                                 const PmStepInfo &step, std::string &error) {
    if (capacity_ == 0U) return true;
    try {
        RigidPhysicsSample sample{frame.revision, step, frame.rigid_states,
                                  frame.constraint_states, frame.contacts};
        // A reset must not splice the previous simulation into a new replay.
        if (!frames_.empty() && frame.revision <= frames_.back().revision) {
            frames_.clear();
            bytes_ = 0U;
        }
        const auto bytes = sample_bytes(sample);
        frames_.push_back(std::move(sample));
        bytes_ += bytes;
        constexpr std::size_t budget = 32U * 1024U * 1024U;
        while (frames_.size() > capacity_ || bytes_ > budget) {
            bytes_ -= sample_bytes(frames_.front());
            frames_.pop_front();
        }
    } catch (const std::bad_alloc &) {
        error = "could not retain physics capture history";
        return false;
    }
    return true;
}

bool write_physics_debug_capture(const CommandSceneFrame &frame,
                                 const std::filesystem::path &output,
                                 std::string &error,
                                 const PhysicsDebugHistory *history) {
    error.clear();
    std::ofstream stream(output, std::ios::out | std::ios::trunc);
    if (!stream) {
        error = "could not open physics capture log";
        return false;
    }
    stream << std::setprecision(9)
           << "parallel_mater_physics_capture 4\n";
    if (history != nullptr) {
        stream << "rigid_history " << history->frames().size() << '\n';
        for (const auto &sample : history->frames()) {
            stream << "history_frame " << sample.revision
                   << " timestep " << sample.step.timestep
                   << " substeps " << sample.step.substeps << " gravity "
                   << sample.step.gravity[0] << ' ' << sample.step.gravity[1]
                   << ' ' << sample.step.gravity[2] << '\n';
            write_rigid_states(stream, sample.bodies);
            write_constraint_states(stream, sample.constraints);
            write_contacts(stream, sample.contacts);
            stream << "end_history_frame\n";
        }
    }
    stream << "frame " << frame.revision
           << " rigid " << frame.rigid_states.size()
           << " constraints " << frame.constraint_states.size()
           << " fluid " << frame.fluid_particles.size()
           << " cloth " << frame.cloth_vertices.size()
           << " soft_body " << frame.soft_body_nodes.size()
           << " rope " << frame.rope_nodes.size()
           << " smoke " << frame.smoke_particles.size()
           << " contacts " << frame.contacts.size() << '\n';
    write_rigid_states(stream, frame.rigid_states);
    write_constraint_states(stream, frame.constraint_states);
    for (const PmFluidParticleOutput &particle : frame.fluid_particles) {
        stream << "fluid " << particle.stableId << " position "
               << particle.position[0] << ' ' << particle.position[1] << ' '
               << particle.position[2] << " velocity "
               << particle.velocity[0] << ' ' << particle.velocity[1] << ' '
               << particle.velocity[2] << " acceleration "
               << particle.acceleration[0] << ' ' << particle.acceleration[1]
               << ' ' << particle.acceleration[2] << " foam "
               << particle.foam << '\n';
    }
    write_contacts(stream, frame.contacts);
    for (const PmDebugRecord &record : frame.debug_records) {
        stream << "debug " << static_cast<unsigned>(record.type) << ' '
               << record.objectIndex << ' ' << record.elementIndex
               << " position " << record.position.x << ' '
               << record.position.y << ' ' << record.position.z
               << " velocity " << record.velocity.x << ' '
               << record.velocity.y << ' ' << record.velocity.z
               << " force " << record.force.x << ' ' << record.force.y << ' '
               << record.force.z << '\n';
    }
    stream << "end_frame\n";
    if (!stream) {
        error = "could not finish physics capture log";
        return false;
    }
    return true;
}

bool save_physics_debug_capture(const CommandSceneFrame &frame,
                                std::filesystem::path &output,
                                std::string &error,
                                const PhysicsDebugHistory *history) {
    output.clear();
    if (!default_capture_path(frame.revision, output, error)) return false;
    return write_physics_debug_capture(frame, output, error, history);
}

} // namespace parallel_mater::gallery
