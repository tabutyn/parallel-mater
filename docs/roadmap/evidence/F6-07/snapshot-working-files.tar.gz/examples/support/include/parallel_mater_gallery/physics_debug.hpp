// SPDX-License-Identifier: MIT
#pragma once

#include <parallel_mater/parallel_mater.h>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <filesystem>
#include <string>
#include <vector>

namespace parallel_mater::gallery {

struct CommandSceneFrame;

struct RigidPhysicsSample {
    std::uint64_t revision{};
    PmStepInfo step{};
    std::vector<PmRigidState> bodies;
    std::vector<PmConstraintState> constraints;
    std::vector<PmContactEvent> contacts;
};

// Bounded history of public output. Retain rigid contacts even when the
// contact overlay is hidden; M needs the lead-up to a visible failure.
class PhysicsDebugHistory {
  public:
    explicit PhysicsDebugHistory(std::size_t capacity = 300U)
        : capacity_(capacity) {}
    [[nodiscard]] bool record(const CommandSceneFrame &frame,
                              const PmStepInfo &step, std::string &error);
    [[nodiscard]] const std::deque<RigidPhysicsSample> &frames() const {
        return frames_;
    }
  private:
    std::size_t capacity_{};
    std::size_t bytes_{};
    std::deque<RigidPhysicsSample> frames_;
};

// The frame is already host-visible public-API output; persistence never
// borrows private solver memory.
[[nodiscard]] bool save_physics_debug_capture(
    const CommandSceneFrame &frame, std::filesystem::path &output,
    std::string &error, const PhysicsDebugHistory *history = nullptr);

[[nodiscard]] bool write_physics_debug_capture(
    const CommandSceneFrame &frame, const std::filesystem::path &output,
    std::string &error, const PhysicsDebugHistory *history = nullptr);

} // namespace parallel_mater::gallery
