$ErrorActionPreference = 'Stop'
$F826Source = 'C:/Users/tabut/Repos/ballroller-2026/.codex-worktrees/parallel-mater-f8-26-20261101'
$F826Build = 'D:/Repos/parallel-mater-f8-26-build-20261101'
$F826Evidence = 'D:/Repos/parallel-mater-f8-26-evidence-20261101'
$F826Python = 'C:/Users/tabut/AppData/Local/Programs/Python/Python313/python.exe'
$F826Slang = 'D:/Repos/parallel-mater/build-d3d12-full/_deps/parallel_mater_slang-src/bin/slangc.exe'
& 'C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation | Out-Null
$env:PATH = 'C:/Users/tabut/AppData/Local/Programs/Python/Python313;C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja;C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v12.9/bin;' + $env:PATH
$env:GIT_CONFIG_COUNT = '2'
$env:GIT_CONFIG_KEY_0 = 'safe.directory'
$env:GIT_CONFIG_VALUE_0 = $F826Source
$env:GIT_CONFIG_KEY_1 = 'core.autocrlf'
$env:GIT_CONFIG_VALUE_1 = 'false'
$env:PYTHONUTF8 = '1'
Set-Location -LiteralPath $F826Source
New-Item -ItemType Directory -Path $F826Evidence -Force | Out-Null
