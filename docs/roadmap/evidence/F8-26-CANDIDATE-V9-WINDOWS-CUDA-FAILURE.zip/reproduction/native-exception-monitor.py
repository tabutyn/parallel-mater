"""Record native exception codes/parameters without changing the tested binary."""
import ctypes as C
from ctypes import wintypes as W
import json
import os
import subprocess
import sys
import time
from pathlib import Path

class ExceptionRecord(C.Structure):
    _fields_ = [('code', W.DWORD), ('flags', W.DWORD), ('record', C.c_void_p),
                ('address', C.c_void_p), ('count', W.DWORD),
                ('information', C.c_size_t * 15)]

class ExceptionInfo(C.Structure):
    _fields_ = [('record', ExceptionRecord), ('first_chance', W.DWORD)]

class CreateInfo(C.Structure):
    _fields_ = [('file', W.HANDLE), ('process', W.HANDLE), ('thread', W.HANDLE),
                ('base', C.c_void_p)]

class LoadInfo(C.Structure):
    _fields_ = [('file', W.HANDLE), ('base', C.c_void_p)]

class EventUnion(C.Union):
    _fields_ = [('exception', ExceptionInfo), ('create', CreateInfo),
                ('load', LoadInfo), ('exit_code', W.DWORD), ('buffer', C.c_byte * 160)]

class DebugEvent(C.Structure):
    _fields_ = [('code', W.DWORD), ('process_id', W.DWORD),
                ('thread_id', W.DWORD), ('data', EventUnion)]

k = C.WinDLL('kernel32', use_last_error=True)
k.WaitForDebugEvent.argtypes = [C.POINTER(DebugEvent), W.DWORD]
k.WaitForDebugEvent.restype = W.BOOL
k.ContinueDebugEvent.argtypes = [W.DWORD, W.DWORD, W.DWORD]
k.ContinueDebugEvent.restype = W.BOOL
k.GetFinalPathNameByHandleW.argtypes = [W.HANDLE, W.LPWSTR, W.DWORD, W.DWORD]
k.GetFinalPathNameByHandleW.restype = W.DWORD
k.CloseHandle.argtypes = [W.HANDLE]

def path_for(handle):
    result = C.create_unicode_buffer(32768)
    return result.value if not handle else (
        result.value if k.GetFinalPathNameByHandleW(handle, result, len(result), 0) else '')

output = Path(sys.argv[1])
command = sys.argv[2:]
records = {'command': command, 'cuda_launch_blocking': os.environ.get('CUDA_LAUNCH_BLOCKING'),
           'modules': [], 'exceptions': []}
started = time.monotonic()
with output.with_suffix('.log').open('w', encoding='utf-8') as log:
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                               creationflags=0x00000002 | 0x08000000)
    while True:
        event = DebugEvent()
        if not k.WaitForDebugEvent(C.byref(event), 1000):
            if C.get_last_error() == 121:
                if time.monotonic() - started > 180:
                    process.terminate()
                    records['timeout'] = True
                continue
            raise C.WinError(C.get_last_error())
        status = 0x00010002
        if event.code == 1:
            item = event.data.exception
            rec = item.record
            if rec.code not in (0x80000003, 0x80000004):
                records['exceptions'].append({
                    'code': f'0x{rec.code:08x}', 'first_chance': bool(item.first_chance),
                    'address': hex(rec.address or 0), 'thread_id': event.thread_id,
                    'parameters': [hex(rec.information[i]) for i in range(min(rec.count, 15))]})
                status = 0x80010001
        elif event.code in (3, 6):
            data = event.data.create if event.code == 3 else event.data.load
            records['modules'].append({'base': hex(data.base or 0), 'path': path_for(data.file)})
            if data.file:
                k.CloseHandle(data.file)
        elif event.code == 5:
            records['exit_code'] = event.data.exit_code
            k.ContinueDebugEvent(event.process_id, event.thread_id, status)
            break
        k.ContinueDebugEvent(event.process_id, event.thread_id, status)
records['elapsed_seconds'] = time.monotonic() - started
output.write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in records.items() if key != 'modules'}, indent=2))
