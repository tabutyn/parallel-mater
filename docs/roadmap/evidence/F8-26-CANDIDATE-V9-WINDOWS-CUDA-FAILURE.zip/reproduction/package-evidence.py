"""Package the unmodified candidate's failed Windows qualification evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

root = Path('C:/Users/tabut/Repos/ballroller-2026')
source = root / '.codex-worktrees/parallel-mater-f8-26-20261101'
raw = Path('D:/Repos/parallel-mater-f8-26-evidence-20261101')
build = Path('D:/Repos/parallel-mater-f8-26-build-20261101')
destination = root / '.codex-tmp'
stem = 'F8-26-CANDIDATE-V9-WINDOWS-CUDA-FAILURE'
archive = destination / (stem + '.zip')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

members = {}
for path in raw.iterdir():
    if path.is_file() and path.suffix in {'.json', '.xml', '.log', '.txt'}:
        members[path.name] = path
for directory in ('device-capture', 'soft-fluid-isolated'):
    for path in (raw / directory).rglob('*'):
        if path.is_file():
            members[path.relative_to(raw).as_posix()] = path
for path in (raw / 'sdk').glob('*.log'):
    members['sdk/' + path.name] = path
members['sdk/report.json'] = raw / 'sdk/report.json'
members['reproduction/native-exception-monitor.py'] = destination / 'f826-debug.py'
members['reproduction/windows-environment.ps1'] = destination / 'f826-env.ps1'
members['reproduction/package-evidence.py'] = Path(__file__)
members['candidate/realtime-candidate-v9.json'] = source / 'conformance/v1/qualification/realtime-candidate-v9.json'
records = [{'path': name, 'sha256': digest(path), 'bytes': path.stat().st_size}
           for name, path in sorted(members.items())]
manifest = json.dumps(records, indent=2, sort_keys=True).encode() + b'\n'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for name, path in sorted(members.items()):
        stream.write(path, name)
    stream.writestr('SHA256SUMS.json', manifest)
with zipfile.ZipFile(archive) as stream:
    assert stream.testzip() is None
    for record in records:
        assert hashlib.sha256(stream.read(record['path'])).hexdigest() == record['sha256']

machine = load(raw / 'machine.json')
tests = ET.parse(raw / 'ctest.xml').getroot()
failed = [item.attrib['name'] for item in tests.findall('testcase') if item.find('failure') is not None]
sdk = load(raw / 'sdk/report.json')
cases = [load(path) for path in (raw / 'device-capture/raw/plain/public-cases').glob('*.json')]
capabilities = load(raw / 'device-capture/logs/plain/capabilities.log')
installed = raw / 'sdk/relocated-sdk'
binary_paths = {
    'build_cuda_driver': build / 'parallel_mater_driver_slang_cuda.dll',
    'build_conformance_runner': build / 'parallel-mater-conformance.exe',
    'build_gallery': build / 'Parallel-Mater.exe',
    'gallery_test': build / 'parallel-mater-command-gallery-tests.exe',
    'fluid_test': build / 'tests/solver/parallel-mater-fluid-realtime-cuda-tests.exe',
    'installed_cuda_driver': installed / 'bin/parallel_mater_driver_slang_cuda.dll',
    'installed_runner': installed / 'bin/parallel-mater-conformance.exe',
    'installed_validation_layer': installed / 'bin/parallel_mater_layer_validation.dll',
    'installed_driver_manifest': installed / 'share/parallel-mater/drivers.d/parallel_mater_slang_cuda.json',
    'installed_layer_manifest': installed / 'share/parallel-mater/layers.d/parallel_mater_validation.json',
}
report = {
    'schema': 'parallel-mater-realtime-device-qualification/v1',
    'status': 'failed', 'captured_at': datetime.now(timezone.utc).isoformat(),
    'task': 'F8-26', 'claim_pr': 633,
    'lease_token': 'd294c5b8-34e9-4255-83bd-bf0a45d8ab23',
    'candidate': {
        'id': 'realtime-single-step-v1-ba67db3',
        'source_revision': 'ba67db35447b1f9022be4c3d8aae59dbe6d514d5',
        'source_tree': '2dfc4b680fac97519aee1c67526bddffdd01c474',
        'manifest': 'conformance/v1/qualification/realtime-candidate-v9.json',
        'manifest_sha256': '4ed4ed7a097928944ac5667e8120e2447affda962a258e56c01dfd0d90d9dd4b',
        'exact_source_ci_run': 41257022787,
        'target': 'windows-gtx1080-slang-cuda', 'runtime_variant': 'cuda-runtime',
    },
    'qualification_harness': {
        'source_revision': machine['source_revision'], 'source_tree': machine['source_tree'],
        'source_dirty': machine['source_dirty'], 'candidate_production_delta': 'none',
        'unprotected_test_delta': 'Merged F8-72 repairs the CUDA rigid spatial fixture only.',
        'protected_closures_unchanged': True,
        'candidate_checker': 'PASS: realtime-single-step-v1-ba67db3 protected closure and routing are exact',
        'windows_checkout': 'Restore Git LF bytes, refresh newline-only index metadata, and prove the index tree equals HEAD before configuring/building. No tracked source changes.',
    },
    'machine': machine,
    'cuda_memory_attributes': load(raw / 'cuda-memory-attributes.json'),
    'results': {
        'clean_release_build': {'status': 'passed', 'configuration': 'Release', 'generator': 'Ninja', 'cuda_architectures': '61', 'source_dirty': False},
        'registered_tests': {'status': 'failed', 'total': int(tests.attrib['tests']), 'passed': 128, 'failed': int(tests.attrib['failures']), 'skipped': int(tests.attrib['skipped']), 'elapsed_seconds': 270.59, 'failed_tests': failed},
        'installed_sdk_relocation': {'status': sdk['status'], 'checks_passed': sum(item['status'] == 'passed' for item in sdk['checks']), 'checks_failed': sum(item['status'] != 'passed' for item in sdk['checks']), 'source_dirty': sdk['source_dirty']},
        'installed_public_capture': {
            'status': 'failed', 'capture_exit_code': 2, 'runner_exit_code': 3221225478,
            'runner_exception': '0xc0000006', 'stopped_at': 'soft-body-fluid',
            'capability_rows_discovered': len(capabilities),
            'plain_public_cases_completed': sum(item.get('execution_status') == 'completed' for item in cases),
            'required_public_cases': 30, 'plain_public_cases_with_quality_evaluated': sum(item.get('quality_status') != 'not_evaluated' for item in cases),
            'validation_mode': 'not_reached', 'scenarios': 'not_reached',
            'negative_controls': 'not_reached', 'workloads': 'not_reached',
            'independent_validation': 'not_run_no_complete_capture',
        },
        'installed_gallery': 'not_deployed_after_required_Gallery_crash',
        'fixed_tick_quality_and_performance': 'not_qualified; required installed-public scenarios and cold/sustained workload distributions were not reached',
    },
    'failures': [
        {'id': 'windows-fluid-fixture-managed-read', 'kind': 'test_harness',
         'reproduction': 'parallel-mater-fluid-realtime-cuda-tests.exe',
         'exception': '0xc0000006', 'access_status': '0xc0000022',
         'source': 'tests/solver/fluid_realtime_cuda_tests.cu:Fixture::run_tick',
         'finding': 'The fixture launches fluid_realtime_predict and then dereferences managed *count on the CPU to form later kernel arguments. The device reports concurrentManagedAccess=0. Normal execution crashes; unchanged binary with CUDA_LAUNCH_BLOCKING=1 finishes all assertions. Forced synchronization is diagnostic only and does not qualify the fixture or performance.',
         'normal_diagnostic': 'fluid-debug-d.json', 'blocking_diagnostic': 'fluid-blocking-diagnostic.json'},
        {'id': 'windows-gallery-peg-paint', 'kind': 'production_runtime',
         'reproduction': 'parallel-mater-command-gallery-tests.exe --backend cuda --scene Pegs.glb --frames 1',
         'exception': '0xc0000006', 'access_status': '0xc0000022',
         'faulting_module': 'parallel_mater_driver_slang_cuda.dll',
         'finding': 'Fails in the first PEG PAINT frame and in an isolated single-scene reproduction. CPU read of managed-address range fails with access denied. Forced kernel launch synchronization does not remove this failure. Production boundary code reads paint field metadata after asynchronous native clear operations; this is a source-level lead, not a symbolized root-cause proof.',
         'source_lead': 'src/simulation/production_realtime_backend.cu.inc:NativeRealtimeBackend::boundary',
         'normal_diagnostic': 'gallery-peg-debug.json', 'blocking_diagnostic': 'gallery-peg-blocking-diagnostic.json'},
        {'id': 'windows-installed-soft-body-fluid', 'kind': 'production_runtime',
         'reproduction': 'parallel-mater-conformance.exe --case soft-body-fluid --root <source> --output <new-directory>',
         'exception': '0xc0000006', 'access_status': '0xc0000022',
         'finding': 'The relocated public runner crashes at soft-body-fluid in --case all after 19 completed cases. Isolated normal-execution reproduction also fails with a managed-address CPU read and access-denied status. Exact runtime site requires follow-up diagnosis.',
         'normal_diagnostic': 'soft-fluid-debug.json'},
    ],
    'reference': {
        'url': 'https://docs.nvidia.com/cuda/cuda-programming-guide/04-special-topics/unified-memory.html',
        'relevance': 'NVIDIA documents that devices without concurrent managed access cannot access globally attached managed memory on the CPU while GPU operations make it inaccessible; Windows uses this restricted model. Device attributes and exception parameters are retained separately from the source-level diagnosis.',
    },
    'artifacts': {
        'tracked_archive': 'docs/roadmap/evidence/' + archive.name,
        'tracked_archive_sha256': digest(archive), 'tracked_archive_bytes': archive.stat().st_size,
        'tracked_archive_file_count': len(members) + 1,
        'member_manifest': 'SHA256SUMS.json', 'member_manifest_sha256': hashlib.sha256(manifest).hexdigest(),
        'contents': 'Complete configure/build/CTest logs and JUnit, SDK report and logs, partial public capture, native exception monitor and normal/blocking diagnostic results, machine attributes, exact candidate manifest, binary hashes in this report. Executables are identified by hashes rather than embedded.',
        'binary_hashes': {name: digest(path) for name, path in binary_paths.items()},
    },
    'commands': {
        'environment': 'Visual Studio 2022 x64 developer shell; CUDA 12.9 bin and Python 3.13 on PATH; no CUDA_LAUNCH_BLOCKING in qualification runs.',
        'configure': 'cmake -S <source> -B <build> -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_CUDA_COMPILER="C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v12.9/bin/nvcc.exe" -DCMAKE_CUDA_ARCHITECTURES=61 -DPython3_EXECUTABLE=<python313> -DBUILD_TESTING=ON -DPARALLEL_MATER_BUILD_CUDA=ON -DPARALLEL_MATER_BUILD_D3D12=OFF -DPARALLEL_MATER_BUILD_VULKAN=OFF -DPARALLEL_MATER_BUILD_CONFORMANCE=ON -DPARALLEL_MATER_BUILD_GALLERY=ON -DPARALLEL_MATER_WINDOWS_GALLERY_AUTO_DEPLOY=OFF -DPARALLEL_MATER_BUILD_SLANG_MIRRORS=ON -DPARALLEL_MATER_BUILD_SLANG_GEOMETRY_CONSTRAINTS=ON -DPARALLEL_MATER_SLANGC_EXECUTABLE=<slang2026.18>/bin/slangc.exe -DFETCHCONTENT_SOURCE_DIR_PARALLEL_MATER_GLFW=<existing-glfw-source>',
        'build': 'cmake --build <build> --parallel 4',
        'registered_suite': 'ctest --test-dir <build> -C Release --output-on-failure --no-tests=error --output-junit <evidence>/ctest.xml -j1',
        'sdk': 'python tools/check_sdk_install.py --build-dir <build> --output <evidence>/sdk',
        'capture': 'python conformance/v1/realtime_device_capture.py --runner <sdk>/bin/parallel-mater-conformance.exe --driver-manifest <sdk>/share/parallel-mater/drivers.d/parallel_mater_slang_cuda.json --validation-layer-manifest <sdk>/share/parallel-mater/layers.d/parallel_mater_validation.json --runtime-variant cuda-runtime --target-id windows-gtx1080-slang-cuda --output <new-capture-directory>',
    },
    'qualification_effect': 'F8-26 remains incomplete. No partial pass or forced-synchronization diagnostic qualifies Windows. Preserve failure evidence; separately repair the fixture and production managed-memory ordering, then use F8-74 to freeze/reroute any protected changes before a fresh F8-26 lease and complete rerun.',
}
assert report['results']['registered_tests']['passed'] + len(failed) == 130
assert sdk['status'] == 'passed' and not machine['source_dirty'] and not sdk['source_dirty']
path = destination / (stem + '.json')
path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'report': str(path), 'report_sha256': digest(path), 'archive': str(archive), 'archive_sha256': digest(archive), 'archive_bytes': archive.stat().st_size, 'tests': report['results']['registered_tests'], 'sdk': report['results']['installed_sdk_relocation']}, indent=2))
