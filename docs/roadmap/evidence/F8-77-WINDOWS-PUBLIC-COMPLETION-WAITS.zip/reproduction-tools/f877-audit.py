import difflib
import hashlib
import importlib.util
import json
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f8-77-evidence-20261102')
before = '172ed9192350a5d96155a9da41c92595e26214e7'
after = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
def git(*args):
    return subprocess.check_output(['git', *args])
def sha(data):
    return hashlib.sha256(data).hexdigest()
def write(name, value):
    path = raw / name
    assert not path.exists(), f'Retain previous evidence: {name}'
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')

original_path = root / 'docs/roadmap/evidence/F8-76-WINDOWS-CUDA-METADATA-PROGRESS.json'
original = json.loads(original_path.read_text())
old_revision = original['after']['source_revision']
baseline_changes = git('diff', '--name-only', old_revision, before).decode().splitlines()
assert all(p.startswith('docs/') for p in baseline_changes)
archive_path = root / original['artifacts']['archive']
assert sha(archive_path.read_bytes()) == original['artifacts']['sha256']
with zipfile.ZipFile(archive_path) as archive:
    manifest = json.loads(archive.read('SHA256SUMS-current.json'))
    for mode in ['plain', 'validation']:
        name = f'installed-public-current/raw/{mode}/workloads/rigid-wall.json'
        data = archive.read(name)
        assert sha(data) == manifest[name]['sha256']
        output = raw / f'before-rigid-{mode}.json'
        assert not output.exists()
        output.write_bytes(data)
provenance = {
    'purpose': 'Exact retained normal-execution before measurements; source fields distinguish compiled binaries from the later claim checkout.',
    'compiled_source_revision': old_revision, 'compiled_source_tree': original['after']['source_tree'],
    'claim_base_revision': before, 'changes_from_compiled_source_to_claim_base': baseline_changes,
    'all_changes_are_documentation_or_roadmap_metadata': True,
    'authoritative_report': original_path.relative_to(root).as_posix(), 'authoritative_report_sha256': sha(original_path.read_bytes()),
    'archive': original['artifacts'], 'before_binary_identity': original['after'],
    'machine_at_original_capture': original['machine'], 'execution': 'Installed public runner, CUDA_LAUNCH_BLOCKING absent, 600 warmup / 7200 measured ticks, plain and validation. No consumer polling override.',
    'shorter_consumer_diagnostic': 'F8-76-WINDOWS-COMPLETION-DIAGNOSTIC remains non-qualification history; it is not substituted for these full baseline samples.',
}
write('before-provenance.json', provenance)

explanations = {
    'src/api/synchronization.cpp': 'Absolute bounded deadlines and queue completion notifications replace the two public polling sleeps; queue admission, execution, validation and failure semantics preserved.',
    'src/device/submission.cpp': 'Notify all public waiters after capture retirement, completion publication and queue bookkeeping; retain existing native drain and worker dependency scheduling.',
    'src/device/submission.hpp': 'Internal per-queue completion epoch/CV; no public C ABI or backend physics change.',
    'tests/api/CMakeLists.txt': 'Register strict plain/validation completion regressions for real drivers and the portable host fixture.',
    'tests/api/completion_wait_tests.cpp': 'Public deterministic timeline-gated ready/pending, zero/finite/large/infinite timeout, wait-any/all, foreign/null handles, simultaneous waiters and reset coverage.',
    'tests/api/async_submission_tests.cpp': 'Add failed timeline and ready-plus-failed fence assertions without removing existing checks.',
    'tests/api/submission_queue_tests.cpp': 'Add completion-before-blocking, expired deadline, simultaneous waiter and resource retirement regressions.',
}
changed = git('diff', '--name-only', before, after).decode().splitlines()
assert set(changed) == set(explanations), changed
assert not git('diff', '--name-only', before, after, '--', 'src/simulation', 'src/slang', 'include', 'conformance').strip()
old_sync = git('show', before + ':src/api/synchronization.cpp').decode()
new_sync = (root / 'src/api/synchronization.cpp').read_text()
for start, end in [('struct Submission {', 'struct PreparedSignal'), ('extern "C" PMAPI_ATTR PmResult PMAPI_CALL pmQueueSubmit(', 'extern "C" PMAPI_ATTR PmResult PMAPI_CALL pmQueueWaitIdle(')]:
    assert old_sync[old_sync.index(start):old_sync.index(end)] == new_sync[new_sync.index(start):new_sync.index(end)]
assert 'sleep_for(std::chrono::microseconds(50))' not in new_sync
for name in ['tests/api/async_submission_tests.cpp', 'tests/api/submission_queue_tests.cpp']:
    old = git('show', before + ':' + name).decode().splitlines()
    new = (root / name).read_text().splitlines()
    assert all(tag in ['equal', 'insert'] for tag, *_ in difflib.SequenceMatcher(None, old, new, autojunk=False).get_opcodes()), name

candidate_path = root / 'conformance/v1/qualification/realtime-candidate-v9.json'
assert sha(candidate_path.read_bytes()) == '4ed4ed7a097928944ac5667e8120e2447affda962a258e56c01dfd0d90d9dd4b'
candidate = json.loads(candidate_path.read_text())
spec = importlib.util.spec_from_file_location('checker', root / 'tools/check_realtime_candidate.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
tracked = set(git('ls-files').decode().splitlines())
closures = []
with tempfile.TemporaryDirectory(prefix='f877-closures-') as temporary:
    clean = Path(temporary)
    for item in candidate['source']['protected_closures']:
        for pattern in item['patterns']:
            for path in root.glob(pattern):
                if path.is_file() and path.relative_to(root).as_posix() in tracked:
                    target = clean / path.relative_to(root)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(path, target)
    for item in candidate['source']['protected_closures']:
        previous = next(c for c in original['closure_classification']['protected_closures'] if c['category'] == item['category'])
        identity = dict(zip(['file_count', 'sha256'], checker.closure_identity(clean, item['patterns'])))
        # Documentation added since the physical baseline does not match any
        # protected budget/contract path, so its clean identity is still exact.
        protected_doc_changes = set(baseline_changes) & {
            p.relative_to(root).as_posix() for pattern in item['patterns'] for p in root.glob(pattern) if p.is_file()
        }
        assert not protected_doc_changes
        differs = identity != previous['identities']['after']
        assert differs == (item['category'] == 'adapter_binding'), item['category']
        closures.append({'category': item['category'], 'patterns': item['patterns'],
                         'before': previous['identities']['after'], 'after': identity, 'changed_by_F8_77': differs})
write('source-closure-audit.json', {
    'before_revision': before, 'after_revision': after, 'after_tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
    'changed_files': [{'path': p, 'classification': explanations[p]} for p in changed],
    'protected_closures': closures, 'candidate_v9_manifest_unchanged': True,
    'fixed_tick_kernels_equations_schedule_budgets_and_oracles_unchanged': True,
    'submission_admission_execution_and_native_drain_byte_identical': True,
    'existing_async_and_queue_assertions_retained': True,
    'method': 'Tracked clean files only, ignored caches excluded; all before closure identities equal the exact retained F8-76 source and no protected documentation changed before this claim.',
    'qualification': 'Adapter-binding closure change requires F8-74 refreeze; F8-78 still owns complete Windows performance acceptance.'
})
(raw / 'source-repair.patch').write_bytes(git('diff', before, after))
print(json.dumps({'revision': after, 'changed_files': changed, 'changed_protected_categories': ['adapter_binding']}, indent=2))
