. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f826-env.ps1
$F877Source = $F826Source
$F877Build = 'D:/Repos/parallel-mater-f8-77-build-20261102'
$F877Evidence = 'D:/Repos/parallel-mater-f8-77-evidence-20261102'
$F877Python = $F826Python
foreach ($name in @('CUDA_LAUNCH_BLOCKING','PM_DRIVER_FILES','PM_LAYER_FILES','PM_ENABLE_LAYERS','PM_TEST_VALIDATION','F876_DIAGNOSTIC_YIELD_WAIT')) {
    Remove-Item "Env:$name" -ErrorAction SilentlyContinue
}
New-Item -ItemType Directory -Path $F877Evidence -Force | Out-Null
