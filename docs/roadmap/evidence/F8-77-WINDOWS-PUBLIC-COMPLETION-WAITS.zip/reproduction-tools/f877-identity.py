import ctypes
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

phase, build_text = sys.argv[1:3]
root, build = Path.cwd(), Path(build_text)
raw = Path('D:/Repos/parallel-mater-f8-77-evidence-20261102')
def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()
def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
runtime = ctypes.WinDLL('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v12.9/bin/cudart64_12.dll')
attrs = {}
for name, enum in [('managed_memory', 83), ('concurrent_managed_access', 89)]:
    value = ctypes.c_int()
    result = runtime.cudaDeviceGetAttribute(ctypes.byref(value), enum, 0)
    attrs[name] = {'result': result, 'value': value.value}
names = ['parallel_mater_driver_slang_cuda.dll', 'parallel_mater_driver_slang_cuda.pdb',
         'parallel-mater.dll', 'cudart64_12.dll', 'parallel-mater-slang-cuda-realtime-tests.exe',
         'parallel-mater-command-gallery-tests.exe', 'parallel-mater-conformance.exe',
         'parallel_mater_layer_validation.dll', 'CMakeCache.txt', 'parallel-mater-completion-wait-tests.exe', 'parallel-mater-submission-queue-tests.exe']
report = {'captured_at': datetime.now(timezone.utc).isoformat(), 'phase': phase,
          'source_revision': git('rev-parse', 'HEAD'), 'source_tree': git('rev-parse', 'HEAD^{tree}'),
          'source_status': git('status', '--porcelain'), 'build': str(build),
          'cuda_memory_attributes': attrs,
          'candidate_v9_manifest': identity(root / 'conformance/v1/qualification/realtime-candidate-v9.json'),
          'artifacts': [identity(build / name) for name in names if (build / name).is_file()]}
assert attrs['concurrent_managed_access'] == {'result': 0, 'value': 0}
assert not report['source_status'], report['source_status']
(raw / f'{phase}-identity.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({k: report[k] for k in ['phase', 'source_revision', 'source_tree', 'source_status', 'cuda_memory_attributes']}, indent=2))
