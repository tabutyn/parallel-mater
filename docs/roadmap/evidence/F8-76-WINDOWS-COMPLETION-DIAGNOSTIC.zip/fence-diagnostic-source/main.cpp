#include <parallel_mater_conformance/runner.hpp>
#include <fstream>
#include <iostream>
int main(int argc, char **argv) {
    if (argc != 3) return 2;
    try {
        const auto capture = parallel_mater::conformance::conformance_realtime_workload(argv[1], 600, 1200);
        std::ofstream stream(argv[2]);
        stream << capture << "\n";
        return stream ? 0 : 3;
    } catch (const std::exception &error) {
        std::cerr << error.what() << "\n";
        return 1;
    }
}
