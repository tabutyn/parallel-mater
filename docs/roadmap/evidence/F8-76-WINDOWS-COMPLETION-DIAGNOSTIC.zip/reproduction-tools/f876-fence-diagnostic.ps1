. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f876-env.ps1
& $F876Python C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f876-fence-diagnostic.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$sdk = "$F876Evidence/sdk-current/relocated-sdk"
$diagnostic = "$F876Evidence/fence-diagnostic-source"
$exe = "$F876Evidence/fence-diagnostic.exe"
$arguments = @('/nologo','/std:c++20','/EHsc','/O2','/DPM_CONFORMANCE_EMBEDDED=1',
    "/I$sdk/include", "/I$F876Source/conformance/v1/include", "$diagnostic/main.cpp", "$diagnostic/realtime_workload.cpp",
    "/Fe$exe", "/Fo$diagnostic/", '/link', "/LIBPATH:$sdk/lib", 'parallel-mater.lib')
@{executable=(Get-Command cl).Source; arguments=$arguments} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F876Evidence/fence-diagnostic-build-command.json"
cl @arguments *> "$F876Evidence/fence-diagnostic-build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F876Evidence/fence-diagnostic-build.log" -Tail 20; exit $LASTEXITCODE }
$env:PATH = "$sdk/bin;" + $env:PATH
$env:PM_DRIVER_FILES = "$sdk/share/parallel-mater/drivers.d/parallel_mater_slang_cuda.json"
Remove-Item Env:PM_TEST_VALIDATION -ErrorAction SilentlyContinue
$results = @()
foreach ($wait in @('canonical','yield')) {
    if ($wait -eq 'yield') { $env:F876_DIAGNOSTIC_YIELD_WAIT = '1' } else { Remove-Item Env:F876_DIAGNOSTIC_YIELD_WAIT -ErrorAction SilentlyContinue }
    $jsonPath = "$F876Evidence/fence-diagnostic-$wait.json"
    $watch = [Diagnostics.Stopwatch]::StartNew()
    & $exe six-family-mixed $jsonPath *> "$F876Evidence/fence-diagnostic-$wait.log"
    $code = $LASTEXITCODE
    $watch.Stop()
    $results += @{ mode=$wait; exit_code=$code; seconds=$watch.Elapsed.TotalSeconds; executable_sha256=(Get-FileHash -Algorithm SHA256 $exe).Hash.ToLowerInvariant(); qualification=$false; output=$jsonPath }
    if ($code -ne 0) { Get-Content "$F876Evidence/fence-diagnostic-$wait.log" -Tail 10; exit $code }
    $capture = Get-Content $jsonPath -Raw | ConvertFrom-Json
    $capture | Select-Object id,failed_ticks,simulated_to_wall_time_ratio,timings | ConvertTo-Json -Depth 5
}
$results | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F876Evidence/fence-diagnostic-results.json"
Remove-Item Env:F876_DIAGNOSTIC_YIELD_WAIT -ErrorAction SilentlyContinue
