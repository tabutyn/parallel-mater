import hashlib
import json
import zipfile
from pathlib import Path

raw = Path('D:/Repos/parallel-mater-f8-76-evidence-20261102')
destination = Path.cwd() / 'docs/roadmap/evidence'
stem = 'F8-76-WINDOWS-COMPLETION-DIAGNOSTIC'
def read(name):
    return json.loads((raw / name).read_text(encoding='utf-8-sig'))
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

results = read('fence-diagnostic-results.json')
assert len(results) == 2 and all(r['exit_code'] == 0 for r in results)
observations = {mode: read(f'fence-diagnostic-{mode}.json') for mode in ['canonical', 'yield']}
assert all(j['failed_ticks'] == 0 and j['warmup_ticks'] == 600 and j['measured_ticks'] == 1200 for j in observations.values())
assert observations['canonical']['counts'] == observations['yield']['counts']
members = [p for p in raw.glob('fence-diagnostic-*') if p.is_file() and p.suffix in ['.json', '.log']]
members += [p for p in (raw / 'fence-diagnostic-source').iterdir() if p.suffix in ['.cpp', '.hpp', '.json']]
helpers = Path('C:/Users/tabut/Repos/ballroller-2026/.codex-tmp')
files = {p.relative_to(raw).as_posix(): p for p in members}
for name in ['f876-fence-diagnostic.py', 'f876-fence-diagnostic.ps1', 'f876-diagnostic-report.py']:
    files['reproduction-tools/' + name] = helpers / name
manifest = {name: {'sha256': sha(p), 'bytes': p.stat().st_size} for name, p in sorted(files.items())}
archive = destination / (stem + '.zip')
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as output:
    for name, p in files.items():
        output.write(p, name)
    output.writestr('SHA256SUMS.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert all(hashlib.sha256(check.read(name)).hexdigest() == item['sha256'] for name, item in manifest.items())
report = {
    'schema': 'parallel-mater-completion-diagnostic/v1', 'task': 'F8-76',
    'purpose': 'Separate existing public fence-polling latency from device execution cost; not qualification evidence.',
    'runtime_revision': '68e7d8f3af24c47d8d4d1da374d7ef600b9f04e2',
    'runtime_driver_sha256': '456509e1ae3f12742f3bcd264528ca878fcb53ab0e04d77f0b5f0fec98deb1f2',
    'consumer_source': read('fence-diagnostic-source/identity.json'), 'commands': results,
    'observations': {mode: {k: v for k, v in j.items() if k != 'raw_samples'} for mode, j in observations.items()},
    'finding': 'Consumer yield-polling removes much of the timer-sized host delay, but GPU execution and the end-to-end path still exceed the frozen 10 ms physics p95 budget.',
    'limits': ['600 warmup / 1200 measured ticks; shorter than the required canonical 7200 sample capture.',
               'One exploratory serial pair, canonical then yield; no controlled thermal/clock equivalence or full-run performance claim.',
               'The diagnostic changes only a copied public consumer; production and canonical measurement source are untouched. Busy polling is not proposed as the production fix.',
               'No power policy, workload count, physics equation or frozen limit changed.'],
    'artifact': {'path': f'docs/roadmap/evidence/{stem}.zip', 'sha256': sha(archive), 'bytes': archive.stat().st_size, 'member_count': len(files) + 1},
}
path = destination / (stem + '.json')
assert not path.exists()
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'report_sha256': sha(path), 'artifact': report['artifact'], 'finding': report['finding']}, indent=2))
