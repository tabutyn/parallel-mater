import hashlib
import json
import subprocess
from pathlib import Path

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f8-76-evidence-20261102')
out = raw / 'fence-diagnostic-source'
assert not out.exists()
out.mkdir()
source = root / 'conformance/v1/src'
context = (source / 'test_context.hpp').read_text()
needle = '        return pmWaitForFences(device, 1, &fence, PM_TRUE, PM_TIMEOUT_INFINITE);'
replacement = '''        if (std::getenv("F876_DIAGNOSTIC_YIELD_WAIT") != nullptr) {
            for (;;) {
                const auto result = pmGetFenceStatus(device, fence);
                if (result != PM_NOT_READY) return result;
                std::this_thread::yield();
            }
        }
''' + needle
assert context.count(needle) == 1
(out / 'test_context.hpp').write_text(context.replace('#include <vector>', '#include <vector>\n#include <thread>').replace(needle, replacement), newline='\n')
(out / 'realtime_workload.cpp').write_bytes((source / 'realtime_workload.cpp').read_bytes())
(out / 'main.cpp').write_text('''#include <parallel_mater_conformance/runner.hpp>
#include <fstream>
#include <iostream>
int main(int argc, char **argv) {
    if (argc != 3) return 2;
    try {
        const auto capture = parallel_mater::conformance::conformance_realtime_workload(argv[1], 600, 1200);
        std::ofstream stream(argv[2]);
        stream << capture << "\\n";
        return stream ? 0 : 3;
    } catch (const std::exception &error) {
        std::cerr << error.what() << "\\n";
        return 1;
    }
}
''', newline='\n')
metadata = {
    'purpose': 'Isolated public-consumer diagnostic, not qualification; same unchanged driver and workload/counts; 600 warmup, 1200 measured ticks.',
    'runtime_revision': '68e7d8f3af24c47d8d4d1da374d7ef600b9f04e2',
    'consumer_only_change': 'Optional public fence-status/yield loop in a copied test_context.hpp instead of pmWaitForFences; canonical source and captured SDK remain untouched.',
    'source_files': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()},
    'canonical_workload_sha256': hashlib.sha256((source / 'realtime_workload.cpp').read_bytes()).hexdigest(),
}
(out / 'identity.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(out)
