. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f875-env.ps1
$configure = @('-S', $F875Source, '-B', $F875Build, '-G', 'Ninja',
    '-DCMAKE_BUILD_TYPE=Release', '-DBUILD_TESTING=ON',
    '-DCMAKE_CUDA_ARCHITECTURES=61', '-DPARALLEL_MATER_BUILD_CUDA=ON',
    '-DPARALLEL_MATER_BUILD_D3D12=OFF', '-DPARALLEL_MATER_BUILD_VULKAN=OFF',
    '-DPARALLEL_MATER_BUILD_GALLERY=OFF', '-DPARALLEL_MATER_BUILD_CONFORMANCE=OFF',
    '-DPARALLEL_MATER_BUILD_SLANG_MIRRORS=ON',
    '-DPARALLEL_MATER_BUILD_SLANG_GEOMETRY_CONSTRAINTS=ON',
    '-DPARALLEL_MATER_WINDOWS_GALLERY_AUTO_DEPLOY=OFF',
    "-DPython3_EXECUTABLE=$F875Python", "-DPARALLEL_MATER_SLANGC_EXECUTABLE=$F826Slang")
@{ executable = 'cmake'; arguments = $configure } | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F875Evidence/configure-command.json"
cmake @configure *> "$F875Evidence/configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F875Evidence/configure.log" -Tail 50; exit $LASTEXITCODE }
cmake --build $F875Build --target parallel-mater-fluid-realtime-cuda-tests -j 4 *> "$F875Evidence/before-build.log"
$buildExit = $LASTEXITCODE
Get-Content "$F875Evidence/before-build.log" -Tail 12
exit $buildExit
