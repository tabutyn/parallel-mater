import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

phase = sys.argv[1]
evidence = Path('D:/Repos/parallel-mater-f8-75-evidence-20261101')
binary = Path('D:/Repos/parallel-mater-f8-75-build-20261101/tests/solver/parallel-mater-fluid-realtime-cuda-tests.exe')
assert 'CUDA_LAUNCH_BLOCKING' not in os.environ
started = time.monotonic()
with (evidence / f'{phase}-normal.log').open('w', encoding='utf-8') as output:
    result = subprocess.run([str(binary)], stdout=output, stderr=subprocess.STDOUT, timeout=180)
report = {'captured_at': datetime.now(timezone.utc).isoformat(), 'command': [str(binary)],
          'cuda_launch_blocking': None, 'debugger': False,
          'exit_code': result.returncode, 'exit_hex': hex(result.returncode & 0xffffffff),
          'elapsed_seconds': time.monotonic() - started}
(evidence / f'{phase}-normal.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(report, indent=2))
print((evidence / f'{phase}-normal.log').read_text())
if phase == 'before':
    assert result.returncode & 0xffffffff == 0xc0000006
else:
    assert result.returncode == 0
