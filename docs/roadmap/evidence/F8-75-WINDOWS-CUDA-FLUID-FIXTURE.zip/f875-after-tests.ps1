. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f875-env.ps1
$targets = @('parallel-mater-fluid-realtime-cuda-tests',
    'parallel-mater-fluid-spatial-cuda-tests',
    'parallel-mater-liquid-coupling-realtime-cuda-tests',
    'parallel-mater-rigid-coupling-realtime-cuda-tests',
    'parallel-mater-spatial-build-cuda-tests',
    'parallel-mater-deformable-spatial-cuda-tests',
    'parallel-mater-deform-coupling-cuda-tests')
cmake --build $F875Build --target @targets -j 4 *> "$F875Evidence/after-build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$F875Evidence/after-build.log" -Tail 40; exit $LASTEXITCODE }
& $F875Python C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f875-identity.py after
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $F875Python C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f875-run.py after
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$filter = '^parallel-mater-(fluid-realtime|fluid-spatial|liquid-coupling-realtime|rigid-coupling-realtime|spatial-build|deformable-spatial|deform-coupling)-cuda-tests$'
$testArgs = @('--test-dir', $F875Build, '-R', $filter, '-j', '1', '--verbose', '--output-junit', "$F875Evidence/after-ctest.xml")
@{ executable = 'ctest'; arguments = $testArgs; cuda_launch_blocking = $null; targets = $targets } | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$F875Evidence/after-ctest-command.json"
ctest @testArgs *> "$F875Evidence/after-ctest.log"
$testExit = $LASTEXITCODE
Get-Content "$F875Evidence/after-ctest.log" -Tail 18
exit $testExit
