import ctypes
import hashlib
import importlib.util
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()
evidence = Path('D:/Repos/parallel-mater-f8-75-evidence-20261101')
build = Path('D:/Repos/parallel-mater-f8-75-build-20261101')
phase = sys.argv[1]

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

manifest_path = root / 'conformance/v1/qualification/realtime-candidate-v9.json'
candidate = json.loads(manifest_path.read_text())
spec = importlib.util.spec_from_file_location('check_realtime_candidate', root / 'tools/check_realtime_candidate.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
requested = tuple((c['category'], tuple(c['patterns'])) for c in candidate['source']['protected_closures'])
current = checker.revision_closure_identities(str(root), git('rev-parse', 'HEAD'), requested)
frozen = checker.revision_closure_identities(str(root), candidate['source']['revision'], requested)
baseline = json.loads((evidence / 'before-identity.json').read_text()) if phase == 'after' else None
closures = []
for closure in candidate['source']['protected_closures']:
    count, digest = current[closure['category']]
    frozen_count, frozen_digest = frozen[closure['category']]
    previous = next(c for c in baseline['protected_closures'] if c['category'] == closure['category']) if baseline else None
    closures.append({**closure, 'observed_file_count': count, 'observed_sha256': digest,
                     'frozen_identity_verified': frozen_count == closure['file_count'] and frozen_digest == closure['sha256'],
                     'matches_candidate_v9': count == closure['file_count'] and digest == closure['sha256'],
                     'unchanged_by_repair': (count == previous['observed_file_count'] and digest == previous['observed_sha256']) if previous else None})

runtime = ctypes.WinDLL('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v12.9/bin/cudart64_12.dll')
attributes = {}
for name, enum in [('managed_memory', 83), ('concurrent_managed_access', 89)]:
    value = ctypes.c_int()
    result = runtime.cudaDeviceGetAttribute(ctypes.byref(value), enum, 0)
    attributes[name] = {'result': result, 'value': value.value}

report = {
    'phase': phase, 'captured_at': datetime.now(timezone.utc).isoformat(),
    'source_revision': git('rev-parse', 'HEAD'), 'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'status_porcelain': git('status', '--porcelain'),
    'fixture': identity(root / 'tests/solver/fluid_realtime_cuda_tests.cu'),
    'candidate_manifest': identity(manifest_path),
    'protected_closures': closures,
    'all_frozen_closures_verified': all(c['frozen_identity_verified'] for c in closures),
    'all_protected_closures_unchanged_by_repair': all(c['unchanged_by_repair'] for c in closures) if baseline else None,
    'closure_method': 'Hash clean Git archives, excluding ignored build/Python cache files. Compare before/after tracked closures separately from immutable frozen source.',
    'preexisting_freeze_metadata_delta': git('diff', '--name-status', candidate['source']['revision'], '7d48576a80ccf33e9a4b6fe413513babae82625e', '--', 'conformance/v1'),
    'cuda_memory_attributes': attributes,
    'binaries': [identity(path) for path in sorted((build / 'tests/solver').glob('*-cuda-tests.exe'))],
}
destination = evidence / f'{phase}-identity.json'
destination.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({key: report[key] for key in ['phase', 'source_revision', 'source_tree', 'status_porcelain', 'all_frozen_closures_verified', 'all_protected_closures_unchanged_by_repair', 'cuda_memory_attributes']}, indent=2))
assert report['all_frozen_closures_verified']
assert not baseline or report['all_protected_closures_unchanged_by_repair']
assert attributes['concurrent_managed_access'] == {'result': 0, 'value': 0}
assert not report['status_porcelain'], 'Capture identities from clean committed source'
