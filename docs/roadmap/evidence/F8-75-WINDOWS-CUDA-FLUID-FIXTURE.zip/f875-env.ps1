. C:/Users/tabut/Repos/ballroller-2026/.codex-tmp/f826-env.ps1
$F875Source = $F826Source
$F875Build = 'D:/Repos/parallel-mater-f8-75-build-20261101'
$F875Evidence = 'D:/Repos/parallel-mater-f8-75-evidence-20261101'
$F875Python = $F826Python
$env:PATH = $F875Build + ';' + $env:PATH
Remove-Item Env:CUDA_LAUNCH_BLOCKING -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $F875Evidence -Force | Out-Null
