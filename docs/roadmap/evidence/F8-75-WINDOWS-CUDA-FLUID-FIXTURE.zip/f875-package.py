import hashlib
import json
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()
raw = Path('D:/Repos/parallel-mater-f8-75-evidence-20261101')
helpers = Path('C:/Users/tabut/Repos/ballroller-2026/.codex-tmp')
destination = root / 'docs/roadmap/evidence'
stem = 'F8-75-WINDOWS-CUDA-FLUID-FIXTURE'
def read(name):
    return json.loads((raw / name).read_text(encoding='utf-8-sig'))
def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)

before = read('before-identity.json')
after = read('after-identity.json')
baseline = before['source_revision']
repaired = after['source_revision']
fixture = 'tests/solver/fluid_realtime_cuda_tests.cu'
old = git('show', f'{baseline}:{fixture}').decode()
new = git('show', f'{repaired}:{fixture}').decode()
def split_tick(text):
    start = text.index('    void run_tick(')
    end = text.index('    std::vector<float> compression_errors(', start)
    return text[:start], text[start:end], text[end:]
old_prefix, old_tick, old_suffix = split_tick(old)
new_prefix, new_tick, new_suffix = split_tick(new)
snapshot = ('        // Snapshot at the completed tick boundary: Windows cannot read managed\n'
            '        // memory on the host while the following kernels are executing.\n'
            '        const unsigned live_count = *count;\n')
expected = old_tick.replace('        *time_advances = 0U;\n', snapshot + '        *time_advances = 0U;\n')
assert old_tick.count('query_sources, *count,') == 3
expected = expected.replace('query_sources, *count,', 'query_sources, live_count,')
assert new_tick == expected
assert old_prefix == new_prefix and old_suffix == new_suffix
assert '*count' not in new_tick.split('fluid_realtime_predict<<<', 1)[1]
changed = git('diff', '--name-only', baseline, repaired).decode().splitlines()
assert changed == [fixture], changed
assert after['all_protected_closures_unchanged_by_repair']
assert before['all_frozen_closures_verified'] and after['all_frozen_closures_verified']
assert not before['status_porcelain'] and not after['status_porcelain']
normal_before, normal_after = read('before-normal.json'), read('after-normal.json')
assert normal_before['exit_hex'] == '0xc0000006' and normal_after['exit_code'] == 0
assert normal_before['cuda_launch_blocking'] is None and normal_after['cuda_launch_blocking'] is None
debug = read('before-debug.json')
assert any(e['code'] == '0xc0000006' and e['parameters'][-1] == '0xc0000022' and not e['first_chance'] for e in debug['exceptions'])
suite = ET.parse(raw / 'after-ctest.xml').getroot()
cases = suite.findall('testcase')
assert len(cases) == 7, len(cases)
assert all(c.get('status') == 'run' and c.find('failure') is None and c.find('skipped') is None for c in cases)
test_results = [{'name': c.get('name'), 'status': 'passed', 'seconds': float(c.get('time'))} for c in cases]
log = (raw / 'after-normal.log').read_text()
metrics = {}
for line in log.splitlines():
    if line.startswith('F8_FLUID_60HZ_'):
        name, *fields = line.split()
        metrics[name] = {k: float(v) if any(x in v for x in '.eE') else int(v) for k, v in (f.split('=', 1) for f in fields)}
assert metrics['F8_FLUID_60HZ_WINDOW']['ticks'] == 720
(raw / 'fixture-repair.patch').write_bytes(git('diff', baseline, repaired, '--', fixture))
audit = {
    'changed_source_files': changed,
    'only_code_change': 'Snapshot managed count once before the first kernel; reuse it in the three query-count launch arguments.',
    'all_source_outside_run_tick_byte_identical': True,
    'assertions_tolerances_workloads_and_completion_boundaries_unchanged': True,
    'no_added_synchronization': True,
    'no_managed_host_dereference_after_first_launch': True,
    'review': 'After predict, host expressions read only ordinary Fixture fields, immutable local launch arguments and host options; managed allocations are passed as pointers. All observations remain after existing cudaDeviceSynchronize or cudaEventSynchronize calls.',
    'all_candidate_v9_frozen_hashes_verified': True,
    'every_tracked_protected_closure_identical_before_after': True,
    'preexisting_freeze_metadata_delta': before['preexisting_freeze_metadata_delta'],
    'closure_caveat': 'The public_oracle closure on both tested heads already includes the F8-70 activation-pointer update and v8-rejection/v9-freeze records added after the immutable candidate source. No repair changes these files. Hash clean Git archives so ignored Python caches cannot enter closure measurements.',
}
dump(raw / 'source-audit.json', audit)
for name in ['f875-env.ps1', 'f826-env.ps1', 'f875-baseline-build.ps1', 'f875-after-tests.ps1', 'f875-identity.py', 'f875-run.py', 'f826-debug.py', 'f875-package.py']:
    shutil.copy2(helpers / name, raw / name)
shutil.copy2(root / 'conformance/v1/qualification/realtime-candidate-v9.json', raw / 'realtime-candidate-v9.json')
members = sorted(p for p in raw.iterdir() if p.is_file() and p.name != 'SHA256SUMS.json')
manifest = {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size} for p in members}
dump(raw / 'SHA256SUMS.json', manifest)
archive = destination / f'{stem}.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as output:
    for path in [*members, raw / 'SHA256SUMS.json']:
        output.write(path, path.name)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for name, item in manifest.items():
        data = check.read(name)
        assert hashlib.sha256(data).hexdigest() == item['sha256'] and len(data) == item['bytes']
report = {
    'schema': 'parallel-mater-test-fixture-repair/v1', 'task': 'F8-75', 'status': 'passed',
    'captured_at': datetime.now(timezone.utc).isoformat(),
    'claim_pr': 'https://github.com/tabutyn/parallel-mater/pull/640',
    'lease_token': 'e44a1793-17a4-4184-a09f-ee34e0955c99',
    'scope': 'Windows CUDA fluid test fixture memory ordering only; no production or qualification change.',
    'before': before, 'after': after, 'machine': read('machine.json'),
    'baseline_reproduction': normal_before,
    'baseline_exceptions': debug['exceptions'],
    'repaired_normal_execution': normal_after,
    'fixture_metrics': metrics,
    'focused_cuda_tests': {'total': 7, 'passed': 7, 'failed': 0, 'skipped': 0, 'tests': test_results},
    'source_audit': audit,
    'candidate_check': (raw / 'after-candidate-check.log').read_text().splitlines()[-1],
    'limitations': [
        'The two production failures (PEG PAINT and installed soft-body-fluid) remain open F8-76 work; this focused fixture repair does not skip, alter or resolve them.',
        'F8-26 is not qualified. F8-74 must refreeze after Metal F8-73 and Windows F8-76 production repair; final Windows qualification needs a fresh F8-26 lease.',
        'The 720-tick timings describe this physical fixture run only, not installed-public or end-to-end 60 Hz performance qualification.',
    ],
    'artifacts': {'archive': f'docs/roadmap/evidence/{stem}.zip', 'sha256': sha(archive),
                  'bytes': archive.stat().st_size, 'files': len(members) + 1,
                  'member_manifest': 'SHA256SUMS.json', 'member_manifest_sha256': sha(raw / 'SHA256SUMS.json')},
}
assert report['candidate_check'].startswith('PASS:')
path = destination / f'{stem}.json'
dump(path, report)
print(json.dumps({'report': str(path), 'report_sha256': sha(path), 'archive': report['artifacts'], 'tested_revision': repaired, 'tests': report['focused_cuda_tests']}, indent=2))
